import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import CustomCursor from "@/components/custom-cursor"
import { DefaultSeo } from "next-seo"
import { defaultSEO } from "../seo-config"
import Footer from "@/components/footer"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "AffiliateMarketing.com - Get Paid Instantly | April 2025",
  description:
    "The future of affiliate marketing. Get paid instantly, find the best brands, and grow your business. Updated April 2025.",
  metadataBase: new URL("https://affiliatemarketing.com"),
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://affiliatemarketing.com",
    title: "AffiliateMarketing.com - Get Paid Instantly | April 2025",
    description:
      "The future of affiliate marketing. Get paid instantly, find the best brands, and grow your business. Updated April 2025.",
    siteName: "AffiliateMarketing.com",
  },
  twitter: {
    card: "summary_large_image",
    title: "AffiliateMarketing.com - Get Paid Instantly | April 2025",
    description:
      "The future of affiliate marketing. Get paid instantly, find the best brands, and grow your business. Updated April 2025.",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <DefaultSeo {...defaultSEO} />
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          <main id="main-content" tabIndex={-1}>
            {children}
          </main>
          <Footer />
          <CustomCursor />
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'