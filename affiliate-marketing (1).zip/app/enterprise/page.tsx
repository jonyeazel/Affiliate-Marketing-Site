import { ArrowRight, Check, BarChart3, Users, Shield, Zap, FileText, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function EnterprisePage() {
  return (
    <div className="bg-background">
      <div className="container py-12 md:py-24">
        <div className="mx-auto max-w-3xl text-center mb-16">
          <Badge className="mb-4" variant="secondary">
            Enterprise Solutions
          </Badge>
          <h1 className="mb-4 text-3xl font-bold sm:text-4xl md:text-5xl">Affiliate Marketing at Scale</h1>
          <p className="text-muted-foreground md:text-xl">
            Comprehensive solutions for brands, agencies, and enterprise-level affiliate programs.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 mt-8">
            <Button size="lg">
              Schedule a Demo
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline">
              Contact Sales
            </Button>
          </div>
        </div>

        <Tabs defaultValue="brands" className="w-full max-w-5xl mx-auto">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="brands">For Brands</TabsTrigger>
            <TabsTrigger value="agencies">For Agencies</TabsTrigger>
            <TabsTrigger value="networks">For Networks</TabsTrigger>
          </TabsList>

          <TabsContent value="brands" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 mb-12">
              <div>
                <h2 className="text-3xl font-bold mb-4">Scale Your Affiliate Program</h2>
                <p className="text-muted-foreground mb-6">
                  Our enterprise platform helps brands recruit, manage, and optimize their affiliate programs at scale
                  with advanced tools and analytics.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">AI-Powered Affiliate Matching</h3>
                      <p className="text-sm text-muted-foreground">
                        Our proprietary algorithm identifies and recommends the perfect affiliates for your brand based
                        on audience alignment, performance history, and content quality.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">Advanced Fraud Detection</h3>
                      <p className="text-sm text-muted-foreground">
                        Protect your program with real-time fraud monitoring that identifies suspicious patterns and
                        prevents commission fraud.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">Multi-Touch Attribution</h3>
                      <p className="text-sm text-muted-foreground">
                        Understand the true impact of your affiliates with advanced attribution modeling that tracks the
                        entire customer journey.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">Custom Commission Structures</h3>
                      <p className="text-sm text-muted-foreground">
                        Create sophisticated commission rules based on product categories, order value, new vs.
                        returning customers, and more.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="bg-muted rounded-lg p-6 flex items-center justify-center">
                <div className="w-full max-w-sm h-64 bg-background rounded-lg flex items-center justify-center">
                  <BarChart3 className="h-24 w-24 text-muted-foreground/30" />
                </div>
              </div>
            </div>

            <div className="grid gap-6 md:grid-cols-3 mb-12">
              <Card>
                <CardHeader>
                  <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Affiliate Recruitment</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Access our network of 100,000+ vetted affiliates and creators across all niches and platforms.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">AI-powered matching</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Quality verification</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Outreach automation</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                    <Shield className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Program Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Comprehensive tools to manage your affiliate program efficiently and effectively.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Automated approvals</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Content compliance</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Performance tracking</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                    <BarChart3 className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Analytics & Reporting</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Powerful analytics to measure performance and optimize your affiliate strategy.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Custom dashboards</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">ROI analysis</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Automated reporting</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <div className="mb-12">
              <Card>
                <CardHeader>
                  <CardTitle>Case Study: How Brand X Scaled Their Affiliate Program</CardTitle>
                  <CardDescription>
                    Learn how a leading e-commerce brand increased affiliate revenue by 215% in 12 months
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <div className="text-3xl font-bold text-primary">215%</div>
                      <div className="font-medium">Revenue Growth</div>
                      <p className="text-sm text-muted-foreground">
                        Year-over-year increase in affiliate-driven revenue
                      </p>
                    </div>
                    <div className="space-y-2">
                      <div className="text-3xl font-bold text-primary">3.2x</div>
                      <div className="font-medium">ROI Improvement</div>
                      <p className="text-sm text-muted-foreground">
                        Increase in return on affiliate marketing investment
                      </p>
                    </div>
                    <div className="space-y-2">
                      <div className="text-3xl font-bold text-primary">450+</div>
                      <div className="font-medium">Active Affiliates</div>
                      <p className="text-sm text-muted-foreground">Growth from 120 to over 450 quality affiliates</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    Read Full Case Study
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </div>

            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">Ready to Scale Your Affiliate Program?</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Our enterprise team will work with you to create a customized solution for your specific needs.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button size="lg">Schedule a Demo</Button>
                <Button size="lg" variant="outline">
                  Download Enterprise Brochure
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="agencies" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 mb-12">
              <div>
                <h2 className="text-3xl font-bold mb-4">Agency Management Platform</h2>
                <p className="text-muted-foreground mb-6">
                  Purpose-built tools for agencies managing multiple affiliate programs across different clients and
                  industries.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">Multi-Client Management</h3>
                      <p className="text-sm text-muted-foreground">
                        Manage all your clients' affiliate programs from a single dashboard with role-based access
                        controls and client-specific views.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">White-Label Solutions</h3>
                      <p className="text-sm text-muted-foreground">
                        Fully customizable white-label dashboards and reporting tools that can be branded for your
                        agency and clients.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">Cross-Program Analytics</h3>
                      <p className="text-sm text-muted-foreground">
                        Compare performance across different clients and industries to identify trends and
                        opportunities.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">Agency Growth Tools</h3>
                      <p className="text-sm text-muted-foreground">
                        Resources to help you pitch new clients, expand services, and grow your agency business.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="bg-muted rounded-lg p-6 flex items-center justify-center">
                <div className="w-full max-w-sm h-64 bg-background rounded-lg flex items-center justify-center">
                  <Users className="h-24 w-24 text-muted-foreground/30" />
                </div>
              </div>
            </div>

            <div className="grid gap-6 md:grid-cols-3 mb-12">
              <Card>
                <CardHeader>
                  <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                    <Zap className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Client Acquisition</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Tools and resources to help you win new clients and grow your agency business.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Pitch templates</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Program audits</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Opportunity analysis</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                    <FileText className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Client Reporting</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Automated, white-label reporting solutions for all your clients.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Custom dashboards</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Scheduled reports</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">White-label branding</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                    <MessageSquare className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Agency Community</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Connect with other agencies to share best practices and industry insights.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Agency forums</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Expert webinars</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4 text-primary" />
                      <span className="text-sm">Resource library</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">Become an Agency Partner</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Join our agency partner program to access exclusive tools, resources, and commission structures.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button size="lg">Apply for Agency Partnership</Button>
                <Button size="lg" variant="outline">
                  Learn More
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="networks" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 mb-12">
              <div>
                <h2 className="text-3xl font-bold mb-4">Affiliate Network Solutions</h2>
                <p className="text-muted-foreground mb-6">
                  Enterprise-grade infrastructure and tools for affiliate networks and large-scale program operators.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">Network Management Platform</h3>
                      <p className="text-sm text-muted-foreground">
                        Comprehensive tools to manage thousands of affiliates and merchants with advanced automation and
                        scalability.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">Payment Processing</h3>
                      <p className="text-sm text-muted-foreground">
                        Automated commission calculations, payment processing, and tax management for global affiliate
                        networks.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">API & Integration Suite</h3>
                      <p className="text-sm text-muted-foreground">
                        Robust APIs and integration tools to connect with your existing systems and third-party
                        platforms.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="mr-2 h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <h3 className="font-medium">Enterprise Security</h3>
                      <p className="text-sm text-muted-foreground">
                        Advanced security features including fraud detection, compliance monitoring, and data
                        protection.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="bg-muted rounded-lg p-6 flex items-center justify-center">
                <div className="w-full max-w-sm h-64 bg-background rounded-lg flex items-center justify-center">
                  <Shield className="h-24 w-24 text-muted-foreground/30" />
                </div>
              </div>
            </div>

            <div className="mb-12">
              <Card className="bg-primary text-primary-foreground">
                <CardHeader>
                  <CardTitle>Network Partnership Program</CardTitle>
                  <CardDescription className="text-primary-foreground/80">
                    Strategic partnerships for affiliate networks and large-scale program operators
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <h3 className="font-medium">Data Exchange</h3>
                      <p className="text-sm text-primary-foreground/80">
                        Access our exclusive market intelligence data to enhance your network offerings.
                      </p>
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-medium">Technology Integration</h3>
                      <p className="text-sm text-primary-foreground/80">
                        Integrate our advanced tools and features into your existing network platform.
                      </p>
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-medium">Co-Marketing Opportunities</h3>
                      <p className="text-sm text-primary-foreground/80">
                        Joint marketing initiatives to grow both our platforms and create industry leadership.
                      </p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-background text-foreground hover:bg-background/90">
                    Explore Network Partnerships
                  </Button>
                </CardFooter>
              </Card>
            </div>

            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">Custom Enterprise Solutions</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Our enterprise team will work with you to create a tailored solution for your network's specific
                requirements.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button size="lg">Request Custom Solution</Button>
                <Button size="lg" variant="outline">
                  Contact Enterprise Team
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

