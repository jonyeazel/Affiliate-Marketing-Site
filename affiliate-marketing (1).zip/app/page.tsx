"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion, useScroll, useTransform } from "framer-motion"
import { ArrowRight, Check, ChevronDown, DollarSign, Lock, Shield, Sparkles, Star, Users, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"

// Custom components
import ParticleBackground from "@/components/particle-background"
import { PulseEffect } from "@/components/pulse-effect"
import { GlowCard } from "@/components/glow-card"
import { AnimatedCounter } from "@/components/animated-counter"
import { TestimonialCard } from "@/components/testimonial-card"
import { CredentialCard } from "@/components/credential-card"
import { FaqSection } from "@/components/faq-section"
import { HowItWorks } from "@/components/how-it-works"
import { NewsletterForm } from "@/components/newsletter-form"
import { StatsCounter } from "@/components/stats-counter"
import { BrandShowcase } from "@/components/brand-showcase"
import { ComparisonTable } from "@/components/comparison-table"
import { DashboardPreview } from "@/components/dashboard-preview"
import { TestimonialVideo } from "@/components/testimonial-video"
import { SuccessStories } from "@/components/success-stories"
import { FloatingActionButton } from "@/components/floating-action-button"
import { CookieConsent } from "@/components/cookie-consent"
import { ComingSoonFeatures } from "@/components/coming-soon-features"
import { FoundersSection } from "@/components/founders-section"
import { AdvancedHeader } from "@/components/advanced-header"

export default function Home() {
  const [email, setEmail] = useState("")
  const [userType, setUserType] = useState<"affiliate" | "brand" | null>(null)
  const [showThankYou, setShowThankYou] = useState(false)
  const [remainingSpots, setRemainingSpots] = useState(97)

  const { scrollYProgress } = useScroll()
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0])
  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 0.95])

  // Simulate decreasing spots over time
  useEffect(() => {
    const timer = setInterval(() => {
      setRemainingSpots((prev) => {
        if (prev > 50) return prev - 1
        return prev
      })
    }, 120000) // Every 2 minutes

    return () => clearInterval(timer)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      console.log("Email submitted:", email, "User type:", userType)
      setShowThankYou(true)
      setTimeout(() => setShowThankYou(false), 3000)
      setEmail("")
    }
  }

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  }

  return (
    <div className="min-h-screen bg-[#0A0A14] text-white overflow-hidden">
      {/* Particle Background */}
      <ParticleBackground />

      {/* Advanced Header */}
      <AdvancedHeader />

      {showThankYou && (
        <motion.div
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 100, opacity: 0 }}
          className="fixed top-20 right-4 z-50 bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white p-4 rounded-lg shadow-lg flex items-center gap-2"
        >
          <Check className="h-5 w-5" />
          <span>You're in! Welcome to the future of affiliate marketing.</span>
          <button onClick={() => setShowThankYou(false)} className="ml-2 text-white/80 hover:text-white">
            ×
          </button>
        </motion.div>
      )}

      <main>
        {/* Hero Section */}
        <section className="relative py-20 md:py-32 overflow-hidden">
          <motion.div
            style={{ opacity: heroOpacity, scale: heroScale }}
            className="absolute inset-0 bg-gradient-to-b from-[#0033CC]/20 to-transparent"
          ></motion.div>

          <div className="container relative z-10 px-4 md:px-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto text-center mb-16"
            >
              <Badge
                className="mb-6 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50 px-4 py-1 text-sm"
                variant="outline"
              >
                NO MORE 90 DAY PAYMENT CYCLE
              </Badge>

              <h1 className="mb-6 text-4xl sm:text-5xl md:text-6xl font-black tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-[#00F0FF] to-[#0033CC]">
                Get Paid Instantly.
                <br />
                Get Real Traffic.
              </h1>

              <p className="text-base md:text-lg text-white/80 mb-8 max-w-2xl mx-auto">
                Our revolutionary platform connects creators with premium brands, eliminates payment delays, and puts
                you in control of your affiliate journey.
              </p>

              <div id="features" className="flex flex-wrap justify-center gap-3 mb-8">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8 }}
                  className="inline-flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 text-sm hover:border-[#00F0FF]/50 hover:bg-white/10 transition-all duration-300"
                >
                  <Check className="h-3.5 w-3.5 text-[#00F0FF]" />
                  <p className="text-white/90">Instant payments</p>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2, duration: 0.5 }}
                  className="inline-flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 text-sm hover:border-[#00F0FF]/50 hover:bg-white/10 transition-all duration-300"
                >
                  <Check className="h-3.5 w-3.5 text-[#00F0FF]" />
                  <p className="text-white/90">Verified traffic</p>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                  className="inline-flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 text-sm hover:border-[#00F0FF]/50 hover:bg-white/10 transition-all duration-300"
                >
                  <Check className="h-3.5 w-3.5 text-[#00F0FF]" />
                  <p className="text-white/90">Simple dashboard</p>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4, duration: 0.5 }}
                  className="inline-flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 text-sm hover:border-[#00F0FF]/50 hover:bg-white/10 transition-all duration-300"
                >
                  <Check className="h-3.5 w-3.5 text-[#00F0FF]" />
                  <p className="text-white/90">24/7 support</p>
                </motion.div>
              </div>

              <div className="flex flex-col sm:flex-row justify-center gap-4 mb-8">
                <Button
                  size="lg"
                  onClick={() => scrollToSection("signup")}
                  className="bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90 hover:scale-105 transition-all duration-300 font-bold text-lg px-8 py-6 shadow-xl group relative overflow-hidden"
                >
                  <span className="relative z-10">Join The Waitlist</span>
                  <ArrowRight className="relative z-10 ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                  <PulseEffect />
                </Button>
                <Link href="/quiz">
                  <Button
                    size="lg"
                    className="bg-[#0A0A14] border border-[#00F0FF]/20 text-white hover:bg-[#00F0FF]/10 hover:border-[#00F0FF]/40 hover:scale-105 transition-all duration-300 font-bold text-lg px-8 py-6 shadow-xl group"
                  >
                    Take Quiz
                    <Sparkles className="ml-2 h-5 w-5 group-hover:animate-pulse transition-all duration-300" />
                  </Button>
                </Link>
                <div className="flex items-center justify-center gap-2 text-white/70">
                  <span>
                    Only <span className="text-[#00F0FF] font-medium">{remainingSpots}</span> spots left
                  </span>
                </div>
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8, duration: 0.5 }}
                className="flex justify-center mt-12 animate-bounce"
              >
                <ChevronDown
                  className="h-6 w-6 text-white/50 cursor-pointer hover:text-white transition-colors duration-300"
                  onClick={() => scrollToSection("demo")}
                />
              </motion.div>
            </motion.div>

            {/* Interactive Demo */}
            <motion.div
              id="demo"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8 }}
              className="max-w-3xl mx-auto relative"
            >
              <GlowCard className="relative bg-[#0A0A14]/60 backdrop-blur-sm rounded-xl overflow-hidden border border-white/10 shadow-2xl hover:border-[#00F0FF]/30 transition-all duration-500">
                <div className="p-6 border-b border-white/10 flex justify-between items-center">
                  <h3 className="text-xl font-bold">30-Day Earnings Preview</h3>
                  <Badge
                    className="bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50 font-medium whitespace-nowrap px-2 py-0.5 text-xs"
                    variant="outline"
                  >
                    COMING SOON
                  </Badge>
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <div className="text-white/70 text-sm">Total Sales</div>
                      <div className="text-2xl font-bold">$4,750</div>
                    </div>
                    <div className="text-right">
                      <div className="text-white/70 text-sm">Your Commission</div>
                      <div className="text-2xl font-bold text-gradient bg-clip-text text-transparent bg-gradient-to-r from-[#00F0FF] to-[#0033CC]">
                        $1,425
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div className="bg-white/5 p-3 rounded-lg flex justify-between items-center hover:bg-white/10 transition-colors duration-300">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#00F0FF]/20 to-[#0033CC]/20 flex items-center justify-center">
                          <DollarSign className="h-5 w-5 text-[#00F0FF]" />
                        </div>
                        <div>
                          <div className="font-medium">Sale: Premium Course</div>
                          <div className="text-sm text-white/60">2 hours ago</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-[#00F0FF]">+$87.50</div>
                        <div className="text-xs text-white/60">Paid instantly</div>
                      </div>
                    </div>

                    <div className="bg-white/5 p-3 rounded-lg flex justify-between items-center hover:bg-white/10 transition-colors duration-300">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#00F0FF]/20 to-[#0033CC]/20 flex items-center justify-center">
                          <DollarSign className="h-5 w-5 text-[#00F0FF]" />
                        </div>
                        <div>
                          <div className="font-medium">Sale: Fitness Bundle</div>
                          <div className="text-sm text-white/60">5 hours ago</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-[#00F0FF]">+$124.50</div>
                        <div className="text-xs text-white/60">Paid instantly</div>
                      </div>
                    </div>

                    <div className="bg-white/5 p-3 rounded-lg flex justify-between items-center hover:bg-white/10 transition-colors duration-300">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#00F0FF]/20 to-[#0033CC]/20 flex items-center justify-center">
                          <DollarSign className="h-5 w-5 text-[#00F0FF]" />
                        </div>
                        <div>
                          <div className="font-medium">Sale: Tech Gadget</div>
                          <div className="text-sm text-white/60">Yesterday</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-[#00F0FF]">+$65.25</div>
                        <div className="text-xs text-white/60">Paid instantly</div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 p-4 rounded-lg border border-[#00F0FF]/30">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">Traditional Platform</div>
                      <div className="font-medium text-red-400">$0.00</div>
                    </div>
                    <div className="text-sm text-white/70 mb-4">You'd still be waiting 30-90 days for payment</div>

                    <div className="flex items-center justify-between">
                      <div className="font-medium">AffiliateMarketing.com</div>
                      <div className="font-medium text-[#00F0FF]">$1,425.00</div>
                    </div>
                    <div className="text-sm text-white/70">All earnings paid instantly to your account</div>
                  </div>

                  <div className="text-center mt-6">
                    <Button
                      className="bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90 hover:scale-105 transition-all duration-300 group relative overflow-hidden"
                      onClick={() => scrollToSection("signup")}
                    >
                      <span className="relative z-10">Join the Revolution</span>
                      <ArrowRight className="relative z-10 ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                      <PulseEffect />
                    </Button>
                  </div>
                </div>
              </GlowCard>
            </motion.div>
          </div>
        </section>

        {/* Social Proof Section */}
        <section className="py-12 bg-gradient-to-b from-[#0A0A14] to-[#0A1A2F]/50 border-y border-white/10">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-8">
              <div className="flex items-center gap-2">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <span className="text-white/80">
                  Rated <AnimatedCounter end={4.9} decimals={1} /> by early access users
                </span>
              </div>

              <div className="h-8 w-px bg-white/10 hidden md:block"></div>

              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-[#00F0FF]" />
                <span className="text-white/80">
                  <AnimatedCounter end={5000} suffix="+" /> on waitlist
                </span>
              </div>

              <div className="h-8 w-px bg-white/10 hidden md:block"></div>

              <div className="flex flex-wrap justify-center gap-4 md:gap-8">
                {["Amazon", "Shopify", "Nike", "Samsung", "Sephora"].map((brand) => (
                  <span
                    key={brand}
                    className="text-white/50 font-medium hover:text-white/80 transition-colors duration-300 cursor-default"
                  >
                    {brand}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Stats Counter Section */}
        <StatsCounter />

        {/* Dashboard Preview Section */}
        <DashboardPreview />

        {/* How It Works Section */}
        <HowItWorks />

        {/* Comparison Table Section */}
        <ComparisonTable />

        {/* Brand Showcase Section */}
        <BrandShowcase />

        {/* Digital Credential Card Section */}
        <section className="py-24 bg-gradient-to-b from-[#0A0A14] to-[#050A14]">
          <div className="container px-4 md:px-6">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <Badge className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50 px-4 py-1 font-medium">
                EXCLUSIVE MEMBERSHIP
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
                Your Digital Credential Card
              </h2>
              <p className="text-base md:text-lg text-white/70 mb-8">
                Every member receives a unique, personalized credential card that verifies your status and unlocks
                exclusive platform benefits.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              {/* Card Container */}
              <div className="relative mx-auto w-full max-w-md">
                <CredentialCard />
              </div>

              <div className="space-y-8">
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold text-white">More Than Just A Card</h3>
                  <p className="text-white/70">
                    Your digital credential is a secure, tamper-proof verification of your status as an official
                    affiliate partner. It evolves with your journey and unlocks new benefits as you grow.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white/5 rounded-xl p-6 border border-white/10 hover:border-[#00F0FF]/30 hover:bg-white/10 transition-all duration-300">
                    <Shield className="h-10 w-10 text-[#00F0FF] mb-4" />
                    <h4 className="text-lg font-bold text-white mb-2">Secure Verification</h4>
                    <p className="text-sm md:text-base text-white/70 mb-4">
                      Your credential uses advanced cryptography to verify your identity and protect against fraud.
                    </p>
                  </div>

                  <div className="bg-white/5 rounded-xl p-6 border border-white/10 hover:border-[#00F0FF]/30 hover:bg-white/10 transition-all duration-300">
                    <Star className="h-10 w-10 text-[#00F0FF] mb-4 fill-[#00F0FF]" />
                    <h4 className="text-lg font-bold text-white mb-2">Status Progression</h4>
                    <p className="text-sm md:text-base text-white/70 mb-4">
                      Level up your card as you hit performance milestones and unlock exclusive rewards
                    </p>
                  </div>

                  <div className="bg-white/5 rounded-xl p-6 border border-white/10 hover:border-[#00F0FF]/30 hover:bg-white/10 transition-all duration-300">
                    <Users className="h-10 w-10 text-[#00F0FF] mb-4" />
                    <h4 className="text-lg font-bold text-white mb-2">Community Access</h4>
                    <p className="text-sm md:text-base text-white/70 mb-4">
                      Your credential grants access to exclusive communities and networking opportunities.
                    </p>
                  </div>

                  <div className="bg-white/5 rounded-xl p-6 border border-white/10 hover:border-[#00F0FF]/30 hover:bg-white/10 transition-all duration-300">
                    <Zap className="h-10 w-10 text-[#00F0FF] mb-4" />
                    <h4 className="text-lg font-bold text-white mb-2">Special Perks</h4>
                    <p className="text-sm md:text-base text-white/70 mb-4">
                      Enjoy platform benefits like higher commission rates and faster payouts with your verified status
                    </p>
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    size="lg"
                    onClick={() => scrollToSection("signup")}
                    className="bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white font-bold text-lg px-8 py-6 rounded-xl hover:opacity-90 hover:scale-105 transition-all duration-300 group relative overflow-hidden"
                  >
                    <span className="relative z-10">Get Your Credential Card</span>
                    <ArrowRight className="relative z-10 ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                    <PulseEffect />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Success Stories Section */}
        <SuccessStories />

        {/* Testimonial Video Section */}
        <TestimonialVideo />

        {/* Testimonials Section */}
        <section id="testimonials" className="py-24 bg-[#0A0A14]">
          <div className="container px-4 md:px-6">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <Badge
                className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
                variant="outline"
              >
                SUCCESS STORIES
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
                What Our Beta Users Are Saying
              </h2>
              <p className="text-base md:text-lg text-white/70">
                We've given a select group of affiliates and brands early access to our platform. Here's what they
                think.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <TestimonialCard
                quote="I've been in affiliate marketing for 7 years, and this is the platform I've been waiting for. The instant payments alone are worth it, but the AI matching has connected me with brands I never would have found otherwise."
                name="Alex Chen"
                role="Tech & Lifestyle Blogger"
                delay={0.2}
              />

              <TestimonialCard
                quote="As a DTC brand, finding the right affiliates has always been our biggest challenge. This platform solved that problem instantly. We're seeing 3x the ROI compared to our previous affiliate program."
                name="Sarah Johnson"
                role="CMO, Fashion Brand"
                delay={0.4}
              />

              <TestimonialCard
                quote="The unified dashboard is a game-changer. I used to spend hours jumping between different affiliate platforms. Now I can manage everything in one place and focus on creating content that converts."
                name="Michael Rodriguez"
                role="Fitness Influencer"
                delay={0.6}
              />
            </div>
          </div>
        </section>

        {/* Founders Section */}
        <FoundersSection />

        {/* Coming Soon Features Section */}
        <ComingSoonFeatures />

        {/* FAQ Section */}
        <section id="faq">
          <FaqSection />
        </section>

        {/* Newsletter Section */}
        <section className="py-24 bg-[#0A0A14]">
          <div className="container px-4 md:px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <Badge
                  className="mb-4 bg-gradient-to-r from-[#00FෝFF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
                  variant="outline"
                >
                  STAY CONNECTED
                </Badge>
                <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
                  Never Miss an Update
                </h2>
                <p className="text-base md:text-lg text-white/70 mb-8">
                  Subscribe to our newsletter for exclusive insights, early access to new features, and special offers
                  only available to subscribers.
                </p>

                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-[#00F0FF] mr-2 shrink-0 mt-0.5" />
                    <span className="text-white/80">Insider tips from top affiliates</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-[#00F0FF] mr-2 shrink-0 mt-0.5" />
                    <span className="text-white/80">Early access to new platform features</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-[#00F0FF] mr-2 shrink-0 mt-0.5" />
                    <span className="text-white/80">Exclusive promotional opportunities</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-[#00F0FF] mr-2 shrink-0 mt-0.5" />
                    <span className="text-white/80">Monthly affiliate marketing trends report</span>
                  </li>
                </ul>
              </div>

              <div>
                <NewsletterForm />
              </div>
            </div>
          </div>
        </section>

        {/* Signup Section */}
        <section id="signup" className="py-24 relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,240,255,0.15),transparent_70%)]"></div>
          <div className="container relative z-10 px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <Badge
                className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
                variant="outline"
              >
                LIMITED SPOTS AVAILABLE
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
                Join The Affiliate Marketing Revolution
              </h2>
              <p className="text-base md:text-lg text-white/70 mb-8">
                Be among the first to experience the future of affiliate marketing. Early access members will receive
                exclusive benefits and priority support.
              </p>

              <form
                onSubmit={handleSubmit}
                className="max-w-md mx-auto bg-gradient-to-br from-[#0A1A2F]/40 to-[#0A0A14]/80 backdrop-blur-sm rounded-xl p-8 border border-white/10 shadow-xl"
              >
                <h3 className="text-2xl font-bold mb-6 text-center">Get Early Access</h3>

                <div className="space-y-4 mb-6">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-white/70 mb-1">
                      Email Address
                    </label>
                    <div className="relative">
                      <Input
                        id="email"
                        type="email"
                        placeholder="you@example.com"
                        className="w-full bg-white/10 border-white/20 focus:border-[#00F0FF] h-12 pl-10"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                      <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50">
                        <Lock className="h-4 w-4" />
                      </div>
                    </div>
                    <div className="mt-1 flex items-center text-xs text-white/50">
                      <Shield className="h-3 w-3 mr-1" /> Your email is secure and will never be shared
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-white/70 mb-1">I am a...</label>
                    <div className="grid grid-cols-2 gap-4">
                      <Button
                        type="button"
                        onClick={() => setUserType("affiliate")}
                        className={`h-12 ${
                          userType === "affiliate"
                            ? "bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white"
                            : "bg-white/10 text-white hover:bg-white/20"
                        } transition-all duration-300 hover:scale-105`}
                      >
                        Affiliate
                      </Button>
                      <Button
                        type="button"
                        onClick={() => setUserType("brand")}
                        className={`h-12 ${
                          userType === "brand"
                            ? "bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white"
                            : "bg-white/10 text-white hover:bg-white/20"
                        } transition-all duration-300 hover:scale-105`}
                      >
                        Brand
                      </Button>
                    </div>
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90 hover:scale-105 transition-all duration-300 font-bold h-12 text-lg group relative overflow-hidden"
                  disabled={!userType}
                >
                  <span className="relative z-10">Join Waitlist</span>
                  <ArrowRight className="relative z-10 ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                  <PulseEffect />
                </Button>

                <div className="mt-4 flex justify-center items-center gap-2">
                  <div className="flex -space-x-2">
                    {[1, 2, 3].map((i) => (
                      <div
                        key={i}
                        className="w-6 h-6 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] border border-black"
                      ></div>
                    ))}
                  </div>
                  <p className="text-white/50 text-sm">
                    <span className="text-[#00F0FF] font-medium">{remainingSpots}</span> spots left
                  </p>
                </div>

                <p className="mt-4 text-center text-white/50 text-sm">
                  By joining, you agree to our Terms of Service and Privacy Policy
                </p>
              </form>

              <div className="mt-12 flex flex-col md:flex-row items-center justify-center gap-8 text-white/60">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-[#00F0FF]" />
                  <span>Secure & Confidential</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-[#00F0FF]" />
                  <span>5,000+ on waitlist</span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-[#00F0FF]" />
                  <span>Early access benefits</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 py-12 bg-[#0A0A14]">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <div className="flex items-center gap-3 mb-4 md:mb-0">
              <div className="relative w-8 h-8">
                <div className="absolute inset-0 bg-[#00F0FF] rounded-full blur-sm opacity-60"></div>
                <div className="relative w-8 h-8 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
                  <span className="font-bold text-xs">AM</span>
                </div>
              </div>
              <span className="font-medium text-base">AffiliateMarketing</span>
            </div>

            <div className="flex gap-6">
              <Link href="#" className="text-white/60 hover:text-white transition-colors duration-300">
                Instagram
              </Link>
              <Link href="#" className="text-white/60 hover:text-white transition-colors duration-300">
                LinkedIn
              </Link>
              <Link href="#" className="text-white/60 hover:text-white transition-colors duration-300">
                Twitter
              </Link>
              <Link href="#" className="text-white/60 hover:text-white transition-colors duration-300">
                YouTube
              </Link>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center">
            <p className="text-white/40 text-sm mb-4 md:mb-0">
              © {new Date().getFullYear()} AffiliateMarketing.com. All rights reserved.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="text-white/60 hover:text-white text-sm transition-colors duration-300">
                Privacy Policy
              </Link>
              <Link href="#" className="text-white/60 hover:text-white text-sm transition-colors duration-300">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating Action Button */}
      <FloatingActionButton />

      {/* Cookie Consent Banner */}
      <CookieConsent />
    </div>
  )
}

