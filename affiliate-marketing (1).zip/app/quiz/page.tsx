"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Circle,
  Sparkles,
  Target,
  TrendingUp,
  Zap,
  DollarSign,
  Users,
  BarChart3,
  Award,
  Rocket,
  Lock,
} from "lucide-react"
import {
  Globe,
  Heart,
  Settings,
  RefreshCcw,
  Layers,
  ShoppingCart,
  Building,
  Briefcase,
  SquareSplitVerticalIcon as SplitSquare,
  FileText,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import AffiliateMarketingLogo from "@/components/affiliate-marketing-logo"
import QuizProgressIndicator from "@/components/quiz-progress-indicator"
import { cn } from "@/lib/utils"
import QuizResult from "@/components/quiz-result"

// Quiz questions and options
const quizData = [
  {
    id: "archetype",
    question: "What's your affiliate marketing archetype?",
    options: [
      {
        id: "strategist",
        label: "The Data-Driven Strategist",
        description: "You thrive on analytics and optimization, making decisions based on metrics and performance data",
        icon: BarChart3,
      },
      {
        id: "creator",
        label: "The Authentic Content Creator",
        description: "You build trust through high-quality content that genuinely helps your audience solve problems",
        icon: Sparkles,
      },
      {
        id: "innovator",
        label: "The Market Disruptor",
        description: "You find untapped niches and opportunities that others miss, staying ahead of market trends",
        icon: Zap,
      },
      {
        id: "connector",
        label: "The Relationship Builder",
        description: "You excel at building networks and partnerships that create win-win opportunities",
        icon: Users,
      },
    ],
  },
  {
    id: "challenge",
    question: "What's your biggest revenue bottleneck right now?",
    options: [
      {
        id: "traffic_quality",
        label: "Traffic Quality & Conversion",
        description: "You're getting traffic, but it's not converting at the rate you need for sustainable growth",
        icon: Target,
      },
      {
        id: "scaling_barriers",
        label: "Scaling Beyond Plateaus",
        description: "You've found what works, but hit walls when trying to scale to the next revenue level",
        icon: TrendingUp,
      },
      {
        id: "market_saturation",
        label: "Market Saturation & Competition",
        description: "Your niche is becoming crowded, with diminishing returns on your marketing efforts",
        icon: Users,
      },
      {
        id: "attribution_complexity",
        label: "Attribution & Tracking Complexity",
        description: "You struggle to accurately track performance across multiple channels and touchpoints",
        icon: BarChart3,
      },
    ],
  },
  {
    id: "approach",
    question: "Which approach resonates most with your affiliate strategy?",
    options: [
      {
        id: "omnichannel",
        label: "Omnichannel Ecosystem Builder",
        description: "Creating seamless experiences across multiple platforms and touchpoints",
        icon: Globe,
      },
      {
        id: "authority",
        label: "Authority Positioning Expert",
        description: "Establishing yourself as the go-to expert in your specific niche",
        icon: Award,
      },
      {
        id: "automation",
        label: "Automation & Systems Architect",
        description: "Building scalable systems that generate revenue with minimal ongoing effort",
        icon: Settings,
      },
      {
        id: "community",
        label: "Community & Network Cultivator",
        description: "Fostering engaged communities that drive organic growth and loyalty",
        icon: Heart,
      },
    ],
  },
  {
    id: "monetization",
    question: "Which monetization model has the most untapped potential for you?",
    options: [
      {
        id: "high_ticket",
        label: "High-Ticket Affiliate Partnerships",
        description: "Fewer sales of premium offers with commissions of $1,000+ per conversion",
        icon: DollarSign,
      },
      {
        id: "recurring",
        label: "Recurring Revenue Subscriptions",
        description: "Stable, predictable income from subscription-based affiliate programs",
        icon: RefreshCcw,
      },
      {
        id: "hybrid",
        label: "Hybrid Affiliate-Creator Model",
        description: "Combining affiliate offers with your own digital products and services",
        icon: Layers,
      },
      {
        id: "marketplace",
        label: "Marketplace & Platform Ecosystems",
        description: "Building multi-vendor platforms where you earn from multiple revenue streams",
        icon: ShoppingCart,
      },
    ],
  },
  {
    id: "growth_stage",
    question: "What's your current affiliate business growth stage?",
    options: [
      {
        id: "foundation",
        label: "Foundation Building",
        description: "Establishing your systems, niche, and initial traffic sources ($0-5K/month)",
        icon: Building,
      },
      {
        id: "acceleration",
        label: "Acceleration Phase",
        description: "Scaling what works and optimizing conversion paths ($5K-25K/month)",
        icon: Rocket,
      },
      {
        id: "expansion",
        label: "Expansion & Diversification",
        description: "Expanding to new markets and multiple revenue streams ($25K-100K/month)",
        icon: TrendingUp,
      },
      {
        id: "enterprise",
        label: "Enterprise & Acquisition",
        description: "Building systems for eventual exit or passive ownership ($100K+/month)",
        icon: Briefcase,
      },
    ],
  },
  {
    id: "tech_stack",
    question: "Which technology stack element needs the most improvement?",
    options: [
      {
        id: "analytics",
        label: "Advanced Attribution & Analytics",
        description: "Multi-touch attribution models that reveal true customer journeys and ROI",
        icon: BarChart3,
      },
      {
        id: "automation",
        label: "Marketing Automation & Segmentation",
        description: "Sophisticated automation flows that nurture prospects through your funnel",
        icon: Zap,
      },
      {
        id: "testing",
        label: "Conversion Testing Infrastructure",
        description: "Systems for rapidly testing and optimizing landing pages and offers",
        icon: SplitSquare,
      },
      {
        id: "content",
        label: "Content Creation & Distribution",
        description: "Tools and processes for scaling high-quality content production",
        icon: FileText,
      },
    ],
  },
]

export default function QuizPage() {
  const [step, setStep] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [userInfo, setUserInfo] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
  })
  const [completed, setCompleted] = useState(false)
  const [loading, setLoading] = useState(false)

  const totalSteps = quizData.length + 1 // +1 for the user info step
  const progress = ((step + 1) / totalSteps) * 100

  const currentQuestion = step < quizData.length ? quizData[step] : null

  const handleOptionSelect = (questionId: string, optionId: string) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: optionId,
    }))
  }

  const handleNext = () => {
    if (step < quizData.length) {
      setStep(step + 1)
      window.scrollTo(0, 0)
    } else {
      handleSubmit()
    }
  }

  const handlePrevious = () => {
    if (step > 0) {
      setStep(step - 1)
      window.scrollTo(0, 0)
    }
  }

  const handleSubmit = () => {
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      setLoading(false)
      setCompleted(true)
    }, 1500)
  }

  const isLastStep = step === quizData.length
  const canProceed = isLastStep ? userInfo.firstName && userInfo.email : currentQuestion && answers[currentQuestion.id]

  if (completed) {
    return <QuizResult answers={answers} userInfo={userInfo} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-950 via-slate-950 to-slate-900 text-white flex flex-col">
      <div className="container max-w-4xl mx-auto px-4 py-4 md:py-12 flex flex-col flex-1">
        <div className="flex justify-center mb-4 md:mb-8">
          <AffiliateMarketingLogo size="lg" animated className="h-12 md:h-auto text-cyan-400" />
        </div>

        <div className="mb-6 md:mb-8">
          <div className="flex justify-between items-center mb-3">
            <h1 className="text-xl md:text-2xl font-bold text-cyan-50">Affiliate Success Quiz</h1>
            <span className="text-xs md:text-sm font-medium text-cyan-100/80">
              Step {step + 1} of {totalSteps}
            </span>
          </div>

          {/* Enhanced progress indicator */}
          <QuizProgressIndicator
            steps={totalSteps}
            currentStep={step}
            labels={["Archetype", "Challenge", "Approach", "Monetization", "Growth", "Tech Stack", "Details"]}
          />
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="flex-1 flex flex-col"
          >
            <Card className="bg-slate-900/80 border-slate-700/50 backdrop-blur-sm rounded-xl shadow-2xl shadow-indigo-950/30 hover:shadow-cyan-900/20 transition-all duration-300 flex-1 flex flex-col">
              <CardContent className="p-3 md:p-6 lg:p-8 flex flex-col flex-1 justify-between">
                {!isLastStep ? (
                  <>
                    <h2 className="text-lg md:text-2xl font-bold mb-3 md:mb-6 text-cyan-50">
                      {currentQuestion?.question}
                    </h2>
                    <div className="space-y-2 md:space-y-4 flex-1 overflow-y-auto">
                      {currentQuestion?.options.map((option) => (
                        <div
                          key={option.id}
                          className={cn(
                            "relative rounded-lg border-2 p-2 md:p-4 cursor-pointer transition-all duration-200",
                            answers[currentQuestion.id] === option.id
                              ? "border-cyan-400 bg-gradient-to-br from-slate-800/90 to-slate-800/70 shadow-inner shadow-cyan-900/30"
                              : "border-slate-700/70 hover:border-slate-600 hover:bg-slate-800/40 hover:shadow-md",
                          )}
                          onClick={() => handleOptionSelect(currentQuestion.id, option.id)}
                        >
                          <div className="flex items-start gap-2 md:gap-4">
                            <div
                              className={cn(
                                "flex-shrink-0 w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center",
                                answers[currentQuestion.id] === option.id
                                  ? "bg-gradient-to-r from-cyan-400 to-blue-500 shadow-md shadow-cyan-900/50"
                                  : "bg-slate-800",
                              )}
                            >
                              <option.icon
                                className={cn(
                                  "h-4 w-4 md:h-5 md:w-5",
                                  answers[currentQuestion.id] === option.id ? "text-white" : "text-cyan-300",
                                )}
                              />
                            </div>
                            <div className="flex-1">
                              <div className="flex justify-between">
                                <h3 className="font-medium text-sm md:text-lg text-cyan-50">{option.label}</h3>
                                <div>
                                  {answers[currentQuestion.id] === option.id ? (
                                    <CheckCircle2 className="h-4 w-4 md:h-5 md:w-5 text-cyan-400" />
                                  ) : (
                                    <Circle className="h-4 w-4 md:h-5 md:w-5 text-slate-500" />
                                  )}
                                </div>
                              </div>
                              <p className="text-cyan-100/80 text-xs md:text-sm mt-0.5 md:mt-1">{option.description}</p>
                            </div>
                          </div>

                          {/* Selection animation */}
                          {answers[currentQuestion.id] === option.id && (
                            <motion.div
                              className="absolute inset-0 rounded-lg border-2 border-cyan-400 pointer-events-none"
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              layoutId="selectedOption"
                            />
                          )}
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <>
                    <h2 className="text-lg md:text-2xl font-bold mb-3 md:mb-6 text-cyan-50">
                      Almost there! Tell us where to send your strategy
                    </h2>
                    <div className="space-y-3 md:space-y-4 flex-1">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                        <div className="space-y-1 md:space-y-2">
                          <Label htmlFor="firstName" className="text-cyan-100 text-xs md:text-sm">
                            First Name *
                          </Label>
                          <Input
                            id="firstName"
                            value={userInfo.firstName}
                            onChange={(e) => setUserInfo({ ...userInfo, firstName: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white h-8 md:h-10 text-sm focus:border-cyan-400 focus:ring-cyan-400/20"
                            placeholder="Your first name"
                          />
                        </div>
                        <div className="space-y-1 md:space-y-2">
                          <Label htmlFor="lastName" className="text-cyan-100 text-xs md:text-sm">
                            Last Name
                          </Label>
                          <Input
                            id="lastName"
                            value={userInfo.lastName}
                            onChange={(e) => setUserInfo({ ...userInfo, lastName: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white h-8 md:h-10 text-sm focus:border-cyan-400 focus:ring-cyan-400/20"
                            placeholder="Your last name"
                          />
                        </div>
                      </div>
                      <div className="space-y-1 md:space-y-2">
                        <Label htmlFor="email" className="text-cyan-100 text-xs md:text-sm">
                          Email Address *
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          value={userInfo.email}
                          onChange={(e) => setUserInfo({ ...userInfo, email: e.target.value })}
                          className="bg-slate-800 border-slate-700 text-white h-8 md:h-10 text-sm focus:border-cyan-400 focus:ring-cyan-400/20"
                          placeholder="you@example.com"
                        />
                      </div>
                      <div className="space-y-1 md:space-y-2">
                        <Label htmlFor="phone" className="text-cyan-100 text-xs md:text-sm">
                          Phone Number
                        </Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={userInfo.phone}
                          onChange={(e) => setUserInfo({ ...userInfo, phone: e.target.value })}
                          className="bg-slate-800 border-slate-700 text-white h-8 md:h-10 text-sm focus:border-cyan-400 focus:ring-cyan-400/20"
                          placeholder="Your phone number"
                        />
                        <p className="text-xs text-cyan-200/60 flex items-center mt-1 md:mt-2">
                          <Lock className="h-2.5 w-2.5 md:h-3 md:w-3 mr-1" /> Your information is secure and will never
                          be shared
                        </p>
                      </div>
                    </div>
                  </>
                )}

                <div className="flex justify-between mt-4 md:mt-8">
                  <Button
                    variant="outline"
                    onClick={handlePrevious}
                    disabled={step === 0}
                    className="border-slate-700/70 text-cyan-100 hover:bg-slate-800 hover:text-cyan-50 text-xs md:text-sm py-1.5 h-auto disabled:opacity-50 disabled:pointer-events-none"
                  >
                    <ArrowLeft className="mr-1 md:mr-2 h-3 w-3 md:h-4 md:w-4" />
                    Back
                  </Button>
                  <Button
                    onClick={handleNext}
                    disabled={!canProceed || loading}
                    className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:opacity-90 hover:shadow-lg hover:shadow-cyan-900/20 transition-all duration-300 text-xs md:text-sm py-1.5 h-auto disabled:opacity-50 disabled:pointer-events-none"
                  >
                    {loading ? (
                      <div className="flex items-center">
                        <div className="h-3 w-3 md:h-4 md:w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-1 md:mr-2"></div>
                        Processing...
                      </div>
                    ) : (
                      <>
                        {isLastStep ? "Get My Strategy" : "Continue"}
                        <ArrowRight className="ml-1 md:ml-2 h-3 w-3 md:h-4 md:w-4" />
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        <div className="mt-4 md:mt-8 text-center text-xs md:text-sm text-cyan-200/60">
          <p>Your answers help us create a personalized affiliate marketing strategy just for you.</p>
        </div>
      </div>
    </div>
  )
}

