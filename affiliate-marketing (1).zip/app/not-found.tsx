"use client"

import Link from "next/link"
import { Search, Home, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 bg-background">
      <div className="max-w-md w-full mx-auto text-center">
        <div className="relative mb-8">
          <div className="text-[10rem] font-bold leading-none tracking-tighter text-primary/10">404</div>
          <div className="absolute inset-0 flex items-center justify-center">
            <Search className="h-24 w-24 text-primary/40" />
          </div>
        </div>

        <h1 className="text-3xl font-bold mb-2">Page not found</h1>

        <p className="text-muted-foreground mb-8">
          Sorry, we couldn't find the page you're looking for. It might have been moved, deleted, or never existed.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button asChild variant="default" className="gap-2">
            <Link href="/">
              <Home className="h-4 w-4" />
              Go to homepage
            </Link>
          </Button>

          <Button variant="outline" onClick={() => window.history.back()} className="gap-2">
            <ArrowLeft className="h-4 w-4" />
            Go back
          </Button>
        </div>

        <div className="mt-12 border-t border-border pt-6">
          <p className="text-sm text-muted-foreground">
            Looking for something specific? Try searching or check out our{" "}
            <Link href="/sitemap" className="text-primary hover:underline">
              sitemap
            </Link>
            .
          </p>
        </div>
      </div>
    </div>
  )
}

