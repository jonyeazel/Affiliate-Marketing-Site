import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { originalUrl, programId, productName, enableTracking, enableUtm } = body

    // In a real application, this would:
    // 1. Validate the user is authorized to create links for this program
    // 2. Generate a unique tracking ID
    // 3. Store the link in a database
    // 4. Return the generated link

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Generate a simplified link for demonstration
    const baseUrl = "https://afflink.com"
    const trackingId = enableTracking ? `&t=${Date.now()}` : ""
    const utmParams = enableUtm ? "&utm_source=affiliate&utm_medium=link&utm_campaign=product" : ""

    const generatedUrl = `${baseUrl}/${programId}?url=${encodeURIComponent(originalUrl)}${trackingId}${utmParams}`

    return NextResponse.json({
      success: true,
      link: generatedUrl,
      id: `link_${Date.now()}`,
      createdAt: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error generating link:", error)
    return NextResponse.json({ success: false, error: "Failed to generate link" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  // In a real application, this would fetch the user's links from a database

  // Simulate processing time
  await new Promise((resolve) => setTimeout(resolve, 300))

  // Sample data
  const links = [
    {
      id: "link_1",
      originalUrl: "https://techgadgets.com/products/wireless-headphones",
      shortUrl:
        "https://afflink.com/techgadgetspro?url=https%3A%2F%2Ftechgadgets.com%2Fproducts%2Fwireless-headphones&t=123456",
      programId: "techgadgetspro",
      programName: "TechGadgets Pro",
      clicks: 124,
      conversions: 6,
      revenue: 86.45,
      createdAt: "2025-03-15T10:30:00Z",
    },
    {
      id: "link_2",
      originalUrl: "https://fitnesspro.com/programs/home-workout",
      shortUrl: "https://afflink.com/fitnesspro?url=https%3A%2F%2Ffitnesspro.com%2Fprograms%2Fhome-workout&t=234567",
      programId: "fitnesspro",
      programName: "FitnessPro",
      clicks: 98,
      conversions: 8,
      revenue: 120.0,
      createdAt: "2025-03-14T15:45:00Z",
    },
    {
      id: "link_3",
      originalUrl: "https://homeessentials.com/kitchen/smart-appliances",
      shortUrl:
        "https://afflink.com/homeessentials?url=https%3A%2F%2Fhomeessentials.com%2Fkitchen%2Fsmart-appliances&t=345678",
      programId: "homeessentials",
      programName: "HomeEssentials",
      clicks: 76,
      conversions: 3,
      revenue: 64.8,
      createdAt: "2025-03-12T09:15:00Z",
    },
  ]

  return NextResponse.json({ success: true, links })
}

