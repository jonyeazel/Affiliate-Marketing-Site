import { NextResponse } from "next/server"

export async function GET(request: Request) {
  // In a real application, this would fetch the user's programs from a database

  // Simulate processing time
  await new Promise((resolve) => setTimeout(resolve, 300))

  // Sample data
  const programs = {
    active: [
      {
        id: "prog_1",
        name: "TechGadgets Pro",
        category: "Electronics",
        logo: "/placeholder.svg?height=48&width=48",
        commissionRate: "15%",
        cookieDuration: "45 days",
        status: "active",
        performance: {
          revenue: 845.32,
          clicks: 1245,
          conversions: 62,
          conversionRate: 4.98,
          growth: 12,
        },
        joinedAt: "2024-12-10T14:30:00Z",
      },
      {
        id: "prog_2",
        name: "FitnessPro",
        category: "Health & Fitness",
        logo: "/placeholder.svg?height=48&width=48",
        commissionRate: "20%",
        cookieDuration: "60 days",
        status: "active",
        performance: {
          revenue: 632.45,
          clicks: 986,
          conversions: 42,
          conversionRate: 4.26,
          growth: 24,
        },
        joinedAt: "2025-01-05T10:15:00Z",
      },
      {
        id: "prog_3",
        name: "HomeEssentials",
        category: "Home & Lifestyle",
        logo: "/placeholder.svg?height=48&width=48",
        commissionRate: "12%",
        cookieDuration: "30 days",
        status: "active",
        performance: {
          revenue: 421.87,
          clicks: 754,
          conversions: 29,
          conversionRate: 3.85,
          growth: 8,
        },
        joinedAt: "2025-01-20T16:45:00Z",
      },
    ],
    pending: [
      {
        id: "prog_4",
        name: "DigitalTools Pro",
        category: "Software & SaaS",
        logo: "/placeholder.svg?height=48&width=48",
        commissionRate: "Up to 30%",
        cookieDuration: "90 days",
        status: "pending",
        appliedAt: "2025-03-13T11:30:00Z",
      },
      {
        id: "prog_5",
        name: "StyleHub",
        category: "Fashion & Accessories",
        logo: "/placeholder.svg?height=48&width=48",
        commissionRate: "12-18%",
        cookieDuration: "30 days",
        status: "pending_info",
        appliedAt: "2025-03-10T09:45:00Z",
      },
      {
        id: "prog_6",
        name: "TravelEscape",
        category: "Travel & Leisure",
        logo: "/placeholder.svg?height=48&width=48",
        commissionRate: "Up to 12%",
        cookieDuration: "60 days",
        status: "pending",
        appliedAt: "2025-03-14T14:20:00Z",
      },
    ],
    inactive: [
      {
        id: "prog_7",
        name: "GadgetWorld",
        category: "Electronics",
        logo: "/placeholder.svg?height=48&width=48",
        commissionRate: "10-12%",
        cookieDuration: "30 days",
        status: "discontinued",
        inactiveSince: "2025-01-15T00:00:00Z",
      },
      {
        id: "prog_8",
        name: "BeautyEssentials",
        category: "Beauty & Skincare",
        logo: "/placeholder.svg?height=48&width=48",
        commissionRate: "15-25%",
        cookieDuration: "45 days",
        status: "paused",
        inactiveSince: "2025-02-10T00:00:00Z",
      },
    ],
  }

  return NextResponse.json({ success: true, programs })
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { programId, applicationData } = body

    // In a real application, this would:
    // 1. Validate the application data
    // 2. Submit the application to the program
    // 3. Store the application in a database
    // 4. Return the application status

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return NextResponse.json({
      success: true,
      application: {
        id: `app_${Date.now()}`,
        programId,
        status: "pending",
        submittedAt: new Date().toISOString(),
        estimatedReviewTime: "24-48 hours",
      },
    })
  } catch (error) {
    console.error("Error submitting application:", error)
    return NextResponse.json({ success: false, error: "Failed to submit application" }, { status: 500 })
  }
}

