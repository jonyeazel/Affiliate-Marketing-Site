"use client"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowLeft, DollarSign, CreditCard, Wallet, Bitcoin, CheckCircle, Clock, Zap, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function InstantPayoutPage() {
  const [payoutMethod, setPayoutMethod] = useState("bank")
  const [payoutAmount, setPayoutAmount] = useState("1289.45")
  const [processingFee, setProcessingFee] = useState(25.79)
  const [payoutComplete, setPayoutComplete] = useState(false)

  const handlePayout = () => {
    // Simulate processing
    setPayoutComplete(true)
  }

  const pendingPayouts = [
    {
      id: "1",
      platform: "Amazon Associates",
      logo: "/placeholder.svg?height=40&width=40",
      amount: 432.19,
      dueDate: "Apr 15, 2025",
      category: "Tech",
    },
    {
      id: "2",
      platform: "Shopify Partners",
      logo: "/placeholder.svg?height=40&width=40",
      amount: 289.45,
      dueDate: "Apr 22, 2025",
      category: "Beauty",
    },
    {
      id: "3",
      platform: "TikTok Shop",
      logo: "/placeholder.svg?height=40&width=40",
      amount: 567.81,
      dueDate: "May 5, 2025",
      category: "Fashion",
    },
  ]

  if (payoutComplete) {
    return (
      <div className="min-h-screen bg-black text-white">
        <div className="container max-w-md py-12">
          <Link href="/dashboard" className="inline-flex items-center text-white/60 hover:text-white mb-8">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Link>

          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="bg-[#111111] border-white/10">
              <CardContent className="pt-6 text-center">
                <div className="mb-6 mx-auto w-16 h-16 rounded-full bg-[#00FFFF]/20 flex items-center justify-center">
                  <CheckCircle className="h-8 w-8 text-[#00FFFF]" />
                </div>

                <h1 className="text-2xl font-bold mb-2">Payout Successful!</h1>
                <p className="text-white/60 mb-6">Your funds are on their way to your account</p>

                <div className="bg-[#191919] rounded-lg p-4 mb-6">
                  <div className="text-white/60 mb-1">Amount</div>
                  <div className="text-3xl font-bold text-[#00FFFF]">
                    ${(Number.parseFloat(payoutAmount) - processingFee).toFixed(2)}
                  </div>
                </div>

                <div className="space-y-4 text-left mb-6">
                  <div className="flex justify-between">
                    <span className="text-white/60">Payout method</span>
                    <span className="font-medium">
                      {payoutMethod === "bank" && "Bank Account"}
                      {payoutMethod === "paypal" && "PayPal"}
                      {payoutMethod === "crypto" && "Cryptocurrency"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Transaction ID</span>
                    <span className="font-medium">MD{Math.floor(Math.random() * 1000000)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Processing time</span>
                    <span className="font-medium">Instant</span>
                  </div>
                </div>

                <Button className="w-full bg-white text-black font-bold" asChild>
                  <Link href="/dashboard">Return to Dashboard</Link>
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="container max-w-md py-12">
        <Link href="/dashboard" className="inline-flex items-center text-white/60 hover:text-white mb-8">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Link>

        <Card className="bg-[#111111] border-white/10">
          <CardHeader>
            <CardTitle>Instant Payout</CardTitle>
            <CardDescription className="text-white/60">Get your earnings now, no waiting period</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <Label className="text-white/80">Available Balance</Label>
                <div className="mt-1 relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-white/40" />
                  <Input
                    value={payoutAmount}
                    onChange={(e) => {
                      setPayoutAmount(e.target.value)
                      setProcessingFee(Number.parseFloat(e.target.value) * 0.02)
                    }}
                    className="pl-10 bg-[#191919] border-white/10 text-xl font-bold text-white"
                  />
                </div>
                <div className="mt-1 text-sm text-white/60 flex justify-between">
                  <span>Available: $1,289.45</span>
                  <button className="text-[#00FFFF]" onClick={() => setPayoutAmount("1289.45")}>
                    Max
                  </button>
                </div>
              </div>

              <div>
                <Label className="text-white/80">Payout Method</Label>
                <RadioGroup
                  value={payoutMethod}
                  onValueChange={setPayoutMethod}
                  className="mt-2 grid grid-cols-3 gap-3"
                >
                  <div>
                    <RadioGroupItem value="bank" id="bank" className="peer sr-only" />
                    <Label
                      htmlFor="bank"
                      className="flex flex-col items-center justify-between rounded-md border-2 border-white/10 bg-[#191919] p-4 hover:bg-[#222222] hover:border-white/20 peer-data-[state=checked]:border-[#00FFFF] peer-data-[state=checked]:bg-[#00FFFF]/10 cursor-pointer"
                    >
                      <CreditCard className="mb-2 h-6 w-6" />
                      <span className="text-sm">Bank</span>
                    </Label>
                  </div>

                  <div>
                    <RadioGroupItem value="paypal" id="paypal" className="peer sr-only" />
                    <Label
                      htmlFor="paypal"
                      className="flex flex-col items-center justify-between rounded-md border-2 border-white/10 bg-[#191919] p-4 hover:bg-[#222222] hover:border-white/20 peer-data-[state=checked]:border-[#00FFFF] peer-data-[state=checked]:bg-[#00FFFF]/10 cursor-pointer"
                    >
                      <Wallet className="mb-2 h-6 w-6" />
                      <span className="text-sm">PayPal</span>
                    </Label>
                  </div>

                  <div>
                    <RadioGroupItem value="crypto" id="crypto" className="peer sr-only" />
                    <Label
                      htmlFor="crypto"
                      className="flex flex-col items-center justify-between rounded-md border-2 border-white/10 bg-[#191919] p-4 hover:bg-[#222222] hover:border-white/20 peer-data-[state=checked]:border-[#00FFFF] peer-data-[state=checked]:bg-[#00FFFF]/10 cursor-pointer"
                    >
                      <Bitcoin className="mb-2 h-6 w-6" />
                      <span className="text-sm">Crypto</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="bg-[#191919] rounded-lg p-4">
                <div className="flex justify-between mb-2">
                  <span className="text-white/60">Amount</span>
                  <span>${payoutAmount}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/60">Processing fee (2%)</span>
                  <span className="text-[#FF00FF]">-${processingFee.toFixed(2)}</span>
                </div>
                <div className="border-t border-white/10 my-2 pt-2 flex justify-between">
                  <span className="font-medium">You'll receive</span>
                  <span className="font-bold">${(Number.parseFloat(payoutAmount) - processingFee).toFixed(2)}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm text-white/60 bg-[#00FFFF]/10 p-3 rounded-md">
                <Shield className="h-4 w-4 text-[#00FFFF]" />
                <span>Your payout is protected and guaranteed by moneydrip</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            <Button
              className="w-full bg-gradient-to-r from-[#00FFFF] to-[#FF00FF] text-black font-bold"
              onClick={handlePayout}
            >
              <Zap className="mr-2 h-4 w-4" />
              Get Paid Now
            </Button>
            <div className="text-xs text-white/40 text-center">
              By proceeding, you agree to our Terms of Service and Payout Policy
            </div>
          </CardFooter>
        </Card>

        <div className="mt-8">
          <h2 className="text-xl font-bold mb-4">Pending Payouts</h2>
          <div className="space-y-3">
            {pendingPayouts.map((payout) => (
              <Card key={payout.id} className="bg-[#111111] border-white/10">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10 mr-3">
                        <AvatarImage src={payout.logo} alt={payout.platform} />
                        <AvatarFallback>{payout.platform.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{payout.platform}</div>
                        <div className="text-xs text-white/60">{payout.category} category</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-lg">${payout.amount}</div>
                      <div className="flex items-center text-xs text-white/60">
                        <Clock className="mr-1 h-3 w-3" />
                        Due {payout.dueDate}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 flex justify-between items-center">
                    <Badge className="bg-[#191919] text-white/60 border-none">
                      Fee: ${(payout.amount * 0.02).toFixed(2)}
                    </Badge>
                    <Button size="sm" className="h-8 bg-[#00FFFF] text-black font-medium">
                      <Zap className="mr-1 h-3 w-3" />
                      Get Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

