"use client"

import { useState, useEffect } from "react"
import { LineChart, BarChart, PieChart, TrendingUp, Zap, BarChart3, DollarSign, Calendar, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import MarketTrendsChart from "@/components/market-intelligence/market-trends-chart"
import NicheOpportunityMap from "@/components/market-intelligence/niche-opportunity-map"
import CompetitiveAnalysisTable from "@/components/market-intelligence/competitive-analysis-table"

export default function MarketIntelligencePage() {
  const [analyticsData, setAnalyticsData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("/api/analytics")
        const data = await response.json()
        setAnalyticsData(data)
        setIsLoading(false)
      } catch (error) {
        console.error("Error fetching analytics data:", error)
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  return (
    <div className="bg-background">
      <div className="container py-12 md:py-24">
        <div className="mx-auto max-w-3xl text-center mb-16">
          <Badge className="mb-4" variant="secondary">
            Market Intelligence
          </Badge>
          <h1 className="mb-4 text-3xl font-bold sm:text-4xl md:text-5xl">Data-Driven Affiliate Marketing Insights</h1>
          <p className="text-muted-foreground md:text-xl">
            Exclusive market intelligence to help you identify opportunities and optimize your strategy.
          </p>
        </div>

        <Tabs defaultValue="market-trends" className="w-full">
          <div className="flex justify-center mb-8">
            <TabsList className="grid w-full max-w-2xl grid-cols-3">
              <TabsTrigger value="market-trends">
                <LineChart className="mr-2 h-4 w-4" />
                Market Trends
              </TabsTrigger>
              <TabsTrigger value="niche-opportunities">
                <Zap className="mr-2 h-4 w-4" />
                Niche Opportunities
              </TabsTrigger>
              <TabsTrigger value="competitive-analysis">
                <BarChart3 className="mr-2 h-4 w-4" />
                Competitive Analysis
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="market-trends">
            <div className="grid gap-6 md:grid-cols-3 mb-8">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg. Commission Rate</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {isLoading ? "Loading..." : `${analyticsData?.industryBenchmarks.averageCommissionRate}%`}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-500 inline-flex items-center">
                      +0.8% <TrendingUp className="h-3 w-3 ml-1" />
                    </span>{" "}
                    from last quarter
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg. Conversion Rate</CardTitle>
                  <BarChart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {isLoading ? "Loading..." : `${analyticsData?.industryBenchmarks.averageConversionRate}%`}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-500 inline-flex items-center">
                      +0.3% <TrendingUp className="h-3 w-3 ml-1" />
                    </span>{" "}
                    from last quarter
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg. Cookie Duration</CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {isLoading ? "Loading..." : `${analyticsData?.industryBenchmarks.averageCookieDuration} days`}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-red-500 inline-flex items-center">
                      -2 days <TrendingUp className="h-3 w-3 ml-1 rotate-180" />
                    </span>{" "}
                    from last quarter
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 md:grid-cols-2 mb-8">
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Commission Rate Trends</CardTitle>
                  <CardDescription>Average commission rates across top industries over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[350px]">
                    {isLoading ? (
                      <div className="h-full flex items-center justify-center">
                        <p>Loading chart data...</p>
                      </div>
                    ) : (
                      <MarketTrendsChart data={analyticsData?.marketTrends.commissionTrends} />
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Top Performing Niches</CardTitle>
                  <CardDescription>Niches with highest growth and commission rates</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <p>Loading data...</p>
                  ) : (
                    <div className="space-y-4">
                      {analyticsData?.marketTrends.topNiches.map((niche, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="font-medium">{niche.name}</div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-sm">
                              <span className="text-green-500">+{niche.growth}%</span> growth
                            </div>
                            <div className="text-sm font-medium">{niche.avgCommission}% commission</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Top Performing Channels</CardTitle>
                  <CardDescription>Distribution of affiliate marketing revenue by channel</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    {isLoading ? (
                      <div className="h-full flex items-center justify-center">
                        <p>Loading chart data...</p>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <PieChart className="h-24 w-24 text-muted-foreground/50" />
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="niche-opportunities">
            <div className="grid gap-6 md:grid-cols-2 mb-8">
              <Card className="md:col-span-2">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <CardTitle>Niche Opportunity Map</CardTitle>
                      <CardDescription>Visualize growth potential vs. competition across niches</CardDescription>
                    </div>
                    <Select defaultValue="all">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Filter by category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        <SelectItem value="tech">Technology</SelectItem>
                        <SelectItem value="health">Health & Wellness</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="lifestyle">Lifestyle</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="h-[400px]">
                    {isLoading ? (
                      <div className="h-full flex items-center justify-center">
                        <p>Loading opportunity map...</p>
                      </div>
                    ) : (
                      <NicheOpportunityMap />
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 md:grid-cols-2 mb-8">
              <Card>
                <CardHeader>
                  <CardTitle>Emerging Niches</CardTitle>
                  <CardDescription>Fast-growing niches with high potential</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <p>Loading data...</p>
                  ) : (
                    <div className="space-y-4">
                      {analyticsData?.predictiveInsights.emergingNiches.map((niche, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="font-medium">{niche.name}</div>
                            {niche.potential === "High" && (
                              <Badge variant="secondary" className="bg-green-500/10 text-green-500">
                                High Potential
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="text-sm text-green-500">+{niche.growth}% growth</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    Download Full Report
                  </Button>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Seasonal Opportunities</CardTitle>
                  <CardDescription>Upcoming seasonal affiliate marketing opportunities</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <p>Loading data...</p>
                  ) : (
                    <div className="space-y-4">
                      {analyticsData?.predictiveInsights.seasonalOpportunities.map((season, index) => (
                        <div key={index} className="space-y-2">
                          <div className="font-medium">{season.season}</div>
                          <div className="flex flex-wrap gap-2">
                            {season.categories.map((category, catIndex) => (
                              <Badge key={catIndex} variant="outline">
                                {category}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    View Seasonal Calendar
                  </Button>
                </CardFooter>
              </Card>
            </div>

            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Opportunity Alerts</CardTitle>
                <CardDescription>Personalized opportunities based on your profile and interests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-lg border bg-card p-4">
                    <div className="flex items-start gap-4">
                      <div className="rounded-full bg-primary/10 p-2">
                        <Zap className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">Remote Work Tools - High Growth Opportunity</h3>
                        <p className="text-sm text-muted-foreground mb-2">
                          Based on your profile, we've identified Remote Work Tools as a high-potential niche that
                          aligns with your expertise.
                        </p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="outline">38% Growth</Badge>
                          <Badge variant="outline">15.2% Avg Commission</Badge>
                          <Badge variant="outline">Low Competition</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="rounded-lg border bg-card p-4">
                    <div className="flex items-start gap-4">
                      <div className="rounded-full bg-primary/10 p-2">
                        <Calendar className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium mb-1">Back to School Season - 45 Days Until Peak</h3>
                        <p className="text-sm text-muted-foreground mb-2">
                          Now is the ideal time to prepare content for the upcoming Back to School season.
                        </p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="outline">Education</Badge>
                          <Badge variant="outline">Technology</Badge>
                          <Badge variant="outline">Office Supplies</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Set Up Custom Alerts</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="competitive-analysis">
            <div className="mb-8">
              <Card>
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <CardTitle>Competitive Analysis</CardTitle>
                      <CardDescription>Compare affiliate programs across key metrics</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Select defaultValue="tech">
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Select niche" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="tech">Technology</SelectItem>
                          <SelectItem value="health">Health & Wellness</SelectItem>
                          <SelectItem value="finance">Finance</SelectItem>
                          <SelectItem value="lifestyle">Lifestyle</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button variant="outline" size="icon">
                        <BarChart3 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CompetitiveAnalysisTable />
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 md:grid-cols-2 mb-8">
              <Card>
                <CardHeader>
                  <CardTitle>Commission Structure Analysis</CardTitle>
                  <CardDescription>Compare commission structures across programs</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center">
                    <BarChart className="h-24 w-24 text-muted-foreground/50" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Conversion Rate Comparison</CardTitle>
                  <CardDescription>Average conversion rates by program and category</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center">
                    <LineChart className="h-24 w-24 text-muted-foreground/50" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Program Evaluation Scorecard</CardTitle>
                <CardDescription>Comprehensive evaluation of affiliate programs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">TechGadgets Pro</div>
                      <div className="font-medium">87/100</div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Commission</div>
                        <div>9/10</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Cookie Duration</div>
                        <div>8/10</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Conversion Rate</div>
                        <div>9/10</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Support Quality</div>
                        <div>8/10</div>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">FitnessPro</div>
                      <div className="font-medium">82/100</div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Commission</div>
                        <div>8/10</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Cookie Duration</div>
                        <div>9/10</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Conversion Rate</div>
                        <div>7/10</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Support Quality</div>
                        <div>9/10</div>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">HomeEssentials</div>
                      <div className="font-medium">79/100</div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Commission</div>
                        <div>7/10</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Cookie Duration</div>
                        <div>7/10</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Conversion Rate</div>
                        <div>8/10</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Support Quality</div>
                        <div>8/10</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Generate Custom Scorecard
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-16">
          <Card className="bg-primary text-primary-foreground">
            <div className="grid md:grid-cols-2 gap-6">
              <CardContent className="pt-6 md:pt-10">
                <div className="space-y-4">
                  <h2 className="text-2xl font-bold">Unlock Premium Market Intelligence</h2>
                  <p className="text-primary-foreground/80">
                    Get access to our full suite of market intelligence tools, including custom reports, competitive
                    analysis, and predictive insights.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>Custom niche research reports</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>Competitive analysis tools</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>Predictive trend forecasting</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>Personalized opportunity alerts</span>
                    </li>
                  </ul>
                  <Button className="bg-background text-foreground hover:bg-background/90">Upgrade to Pro</Button>
                </div>
              </CardContent>
              <div className="hidden md:flex items-center justify-center p-6">
                <div className="w-full max-w-sm h-64 bg-primary-foreground/10 rounded-lg flex items-center justify-center">
                  <BarChart3 className="h-24 w-24 text-primary-foreground/30" />
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}

