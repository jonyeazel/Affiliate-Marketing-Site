import { Loader2 } from "lucide-react"

export default function Loading() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8 text-center bg-[#080810]">
      <div className="relative">
        <Loader2 className="h-16 w-16 text-[#00F0FF] animate-spin mb-6" />
        <div className="absolute inset-0 rounded-full bg-[#00F0FF]/20 animate-ping" />
      </div>
      <h2 className="text-2xl font-bold mb-4 text-white">
        Loading<span className="animate-pulse">...</span>
      </h2>
      <p className="text-white/70 max-w-md">Preparing your affiliate marketing experience</p>
      <div className="mt-8 w-64 h-1 bg-white/10 rounded-full overflow-hidden">
        <div className="h-full bg-gradient-to-r from-[#00F0FF] to-[#0033CC] animate-progress" />
      </div>
    </div>
  )
}

// Add this to your globals.css
// @keyframes progress {
//   0% { width: 0%; }
//   50% { width: 70%; }
//   100% { width: 100%; }
// }

