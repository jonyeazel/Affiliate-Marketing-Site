"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { ArrowRight, Check, DollarSign, Zap, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import MoneyDripLogo from "@/components/mobile/moneydrip-logo"

export default function LandingPage() {
  const [email, setEmail] = useState("")

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <div className="flex items-center justify-between h-16 px-4 border-b border-white/10">
        <MoneyDripLogo />
        <Button variant="outline" className="border-white/20" asChild>
          <Link href="/mobile/onboarding">Log In</Link>
        </Button>
      </div>

      <main className="flex-1 flex flex-col">
        <div className="px-4 py-10 text-center">
          <h1 className="text-4xl font-bold mb-4">
            Post. <span className="text-[#00CFCF]">Earn.</span> Get Paid <span className="text-[#00CFCF]">Today.</span>
          </h1>
          <p className="text-white/70 text-lg mb-8">The only affiliate platform that pays you instantly.</p>

          <div className="mb-10">
            <Button className="w-full bg-[#00CFCF] text-black font-bold text-lg py-6" asChild>
              <Link href="/mobile/onboarding">
                Start Earning Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>

        <div className="relative h-64 mb-10">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-64 h-64">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="absolute top-0 left-0 right-0 bg-[#111111] rounded-xl p-4 shadow-lg transform -rotate-6"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-10 w-10 rounded-full bg-[#222222]"></div>
                  <div>
                    <div className="h-4 w-32 bg-[#222222] rounded-full"></div>
                    <div className="h-3 w-20 bg-[#222222] rounded-full mt-1 opacity-60"></div>
                  </div>
                </div>
                <div className="h-24 bg-[#222222] rounded-lg mb-3"></div>
                <div className="flex justify-between items-center">
                  <div className="h-8 w-20 bg-[#222222] rounded-full"></div>
                  <div className="h-8 w-24 bg-[#00CFCF] rounded-full"></div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="absolute top-10 left-10 right-0 bg-[#111111] rounded-xl p-4 shadow-lg transform rotate-3"
              >
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-full bg-[#222222]"></div>
                    <div className="h-4 w-20 bg-[#222222] rounded-full"></div>
                  </div>
                  <div className="h-6 w-16 bg-[#00CFCF] rounded-full"></div>
                </div>
                <div className="h-4 w-full bg-[#222222] rounded-full mb-2"></div>
                <div className="h-4 w-3/4 bg-[#222222] rounded-full mb-2"></div>
                <div className="h-4 w-5/6 bg-[#222222] rounded-full mb-3"></div>
                <div className="h-20 bg-[#222222] rounded-lg"></div>
              </motion.div>
            </div>
          </div>
        </div>

        <div className="px-4 py-8 bg-[#111111]">
          <h2 className="text-2xl font-bold mb-6 text-center">How It Works</h2>

          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="h-10 w-10 rounded-full bg-[#00CFCF] flex items-center justify-center flex-shrink-0">
                <Check className="h-5 w-5 text-black" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Find Products That Match</h3>
                <p className="text-white/70">
                  We analyze your content and audience to find the perfect products for you to promote.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="h-10 w-10 rounded-full bg-[#00CFCF] flex items-center justify-center flex-shrink-0">
                <DollarSign className="h-5 w-5 text-black" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Share & Earn</h3>
                <p className="text-white/70">
                  Share your unique link with your audience and earn money when they purchase.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="h-10 w-10 rounded-full bg-[#00CFCF] flex items-center justify-center flex-shrink-0">
                <Zap className="h-5 w-5 text-black" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Get Paid Instantly</h3>
                <p className="text-white/70">No more waiting 30-90 days. Cash out your earnings whenever you want.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="px-4 py-10">
          <div className="bg-[#111111] rounded-xl p-6 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <Clock className="h-6 w-6 text-[#00CFCF]" />
              <h3 className="font-bold text-xl">Why Wait For Your Money?</h3>
            </div>
            <p className="text-white/70 mb-4">
              Traditional affiliate platforms make you wait 30-90 days to get paid. With MoneyDrip, you can cash out
              instantly.
            </p>
            <div className="flex items-center justify-between bg-[#191919] rounded-lg p-4">
              <div>
                <div className="text-sm text-white/60">Traditional</div>
                <div className="font-bold text-lg">30-90 Days</div>
              </div>
              <ArrowRight className="h-5 w-5 text-white/40" />
              <div>
                <div className="text-sm text-white/60">MoneyDrip</div>
                <div className="font-bold text-lg text-[#00CFCF]">Instant</div>
              </div>
            </div>
          </div>

          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2">Ready to Start Earning?</h2>
            <p className="text-white/70 mb-6">
              Join thousands of creators who are getting paid instantly for their influence.
            </p>

            <Button className="w-full bg-[#00CFCF] text-black font-bold text-lg py-6" asChild>
              <Link href="/mobile/onboarding">
                Start Earning Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </main>

      <footer className="px-4 py-6 border-t border-white/10 text-center text-white/40 text-sm">
        <p>© 2025 AffiliateMarketing.com</p>
        <p className="mt-1">All rights reserved</p>
      </footer>
    </div>
  )
}

