"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Sparkles,
  DollarSign,
  TrendingUp,
  Bell,
  User,
  ArrowRight,
  Heart,
  MessageCircle,
  Share2,
  Clock,
  Wallet,
  Gift,
  Award,
  Star,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Swiper, SwiperSlide } from "swiper/react"
import "swiper/css"
import MobileNavbar from "@/components/mobile/mobile-navbar"
import MobileHeader from "@/components/mobile/mobile-header"
import OpportunityCard from "@/components/mobile/opportunity-card"

interface Opportunity {
  id: string
  title: string
  brand: {
    name: string
    logo: string
    verified: boolean
  }
  category: string
  commission: string
  matchScore: number
  earnings: string
  timeLeft: string
  spots: number
  totalSpots: number
  description: string
  requirements?: string[]
  media?: string
  isHot?: boolean
}

interface Post {
  id: string
  user: {
    name: string
    username: string
    avatar: string
    isVerified: boolean
    level?: number
  }
  content: string
  media?: string
  earnings?: number
  likes: number
  comments: number
  shares: number
  timestamp: Date
  product?: {
    name: string
    image: string
    earnings: number
    platform: string
  }
}

export default function MobilePage() {
  const [activeTab, setActiveTab] = useState("discover")
  const [currentSlide, setCurrentSlide] = useState(0)
  const [likedPosts, setLikedPosts] = useState<string[]>([])
  const [opportunities, setOpportunities] = useState<Opportunity[]>([])
  const [posts, setPosts] = useState<Post[]>([])
  const swiperRef = useRef(null)

  useEffect(() => {
    // Initialize opportunities
    const initialOpportunities: Opportunity[] = [
      {
        id: "1",
        title: "Tech Gadget Bundle Promotion",
        brand: {
          name: "TechGear",
          logo: "/placeholder.svg?height=40&width=40",
          verified: true,
        },
        category: "Tech",
        commission: "$45 + 12%",
        matchScore: 94,
        earnings: "$120-$350",
        timeLeft: "2 days",
        spots: 8,
        totalSpots: 25,
        description: "Premium noise-cancelling headphones with 40-hour battery life and spatial audio.",
        media: "/placeholder.svg?height=400&width=600",
        isHot: true,
      },
      {
        id: "2",
        title: "Skincare Collection Launch",
        brand: {
          name: "GlowUp",
          logo: "/placeholder.svg?height=40&width=40",
          verified: true,
        },
        category: "Beauty",
        commission: "18%",
        matchScore: 87,
        earnings: "$80-$200",
        timeLeft: "5 days",
        spots: 12,
        totalSpots: 50,
        description: "Viral skincare collection featuring vitamin C, hyaluronic acid, and niacinamide serums.",
        media: "/placeholder.svg?height=400&width=600",
      },
      {
        id: "3",
        title: "Fitness Tracker Pro",
        brand: {
          name: "ActiveLife",
          logo: "/placeholder.svg?height=40&width=40",
          verified: false,
        },
        category: "Fitness",
        commission: "$30 + 10%",
        matchScore: 82,
        earnings: "$90-$250",
        timeLeft: "3 days",
        spots: 15,
        totalSpots: 40,
        description: "Advanced fitness tracker with heart rate monitoring, sleep analysis, and 10-day battery life.",
        requirements: ["Minimum 5K followers", "Fitness/Health niche", "At least 3 posts per week"],
      },
      {
        id: "4",
        title: "Sustainable Fashion Collection",
        brand: {
          name: "EcoStyle",
          logo: "/placeholder.svg?height=40&width=40",
          verified: true,
        },
        category: "Fashion",
        commission: "15-20%",
        matchScore: 79,
        earnings: "$75-$180",
        timeLeft: "7 days",
        spots: 20,
        totalSpots: 30,
        description: "Eco-friendly fashion line made from recycled materials with carbon-neutral shipping.",
        isHot: true,
      },
      {
        id: "5",
        title: "Smart Home Starter Kit",
        brand: {
          name: "HomeConnect",
          logo: "/placeholder.svg?height=40&width=40",
          verified: true,
        },
        category: "Tech",
        commission: "$50 flat + 8%",
        matchScore: 91,
        earnings: "$150-$300",
        timeLeft: "4 days",
        spots: 5,
        totalSpots: 15,
        description: "Complete smart home package with voice assistant, smart lights, plugs, and security camera.",
      },
    ]

    setOpportunities(initialOpportunities)

    // Initialize posts
    const initialPosts: Post[] = [
      {
        id: "1",
        user: {
          name: "Mia Chen",
          username: "miacreates",
          avatar: "/placeholder.svg?height=40&width=40",
          isVerified: true,
          level: 15,
        },
        content:
          "just dropped my tech essentials collection and it's already converting at 8.2% 🤯 this collab with @techgear is insane! who else is in the tech niche?",
        media: "/placeholder.svg?height=400&width=600",
        earnings: 432.19,
        likes: 124,
        comments: 28,
        shares: 12,
        timestamp: new Date(Date.now() - 1000 * 60 * 30),
        product: {
          name: "Ultra Boost Headphones Pro",
          image: "/placeholder.svg?height=80&width=80",
          earnings: 432.19,
          platform: "TechGear",
        },
      },
      {
        id: "2",
        user: {
          name: "Alex Rivera",
          username: "alexcreates",
          avatar: "/placeholder.svg?height=40&width=40",
          isVerified: true,
          level: 22,
        },
        content:
          "broke my personal record today! $1,289 in a single day from my finance guide links 📈 the key is building trust with your audience before recommending products",
        earnings: 1289.45,
        likes: 256,
        comments: 42,
        shares: 38,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
      },
      {
        id: "3",
        user: {
          name: "Jordan Williams",
          username: "jordanwilliams",
          avatar: "/placeholder.svg?height=40&width=40",
          isVerified: false,
          level: 7,
        },
        content:
          "testing out this new fitness tracker and the affiliate program is paying 20% commission! already made $167 today just from my morning workout story 💪",
        media: "/placeholder.svg?height=400&width=600",
        earnings: 167.82,
        likes: 98,
        comments: 14,
        shares: 7,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5),
        product: {
          name: "FitPro Smart Watch",
          image: "/placeholder.svg?height=80&width=80",
          earnings: 167.82,
          platform: "ActiveLife",
        },
      },
    ]

    setPosts(initialPosts)
  }, [])

  const toggleLike = (postId: string) => {
    if (likedPosts.includes(postId)) {
      setLikedPosts((prev) => prev.filter((id) => id !== postId))
      setPosts((prev) => prev.map((post) => (post.id === postId ? { ...post, likes: post.likes - 1 } : post)))
    } else {
      setLikedPosts((prev) => [...prev, postId])
      setPosts((prev) => prev.map((post) => (post.id === postId ? { ...post, likes: post.likes + 1 } : post)))
    }
  }

  const formatTime = (date: Date) => {
    const now = new Date()
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

    if (diffInSeconds < 60) return `${diffInSeconds}s ago`
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`
    return `${Math.floor(diffInSeconds / 86400)}d ago`
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <MobileHeader />

      <main className="pb-20">
        {activeTab === "discover" && (
          <div className="relative">
            <Swiper
              ref={swiperRef}
              direction="vertical"
              slidesPerView={1}
              spaceBetween={0}
              className="h-[calc(100vh-120px)]"
              onSlideChange={(swiper) => setCurrentSlide(swiper.activeIndex)}
            >
              {opportunities.map((opportunity, index) => (
                <SwiperSlide key={opportunity.id} className="h-full">
                  <OpportunityCard opportunity={opportunity} isActive={currentSlide === index} />
                </SwiperSlide>
              ))}
            </Swiper>

            <div className="absolute top-4 right-4 z-10 flex flex-col items-center gap-4">
              <div className="bg-black/50 backdrop-blur-md rounded-full p-2">
                <Avatar className="h-12 w-12 border-2 border-white">
                  <AvatarImage
                    src={opportunities[currentSlide]?.brand.logo}
                    alt={opportunities[currentSlide]?.brand.name}
                  />
                  <AvatarFallback>{opportunities[currentSlide]?.brand.name.charAt(0)}</AvatarFallback>
                </Avatar>
                {opportunities[currentSlide]?.brand.verified && (
                  <div className="absolute -bottom-1 -right-1 bg-[#00CFCF] text-black rounded-full w-5 h-5 flex items-center justify-center">
                    <Sparkles className="h-3 w-3" />
                  </div>
                )}
              </div>

              <div className="flex flex-col items-center gap-4">
                <Button variant="ghost" size="icon" className="bg-black/50 backdrop-blur-md rounded-full h-12 w-12">
                  <Heart className="h-6 w-6" />
                </Button>
                <Button variant="ghost" size="icon" className="bg-black/50 backdrop-blur-md rounded-full h-12 w-12">
                  <MessageCircle className="h-6 w-6" />
                </Button>
                <Button variant="ghost" size="icon" className="bg-black/50 backdrop-blur-md rounded-full h-12 w-12">
                  <Share2 className="h-6 w-6" />
                </Button>
                <Button variant="ghost" size="icon" className="bg-black/50 backdrop-blur-md rounded-full h-12 w-12">
                  <Wallet className="h-6 w-6" />
                </Button>
              </div>

              <div className="bg-black/50 backdrop-blur-md rounded-full px-3 py-1.5 flex items-center">
                <Badge className="bg-[#00CFCF] text-black">{opportunities[currentSlide]?.matchScore}%</Badge>
              </div>
            </div>

            <div className="absolute bottom-4 right-4 z-10">
              <div className="bg-[#00CFCF] text-black font-bold rounded-full px-4 py-2 flex items-center">
                <DollarSign className="mr-2 h-4 w-4" />
                Earn Now
              </div>
            </div>

            <div className="absolute bottom-4 left-4 z-10">
              <div className="bg-black/50 backdrop-blur-md rounded-full px-3 py-1.5 flex items-center gap-1">
                <Clock className="h-4 w-4 text-[#00CFCF]" />
                <span className="text-sm">{opportunities[currentSlide]?.timeLeft} left</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === "feed" && (
          <div className="px-4 py-2">
            <Tabs defaultValue="all" className="mb-4">
              <TabsList className="bg-[#191919] p-1 rounded-full">
                <TabsTrigger value="all" className="rounded-full text-sm">
                  All
                </TabsTrigger>
                <TabsTrigger value="following" className="rounded-full text-sm">
                  Following
                </TabsTrigger>
                <TabsTrigger value="trending" className="rounded-full text-sm">
                  Trending
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="space-y-6">
              <AnimatePresence>
                {posts.map((post) => (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4 }}
                    className="bg-[#111111] rounded-xl border border-white/10 overflow-hidden"
                  >
                    <div className="p-4">
                      <div className="flex items-start gap-3 mb-3">
                        <div className="relative">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={post.user.avatar} alt={post.user.name} />
                            <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          {post.user.isVerified && (
                            <div className="absolute -top-1 -right-1 bg-[#00CFCF] text-black rounded-full w-4 h-4 flex items-center justify-center">
                              <Sparkles className="h-2.5 w-2.5" />
                            </div>
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1">
                            <span className="font-medium">{post.user.name}</span>
                            {post.user.level && (
                              <Badge className="bg-[#191919] text-white/80 text-xs">Lv.{post.user.level}</Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-white/60">@{post.user.username}</span>
                            <span className="text-white/40">•</span>
                            <span className="text-sm text-white/60">{formatTime(post.timestamp)}</span>
                          </div>
                        </div>

                        {post.earnings && (
                          <div className="flex items-center bg-[#191919] rounded-full px-3 py-1">
                            <DollarSign className="h-3.5 w-3.5 text-[#00CFCF] mr-1" />
                            <span className="font-medium text-[#00CFCF]">${post.earnings}</span>
                          </div>
                        )}
                      </div>

                      <p className="mb-4 whitespace-pre-line">{post.content}</p>

                      {post.media && (
                        <div className="mb-4 rounded-lg overflow-hidden">
                          <img
                            src={post.media || "/placeholder.svg"}
                            alt="Post media"
                            className="w-full h-auto object-cover"
                          />
                        </div>
                      )}

                      {post.product && (
                        <Card className="mb-4 bg-[#191919] border-white/10">
                          <div className="p-3 flex items-center gap-3">
                            <div className="h-16 w-16 bg-[#222222] rounded-md flex items-center justify-center overflow-hidden">
                              <img
                                src={post.product.image || "/placeholder.svg"}
                                alt={post.product.name}
                                className="max-w-full max-h-full object-contain"
                              />
                            </div>

                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="font-medium truncate">{post.product.name}</div>
                                  <div className="text-sm text-white/60">{post.product.platform}</div>
                                </div>
                                <div className="text-right">
                                  <div className="text-[#00CFCF] font-bold">${post.product.earnings}</div>
                                  <div className="text-xs text-white/60">earned</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </Card>
                      )}

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            className={`text-sm flex items-center gap-1.5 ${likedPosts.includes(post.id) ? "text-[#00CFCF]" : "text-white/60 hover:text-white"}`}
                            onClick={() => toggleLike(post.id)}
                          >
                            <Heart className={`h-4 w-4 ${likedPosts.includes(post.id) ? "fill-[#00CFCF]" : ""}`} />
                            {post.likes}
                          </Button>

                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-sm text-white/60 hover:text-white flex items-center gap-1.5"
                          >
                            <MessageCircle className="h-4 w-4" />
                            {post.comments}
                          </Button>

                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-sm text-white/60 hover:text-white flex items-center gap-1.5"
                          >
                            <Share2 className="h-4 w-4" />
                            {post.shares}
                          </Button>
                        </div>

                        <Button size="sm" className="bg-[#00CFCF] text-black font-medium">
                          <DollarSign className="mr-1.5 h-3.5 w-3.5" />
                          Earn Now
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}

        {activeTab === "earnings" && (
          <div className="px-4 py-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-1">Your Earnings</h2>
              <p className="text-white/60">Track your affiliate revenue in real-time</p>
            </div>

            <Card className="bg-[#00CFCF]/10 border-white/10 mb-6">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="text-white/60">Available Balance</div>
                  <Badge className="bg-[#00CFCF] text-black">Instant Payout</Badge>
                </div>
                <div className="text-4xl font-bold mb-2">$1,289.45</div>
                <div className="flex items-center text-white/60 text-sm mb-6">
                  <TrendingUp className="h-4 w-4 text-[#00CFCF] mr-1" />
                  <span>+$432.19 today</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <Button className="bg-[#00CFCF] text-black font-bold">
                    <Wallet className="mr-2 h-4 w-4" />
                    Get Paid Now
                  </Button>
                  <Button variant="outline" className="border-white/20">
                    <ArrowRight className="mr-2 h-4 w-4" />
                    View History
                  </Button>
                </div>
              </div>
            </Card>

            <div className="mb-6">
              <h3 className="font-medium mb-4">Pending Payouts</h3>
              <div className="space-y-3">
                <Card className="bg-[#111111] border-white/10">
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <Avatar className="h-8 w-8 mr-2">
                          <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Amazon" />
                          <AvatarFallback>AM</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">Amazon Associates</div>
                          <div className="text-xs text-white/60">Tech category</div>
                        </div>
                      </div>
                      <Badge className="bg-[#FFFFFF] text-black">
                        <Clock className="mr-1 h-3 w-3" />
                        15d left
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-lg font-bold">$432.19</div>
                      <Button size="sm" className="h-8 bg-[#00CFCF] text-black font-medium">
                        <DollarSign className="mr-1 h-3 w-3" />
                        Get Paid
                      </Button>
                    </div>
                    <div className="text-xs text-white/40 mt-1">
                      Regular payout: Apr 15, 2025 • Instant fee: $8.64 (2%)
                    </div>
                  </div>
                </Card>

                <Card className="bg-[#111111] border-white/10">
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <Avatar className="h-8 w-8 mr-2">
                          <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Shopify" />
                          <AvatarFallback>SH</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">Shopify Partners</div>
                          <div className="text-xs text-white/60">Beauty products</div>
                        </div>
                      </div>
                      <Badge className="bg-[#FFFFFF] text-black">
                        <Clock className="mr-1 h-3 w-3" />
                        22d left
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-lg font-bold">$289.45</div>
                      <Button size="sm" className="h-8 bg-[#00CFCF] text-black font-medium">
                        <DollarSign className="mr-1 h-3 w-3" />
                        Get Paid
                      </Button>
                    </div>
                    <div className="text-xs text-white/40 mt-1">
                      Regular payout: Apr 22, 2025 • Instant fee: $5.79 (2%)
                    </div>
                  </div>
                </Card>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="font-medium mb-4">Performance Overview</h3>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <Card className="bg-[#111111] border-white/10">
                  <div className="p-4">
                    <div className="text-white/60 text-sm mb-1">Conversion Rate</div>
                    <div className="text-xl font-bold">8.2%</div>
                    <div className="flex items-center text-[#00CFCF] text-xs">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      +2.1% from last week
                    </div>
                  </div>
                </Card>

                <Card className="bg-[#111111] border-white/10">
                  <div className="p-4">
                    <div className="text-white/60 text-sm mb-1">Active Links</div>
                    <div className="text-xl font-bold">24</div>
                    <div className="flex items-center text-[#00CFCF] text-xs">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      +3 new today
                    </div>
                  </div>
                </Card>
              </div>

              <Card className="bg-[#111111] border-white/10">
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="font-medium">Top Performing Links</div>
                    <Button variant="ghost" size="sm" className="h-7 text-xs text-white/60">
                      View All
                    </Button>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Tech Gadgets" />
                          <AvatarFallback>TG</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">Ultra Boost Headphones</div>
                          <div className="text-xs text-white/60">432 clicks</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-[#00CFCF]">$432.19</div>
                        <div className="text-xs text-white/60">12.4% conv.</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Beauty" />
                          <AvatarFallback>GS</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">Glow Serum Collection</div>
                          <div className="text-xs text-white/60">218 clicks</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-[#00CFCF]">$289.45</div>
                        <div className="text-xs text-white/60">8.7% conv.</div>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            </div>

            <Card className="bg-[#00CFCF]/10 border-white/10">
              <div className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-10 w-10 rounded-full bg-[#FFFFFF]/20 flex items-center justify-center">
                    <Award className="h-5 w-5 text-[#FFFFFF]" />
                  </div>
                  <div>
                    <div className="font-medium">Level Up Challenge</div>
                    <div className="text-sm text-white/60">Earn rewards as you grow</div>
                  </div>
                </div>

                <div className="mb-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm">Level 7</span>
                    <span className="text-xs text-white/60">1,250/2,000 XP</span>
                  </div>
                  <Progress value={62.5} className="h-1.5 bg-white/10" indicatorClassName="bg-[#00CFCF]" />
                </div>

                <Button className="w-full bg-white text-black font-bold">
                  <Gift className="mr-2 h-4 w-4" />
                  Claim Level 7 Rewards
                </Button>
              </div>
            </Card>
          </div>
        )}

        {activeTab === "profile" && (
          <div className="px-4 py-6">
            <div className="flex items-center gap-4 mb-6">
              <Avatar className="h-20 w-20 border-2 border-[#00CFCF]">
                <AvatarImage src="/placeholder.svg?height=80&width=80" alt="Jordan Doe" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>

              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-bold">Jordan Doe</h2>
                  <Badge className="bg-[#00CFCF] text-black">
                    <Sparkles className="mr-1 h-3 w-3" />
                    Verified
                  </Badge>
                </div>
                <p className="text-white/60">@jordandoe</p>

                <div className="flex items-center gap-4 mt-2">
                  <div className="text-center">
                    <div className="text-sm font-bold">128</div>
                    <div className="text-xs text-white/60">Followers</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-bold">87</div>
                    <div className="text-xs text-white/60">Following</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-bold">$4,289</div>
                    <div className="text-xs text-white/60">Earned</div>
                  </div>
                </div>
              </div>
            </div>

            <Card className="bg-[#111111] border-white/10 mb-6">
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium">Level Progress</h3>
                  <Badge className="bg-[#191919] text-white/80">Level 7</Badge>
                </div>

                <div className="mb-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-white/60">1,250/2,000 XP</span>
                    <span className="text-xs text-white/60">Next: Level 8</span>
                  </div>
                  <Progress value={62.5} className="h-1.5 bg-white/10" indicatorClassName="bg-[#00CFCF]" />
                </div>

                <div className="text-xs text-white/60">
                  <span className="text-[#00CFCF]">750 XP</span> needed to reach Level 8
                </div>
              </div>
            </Card>

            <div className="mb-6">
              <h3 className="font-medium mb-3">Your Badges</h3>
              <div className="flex flex-wrap gap-3">
                <div className="flex flex-col items-center">
                  <div className="h-12 w-12 rounded-full bg-[#FFFFFF]/20 flex items-center justify-center mb-1">
                    <Star className="h-6 w-6 text-[#FFFFFF]" />
                  </div>
                  <span className="text-xs">Early Adopter</span>
                </div>

                <div className="flex flex-col items-center">
                  <div className="h-12 w-12 rounded-full bg-[#00CFCF]/20 flex items-center justify-center mb-1">
                    <TrendingUp className="h-6 w-6 text-[#00CFCF]" />
                  </div>
                  <span className="text-xs">Rising Star</span>
                </div>

                <div className="flex flex-col items-center">
                  <div className="h-12 w-12 rounded-full bg-[#00CFCF]/20 flex items-center justify-center mb-1">
                    <Sparkles className="h-6 w-6 text-[#00CFCF]" />
                  </div>
                  <span className="text-xs">Verified</span>
                </div>

                <div className="flex flex-col items-center opacity-40">
                  <div className="h-12 w-12 rounded-full bg-white/10 flex items-center justify-center mb-1">
                    <Award className="h-6 w-6 text-white/60" />
                  </div>
                  <span className="text-xs">Locked</span>
                </div>
              </div>
            </div>

            <Card className="bg-[#111111] border-white/10 mb-6">
              <div className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-medium">Stats Overview</h3>
                  <Button variant="ghost" size="sm" className="h-7 text-xs text-white/60">
                    View Details
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-[#191919] rounded-lg p-3">
                    <div className="text-white/60 text-xs mb-1">Total Earnings</div>
                    <div className="text-lg font-bold">$4,289.45</div>
                  </div>

                  <div className="bg-[#191919] rounded-lg p-3">
                    <div className="text-white/60 text-xs mb-1">Conversion Rate</div>
                    <div className="text-lg font-bold">8.2%</div>
                  </div>

                  <div className="bg-[#191919] rounded-lg p-3">
                    <div className="text-white/60 text-xs mb-1">Active Links</div>
                    <div className="text-lg font-bold">24</div>
                  </div>

                  <div className="bg-[#191919] rounded-lg p-3">
                    <div className="text-white/60 text-xs mb-1">Achievements</div>
                    <div className="text-lg font-bold">3/9</div>
                  </div>
                </div>
              </div>
            </Card>

            <div className="space-y-3">
              <Button variant="outline" className="w-full border-white/20 justify-start">
                <User className="mr-2 h-4 w-4" />
                Edit Profile
              </Button>

              <Button variant="outline" className="w-full border-white/20 justify-start">
                <Wallet className="mr-2 h-4 w-4" />
                Payment Settings
              </Button>

              <Button variant="outline" className="w-full border-white/20 justify-start">
                <Bell className="mr-2 h-4 w-4" />
                Notification Preferences
              </Button>
            </div>
          </div>
        )}
      </main>

      <MobileNavbar activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  )
}

