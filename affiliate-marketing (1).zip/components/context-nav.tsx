"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import {
  Search,
  Bell,
  User,
  ChevronDown,
  LogOut,
  Settings,
  CreditCard,
  HelpCircle,
  MessageSquare,
  Heart,
  Bookmark,
  BarChart,
  Zap,
  Star,
  Clock,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import ThemeToggle from "@/components/theme-toggle"

interface NotificationItem {
  id: string
  title: string
  message: string
  time: string
  read: boolean
  type: "sale" | "alert" | "update" | "message"
}

export function ContextNav() {
  const [showSearch, setShowSearch] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: "1",
      title: "New Sale",
      message: "You earned $45.50 from a new sale",
      time: "5 minutes ago",
      read: false,
      type: "sale",
    },
    {
      id: "2",
      title: "Commission Paid",
      message: "Your commission of $120.75 has been paid",
      time: "2 hours ago",
      read: false,
      type: "sale",
    },
    {
      id: "3",
      title: "New Program Available",
      message: "A new program matching your profile is available",
      time: "Yesterday",
      read: true,
      type: "alert",
    },
    {
      id: "4",
      title: "Platform Update",
      message: "New features have been added to the dashboard",
      time: "3 days ago",
      read: true,
      type: "update",
    },
  ])

  const searchRef = useRef<HTMLDivElement>(null)
  const notificationsRef = useRef<HTMLDivElement>(null)
  const userMenuRef = useRef<HTMLDivElement>(null)
  const pathname = usePathname()

  const unreadCount = notifications.filter((n) => !n.read).length

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSearch(false)
      }
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setShowNotifications(false)
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // Close dropdowns when route changes
  useEffect(() => {
    setShowSearch(false)
    setShowNotifications(false)
    setShowUserMenu(false)
  }, [pathname])

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
  }

  const markAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  return (
    <div className="flex items-center gap-2">
      {/* Search */}
      <div className="relative" ref={searchRef}>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setShowSearch(!showSearch)}
          className="text-white/80 hover:text-white hover:bg-white/10"
          aria-label="Search"
        >
          <Search className="h-5 w-5" />
        </Button>

        <AnimatePresence>
          {showSearch && (
            <motion.div
              initial={{ opacity: 0, y: 10, width: "300px" }}
              animate={{ opacity: 1, y: 0, width: "350px" }}
              exit={{ opacity: 0, y: 10 }}
              transition={{ duration: 0.2 }}
              className="absolute right-0 mt-2 p-4 bg-[#0A0A14] border border-white/10 rounded-lg shadow-xl z-50"
            >
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search programs, tools, resources..."
                  className="w-full bg-white/5 border-white/20 focus:border-[#00F0FF] pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  autoFocus
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-white/50" />
              </div>

              {searchQuery && (
                <div className="mt-4 space-y-2">
                  <div className="text-xs font-medium text-white/50 uppercase">Quick Results</div>
                  <div className="space-y-1">
                    <Link
                      href="/marketplace/programs"
                      className="flex items-center gap-2 p-2 rounded-md hover:bg-white/5 transition-colors"
                      onClick={() => setShowSearch(false)}
                    >
                      <Star className="h-4 w-4 text-[#00F0FF]" />
                      <span>Top Affiliate Programs</span>
                    </Link>
                    <Link
                      href="/tools/link-generator"
                      className="flex items-center gap-2 p-2 rounded-md hover:bg-white/5 transition-colors"
                      onClick={() => setShowSearch(false)}
                    >
                      <Zap className="h-4 w-4 text-[#00F0FF]" />
                      <span>Link Generator Tool</span>
                    </Link>
                    <Link
                      href="/blog/affiliate-marketing-guide"
                      className="flex items-center gap-2 p-2 rounded-md hover:bg-white/5 transition-colors"
                      onClick={() => setShowSearch(false)}
                    >
                      <MessageSquare className="h-4 w-4 text-[#00F0FF]" />
                      <span>Affiliate Marketing Guide</span>
                    </Link>
                  </div>
                </div>
              )}

              <div className="mt-4 pt-3 border-t border-white/10">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-medium text-white/50">RECENT SEARCHES</div>
                  <button className="text-xs text-[#00F0FF] hover:underline">Clear All</button>
                </div>
                <div className="mt-2 space-y-1">
                  <div className="flex items-center justify-between p-2 rounded-md hover:bg-white/5 transition-colors">
                    <div className="flex items-center gap-2">
                      <Clock className="h-3 w-3 text-white/50" />
                      <span className="text-sm">health supplements</span>
                    </div>
                    <button className="text-white/30 hover:text-white/60">×</button>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-md hover:bg-white/5 transition-colors">
                    <div className="flex items-center gap-2">
                      <Clock className="h-3 w-3 text-white/50" />
                      <span className="text-sm">commission rates</span>
                    </div>
                    <button className="text-white/30 hover:text-white/60">×</button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Notifications */}
      <div className="relative" ref={notificationsRef}>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setShowNotifications(!showNotifications)}
          className="text-white/80 hover:text-white hover:bg-white/10 relative"
          aria-label="Notifications"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 w-4 h-4 bg-[#00F0FF] text-[#0A0A14] text-xs font-bold rounded-full flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </Button>

        <AnimatePresence>
          {showNotifications && (
            <motion.div
              initial={{ opacity: 0, y: 10, width: "300px" }}
              animate={{ opacity: 1, y: 0, width: "380px" }}
              exit={{ opacity: 0, y: 10 }}
              transition={{ duration: 0.2 }}
              className="absolute right-0 mt-2 bg-[#0A0A14] border border-white/10 rounded-lg shadow-xl z-50 overflow-hidden"
            >
              <div className="p-4 border-b border-white/10 flex items-center justify-between">
                <h3 className="font-medium">Notifications</h3>
                {unreadCount > 0 && (
                  <button className="text-xs text-[#00F0FF] hover:underline" onClick={markAllAsRead}>
                    Mark all as read
                  </button>
                )}
              </div>

              <div className="max-h-[350px] overflow-y-auto">
                {notifications.length > 0 ? (
                  <div className="divide-y divide-white/5">
                    {notifications.map((notification) => (
                      <div
                        key={notification.id}
                        className={`p-4 hover:bg-white/5 transition-colors ${!notification.read ? "bg-[#0A1A2F]/30" : ""}`}
                        onClick={() => markAsRead(notification.id)}
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className={`mt-0.5 p-2 rounded-full 
                            ${
                              notification.type === "sale"
                                ? "bg-green-500/10 text-green-400"
                                : notification.type === "alert"
                                  ? "bg-yellow-500/10 text-yellow-400"
                                  : notification.type === "update"
                                    ? "bg-blue-500/10 text-blue-400"
                                    : "bg-purple-500/10 text-purple-400"
                            }`}
                          >
                            {notification.type === "sale" ? (
                              <CreditCard className="h-4 w-4" />
                            ) : notification.type === "alert" ? (
                              <Bell className="h-4 w-4" />
                            ) : notification.type === "update" ? (
                              <Zap className="h-4 w-4" />
                            ) : (
                              <MessageSquare className="h-4 w-4" />
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <h4 className="font-medium text-sm">{notification.title}</h4>
                              {!notification.read && <span className="w-2 h-2 bg-[#00F0FF] rounded-full"></span>}
                            </div>
                            <p className="text-sm text-white/70 mt-1">{notification.message}</p>
                            <p className="text-xs text-white/50 mt-1">{notification.time}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 text-center">
                    <Bell className="h-10 w-10 text-white/20 mx-auto mb-3" />
                    <p className="text-white/50">No notifications yet</p>
                  </div>
                )}
              </div>

              <div className="p-3 border-t border-white/10 bg-[#0A1A2F]/30 text-center">
                <Link
                  href="/notifications"
                  className="text-sm text-[#00F0FF] hover:underline"
                  onClick={() => setShowNotifications(false)}
                >
                  View all notifications
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Theme Toggle */}
      <ThemeToggle />

      {/* User Menu */}
      <div className="relative" ref={userMenuRef}>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowUserMenu(!showUserMenu)}
          className="text-white/80 hover:text-white hover:bg-white/10 flex items-center gap-2 ml-2"
        >
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
            <User className="h-4 w-4" />
          </div>
          <span className="hidden md:inline">John Doe</span>
          <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${showUserMenu ? "rotate-180" : ""}`} />
        </Button>

        <AnimatePresence>
          {showUserMenu && (
            <motion.div
              initial={{ opacity: 0, y: 10, width: "220px" }}
              animate={{ opacity: 1, y: 0, width: "220px" }}
              exit={{ opacity: 0, y: 10 }}
              transition={{ duration: 0.2 }}
              className="absolute right-0 mt-2 bg-[#0A0A14] border border-white/10 rounded-lg shadow-xl z-50 overflow-hidden"
            >
              <div className="p-4 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
                    <User className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium">John Doe</h3>
                    <p className="text-xs text-white/50">john.doe@example.com</p>
                  </div>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <div className="bg-white/5 rounded p-2 text-center">
                    <div className="text-[#00F0FF] font-medium">$1,245</div>
                    <div className="text-xs text-white/50">Earnings</div>
                  </div>
                  <div className="bg-white/5 rounded p-2 text-center">
                    <div className="text-[#00F0FF] font-medium">24</div>
                    <div className="text-xs text-white/50">Sales</div>
                  </div>
                </div>
              </div>

              <div className="py-1">
                <Link
                  href="/dashboard"
                  className="flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors"
                  onClick={() => setShowUserMenu(false)}
                >
                  <BarChart className="h-4 w-4 text-white/70" />
                  <span>Dashboard</span>
                </Link>
                <Link
                  href="/profile"
                  className="flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors"
                  onClick={() => setShowUserMenu(false)}
                >
                  <User className="h-4 w-4 text-white/70" />
                  <span>Profile</span>
                </Link>
                <Link
                  href="/favorites"
                  className="flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors"
                  onClick={() => setShowUserMenu(false)}
                >
                  <Heart className="h-4 w-4 text-white/70" />
                  <span>Favorites</span>
                </Link>
                <Link
                  href="/saved"
                  className="flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors"
                  onClick={() => setShowUserMenu(false)}
                >
                  <Bookmark className="h-4 w-4 text-white/70" />
                  <span>Saved Items</span>
                </Link>
                <Link
                  href="/settings"
                  className="flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors"
                  onClick={() => setShowUserMenu(false)}
                >
                  <Settings className="h-4 w-4 text-white/70" />
                  <span>Settings</span>
                </Link>
                <Link
                  href="/help"
                  className="flex items-center gap-2 px-4 py-2 hover:bg-white/5 transition-colors"
                  onClick={() => setShowUserMenu(false)}
                >
                  <HelpCircle className="h-4 w-4 text-white/70" />
                  <span>Help & Support</span>
                </Link>
              </div>

              <div className="p-2 border-t border-white/10">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-500/10"
                  onClick={() => setShowUserMenu(false)}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Get Started Button (Desktop) */}
      <Button
        asChild
        className="hidden md:flex bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90 transition-all duration-300 ml-2"
      >
        <Link href="/onboarding">Get Started</Link>
      </Button>
    </div>
  )
}

