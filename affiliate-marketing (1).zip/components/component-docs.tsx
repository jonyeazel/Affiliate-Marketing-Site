"use client"

import { useState } from "react"
import { ChevronDown, Copy, Check } from "lucide-react"

interface PropDefinition {
  name: string
  type: string
  default?: string
  required?: boolean
  description: string
}

interface ComponentDocsProps {
  name: string
  description: string
  usage: string
  props: PropDefinition[]
  examples?: { title: string; code: string }[]
}

export default function ComponentDocs({ name, description, usage, props, examples = [] }: ComponentDocsProps) {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null)
  const [showProps, setShowProps] = useState(true)

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text)
    setCopiedIndex(index)
    setTimeout(() => setCopiedIndex(null), 2000)
  }

  return (
    <div className="bg-white/5 rounded-lg border border-white/10 p-6">
      <h2 className="text-2xl font-bold mb-2">{name}</h2>
      <p className="text-gray-400 mb-6">{description}</p>

      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-2">Usage</h3>
        <div className="relative bg-gray-900 rounded-md p-4">
          <pre className="text-gray-300 overflow-x-auto">
            <code>{usage}</code>
          </pre>
          <button
            onClick={() => copyToClipboard(usage, -1)}
            className="absolute top-2 right-2 p-1 rounded-md hover:bg-gray-800 transition-colors"
            aria-label="Copy code"
          >
            {copiedIndex === -1 ? (
              <Check className="h-5 w-5 text-green-500" />
            ) : (
              <Copy className="h-5 w-5 text-gray-400" />
            )}
          </button>
        </div>
      </div>

      <div className="mb-6">
        <button
          onClick={() => setShowProps(!showProps)}
          className="flex items-center justify-between w-full text-lg font-semibold mb-2 focus:outline-none"
        >
          <span>Props</span>
          <ChevronDown className={`h-5 w-5 transition-transform ${showProps ? "transform rotate-180" : ""}`} />
        </button>

        {showProps && (
          <div className="bg-gray-900 rounded-md overflow-hidden">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="px-4 py-2 text-gray-300">Name</th>
                  <th className="px-4 py-2 text-gray-300">Type</th>
                  <th className="px-4 py-2 text-gray-300">Default</th>
                  <th className="px-4 py-2 text-gray-300">Description</th>
                </tr>
              </thead>
              <tbody>
                {props.map((prop) => (
                  <tr key={prop.name} className="border-b border-gray-800">
                    <td className="px-4 py-2">
                      <code className="text-cyan-400">{prop.name}</code>
                      {prop.required && <span className="ml-2 text-xs text-red-500">Required</span>}
                    </td>
                    <td className="px-4 py-2">
                      <code className="text-yellow-400">{prop.type}</code>
                    </td>
                    <td className="px-4 py-2">
                      {prop.default ? (
                        <code className="text-green-400">{prop.default}</code>
                      ) : (
                        <span className="text-gray-500">-</span>
                      )}
                    </td>
                    <td className="px-4 py-2 text-gray-300">{prop.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {examples.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-2">Examples</h3>
          <div className="space-y-4">
            {examples.map((example, index) => (
              <div key={index} className="bg-gray-900 rounded-md overflow-hidden">
                <div className="bg-gray-800 px-4 py-2 flex items-center justify-between">
                  <h4 className="text-gray-300">{example.title}</h4>
                  <button
                    onClick={() => copyToClipboard(example.code, index)}
                    className="p-1 rounded-md hover:bg-gray-700 transition-colors"
                    aria-label="Copy code"
                  >
                    {copiedIndex === index ? (
                      <Check className="h-4 w-4 text-green-500" />
                    ) : (
                      <Copy className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                </div>
                <pre className="p-4 text-gray-300 overflow-x-auto">
                  <code>{example.code}</code>
                </pre>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

