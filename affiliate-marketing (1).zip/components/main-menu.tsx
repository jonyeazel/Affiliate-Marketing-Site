"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { usePathname } from "next/navigation"
import {
  ChevronDown,
  BarChart2,
  ShoppingBag,
  Users,
  FileText,
  HelpCircle,
  Zap,
  DollarSign,
  Award,
  Briefcase,
  BookOpen,
  MessageSquare,
} from "lucide-react"

interface MenuItem {
  name: string
  href: string
  icon?: React.ReactNode
  description?: string
  isExternal?: boolean
  badge?: string
  children?: MenuItem[]
}

export function MainMenu() {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)
  const pathname = usePathname()
  const dropdownRef = useRef<HTMLDivElement>(null)

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setActiveDropdown(null)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // Close dropdown when route changes
  useEffect(() => {
    setActiveDropdown(null)
  }, [pathname])

  const menuItems: MenuItem[] = [
    {
      name: "Dashboard",
      href: "/dashboard",
      icon: <BarChart2 className="h-5 w-5" />,
      description: "View your performance metrics and earnings",
    },
    {
      name: "Marketplace",
      href: "/marketplace",
      icon: <ShoppingBag className="h-5 w-5" />,
      description: "Browse and join affiliate programs",
      children: [
        {
          name: "Browse Programs",
          href: "/marketplace/programs",
          icon: <Briefcase className="h-4 w-4" />,
        },
        {
          name: "Top Offers",
          href: "/marketplace/top-offers",
          icon: <Award className="h-4 w-4" />,
          badge: "Hot",
        },
        {
          name: "Categories",
          href: "/marketplace/categories",
          icon: <FileText className="h-4 w-4" />,
        },
        {
          name: "Brand Directory",
          href: "/marketplace/brands",
          icon: <ShoppingBag className="h-4 w-4" />,
        },
      ],
    },
    {
      name: "Tools",
      href: "/tools",
      icon: <Zap className="h-5 w-5" />,
      description: "Access affiliate marketing tools",
      children: [
        {
          name: "Link Generator",
          href: "/tools/link-generator",
          icon: <Zap className="h-4 w-4" />,
        },
        {
          name: "Commission Calculator",
          href: "/tools/commission-calculator",
          icon: <DollarSign className="h-4 w-4" />,
        },
        {
          name: "Performance Tracker",
          href: "/tools/performance-tracker",
          icon: <BarChart2 className="h-4 w-4" />,
        },
        {
          name: "Marketing Materials",
          href: "/tools/marketing-materials",
          icon: <FileText className="h-4 w-4" />,
        },
      ],
    },
    {
      name: "Community",
      href: "/community",
      icon: <Users className="h-5 w-5" />,
      description: "Connect with other affiliates",
      children: [
        {
          name: "Forums",
          href: "/community/forums",
          icon: <MessageSquare className="h-4 w-4" />,
        },
        {
          name: "Events",
          href: "/community/events",
          icon: <Users className="h-4 w-4" />,
        },
        {
          name: "Learning Center",
          href: "/community/learning",
          icon: <BookOpen className="h-4 w-4" />,
          badge: "New",
        },
      ],
    },
    {
      name: "Blog",
      href: "/blog",
      icon: <FileText className="h-5 w-5" />,
      description: "Read the latest affiliate marketing tips",
    },
    {
      name: "Help",
      href: "/help",
      icon: <HelpCircle className="h-5 w-5" />,
      description: "Get support and answers to your questions",
    },
  ]

  const handleDropdownToggle = (e: React.MouseEvent, name: string) => {
    e.stopPropagation()
    setActiveDropdown(activeDropdown === name ? null : name)
  }

  return (
    <nav className="hidden lg:block" ref={dropdownRef}>
      <ul className="flex items-center space-x-1">
        {menuItems.map((item) => (
          <li key={item.name} className="relative">
            {item.children ? (
              <div>
                <button
                  onClick={(e) => handleDropdownToggle(e, item.name)}
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-300 ${
                    pathname === item.href || pathname?.startsWith(item.href + "/")
                      ? "text-[#00F0FF] bg-white/5"
                      : "text-white/80 hover:text-white hover:bg-white/5"
                  }`}
                >
                  {item.name}
                  <ChevronDown
                    className={`ml-1 h-4 w-4 transition-transform duration-300 ${
                      activeDropdown === item.name ? "rotate-180" : ""
                    }`}
                  />
                </button>

                <AnimatePresence>
                  {activeDropdown === item.name && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      transition={{ duration: 0.2, ease: "easeOut" }}
                      className="absolute left-0 mt-1 w-64 rounded-md bg-[#0A0A14] border border-white/10 shadow-lg z-50 overflow-hidden"
                      onClick={(e) => e.stopPropagation()}
                      style={{ transformOrigin: "top left" }}
                    >
                      <div className="p-4 border-b border-white/10 bg-gradient-to-r from-[#0A1A2F] to-[#0A0A14]">
                        <div className="flex items-center gap-2">
                          {item.icon}
                          <h3 className="font-medium">{item.name}</h3>
                        </div>
                        {item.description && <p className="mt-1 text-sm text-white/60">{item.description}</p>}
                      </div>
                      <div className="py-2">
                        {item.children.map((child) => (
                          <Link
                            key={child.name}
                            href={child.href}
                            className={`flex items-center justify-between px-4 py-2 text-sm hover:bg-white/5 transition-all duration-300 ${
                              pathname === child.href ? "text-[#00F0FF] bg-white/5" : "text-white/80 hover:text-white"
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              {child.icon}
                              <span>{child.name}</span>
                            </div>
                            {child.badge && (
                              <span className="px-2 py-0.5 text-xs rounded-full bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white">
                                {child.badge}
                              </span>
                            )}
                          </Link>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <Link
                href={item.href}
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-300 ${
                  pathname === item.href
                    ? "text-[#00F0FF] bg-white/5"
                    : "text-white/80 hover:text-white hover:bg-white/5"
                }`}
              >
                {item.name}
              </Link>
            )}

            {/* Active indicator */}
            {(pathname === item.href || pathname?.startsWith(item.href + "/")) && (
              <motion.div
                layoutId="activeNavIndicator"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#00F0FF]"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.2 }}
              />
            )}
          </li>
        ))}
      </ul>
    </nav>
  )
}

