"use client"

import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import { Apple, ArrowRight, QrCode } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"

export function AppDownloadSection() {
  const [activeTab, setActiveTab] = useState<"ios" | "android">("ios")

  const features = [
    "Real-time earnings tracking",
    "Instant notifications for sales",
    "Quick link generation on the go",
    "Performance analytics dashboard",
    "Secure payment withdrawals",
    "Offline content creation tools",
  ]

  return (
    <section className="py-24 overflow-hidden relative">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0A1A2F]/30 to-[#0A0A14] z-0"></div>

      {/* Animated background elements */}
      <div className="absolute top-20 left-10 w-64 h-64 rounded-full bg-[#00F0FF]/10 blur-[100px] animate-pulse"></div>
      <div
        className="absolute bottom-20 right-10 w-64 h-64 rounded-full bg-[#0033CC]/10 blur-[100px] animate-pulse"
        style={{ animationDelay: "2s" }}
      ></div>

      <div className="container px-4 md:px-6 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
          {/* Content */}
          <div className="w-full lg:w-1/2">
            <Badge
              className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
              variant="outline"
            >
              MOBILE APP
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
              Take Your Affiliate Business Anywhere
            </h2>
            <p className="text-base md:text-lg text-white/70 mb-8">
              Our powerful mobile app puts the full potential of AffiliateMarketing.com in your pocket. Generate links,
              track earnings, and manage your campaigns on the go.
            </p>

            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {features.map((feature, index) => (
                <motion.div
                  key={feature}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                  className="flex items-center"
                >
                  <div className="h-5 w-5 rounded-full bg-gradient-to-r from-[#00F0FF] to-[#0033CC] flex items-center justify-center mr-3">
                    <ArrowRight className="h-3 w-3 text-white" />
                  </div>
                  <span className="text-white">{feature}</span>
                </motion.div>
              ))}
            </div>

            {/* Download buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-black hover:bg-black/80 text-white border border-white/20">
                <Apple className="mr-2 h-5 w-5" />
                Download for iOS
              </Button>
              <Button className="bg-black hover:bg-black/80 text-white border border-white/20">
                <svg className="mr-2 h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.523 15.3414C17.523 15.3414 16.7301 14.9286 16.3495 14.6071C16.0301 14.3571 15.7495 14.0357 15.7301 13.6429C15.7301 13.25 16.0301 13 16.3495 12.75C16.6689 12.5 17.523 12.0357 17.523 12.0357L17.5036 7.89286C17.5036 7.89286 15.7689 8.71429 15.0036 9.25C14.2383 9.78571 13.5036 10.75 13.5036 12.0357V19.8929C13.5036 19.8929 13.5036 20.9286 12.7383 21.6071C11.973 22.2857 11.0036 22.5 10.2383 22.5C9.47296 22.5 8.50424 22.2857 7.73891 21.6071C6.97359 20.9286 6.97359 19.8929 6.97359 19.8929C6.97359 19.8929 6.97359 18.8571 7.73891 18.1786C8.50424 17.5 9.47296 17.2857 10.2383 17.2857C11.0036 17.2857 11.973 17.5 12.7383 18.1786V9.25C12.7383 9.25 12.7383 8.21429 13.5036 7.53571C14.2689 6.85714 15.2383 6.64286 16.0036 6.64286C16.7689 6.64286 17.7383 6.85714 18.5036 7.53571C19.2689 8.21429 19.2689 9.25 19.2689 9.25V15.3414H17.523Z" />
                </svg>
                Download for Android
              </Button>

              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="bg-white/5 border-white/10 hover:bg-white/10 text-white">
                    <QrCode className="mr-2 h-5 w-5" />
                    Scan QR Code
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-[#0A0A14] border border-white/10">
                  <div className="p-6 text-center">
                    <h3 className="text-xl font-bold text-white mb-4">Scan to Download</h3>
                    <div className="bg-white p-4 rounded-lg inline-block mb-4">
                      <Image
                        src="/placeholder.svg?height=200&width=200"
                        alt="QR Code"
                        width={200}
                        height={200}
                        className="mx-auto"
                      />
                    </div>
                    <p className="text-white/70">
                      Scan this QR code with your phone camera to download the AffiliateMarketing.com app
                    </p>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="mt-6 text-white/40 text-sm">
              Available on iOS 14+ and Android 8+. App Store release: June 2025.
            </div>
          </div>

          {/* App preview */}
          <div className="w-full lg:w-1/2 flex justify-center">
            <div className="relative">
              {/* Phone frame */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7 }}
                className="relative z-10"
              >
                <div className="w-[280px] h-[580px] bg-black rounded-[40px] p-3 shadow-xl border-4 border-gray-800">
                  {/* Screen */}
                  <div className="w-full h-full rounded-[32px] overflow-hidden relative">
                    {/* Tab switcher */}
                    <div className="absolute top-0 left-0 right-0 z-20 flex justify-center p-2 bg-black/80 backdrop-blur-md">
                      <div className="flex bg-gray-800 rounded-full p-1">
                        <button
                          onClick={() => setActiveTab("ios")}
                          className={`px-4 py-1 rounded-full text-sm font-medium transition-colors ${
                            activeTab === "ios" ? "bg-[#00F0FF] text-black" : "text-white/70 hover:text-white"
                          }`}
                        >
                          iOS
                        </button>
                        <button
                          onClick={() => setActiveTab("android")}
                          className={`px-4 py-1 rounded-full text-sm font-medium transition-colors ${
                            activeTab === "android" ? "bg-[#00F0FF] text-black" : "text-white/70 hover:text-white"
                          }`}
                        >
                          Android
                        </button>
                      </div>
                    </div>

                    {/* App screens */}
                    <div className="w-full h-full bg-[#0A0A14]">
                      <Image
                        src={`/placeholder.svg?height=580&width=280&text=${activeTab === "ios" ? "iOS App" : "Android App"}`}
                        alt={`${activeTab === "ios" ? "iOS" : "Android"} App Preview`}
                        width={280}
                        height={580}
                        className="object-cover"
                      />
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Decorative elements */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[320px] h-[320px] rounded-full bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 blur-xl"></div>
              <div className="absolute top-20 right-10 w-20 h-20 rounded-full bg-[#00F0FF]/30 blur-xl animate-pulse"></div>
              <div
                className="absolute bottom-20 left-10 w-16 h-16 rounded-full bg-[#0033CC]/30 blur-xl animate-pulse"
                style={{ animationDelay: "1.5s" }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

