"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Quote } from "lucide-react"

interface SuccessStory {
  id: string
  name: string
  title: string
  company: string
  image: string
  challenge: string
  solution: string
  results: {
    text: string
    stats: {
      label: string
      value: string
    }[]
  }
  testimonial: string
}

export function SuccessStories() {
  const [activeTab, setActiveTab] = useState("brian-tate")

  const stories: SuccessStory[] = [
    {
      id: "brian-tate",
      name: "Brian Tate",
      title: "Founder & CEO",
      company: "Oats Overnight",
      image: "/images/founders/brian-tate.png",
      challenge:
        "In 2016, Brian Tate was a busy entrepreneur struggling to find time for a nutritious breakfast. After creating a protein-packed overnight oats recipe for himself, he realized there was a market opportunity for convenient, healthy breakfast options. However, as a new DTC brand, Oats Overnight faced significant challenges in customer acquisition costs and building brand awareness in the competitive nutrition space.",
      solution:
        "Brian partnered with AffiliateMarketing.com to develop a comprehensive affiliate strategy. The platform helped Oats Overnight recruit fitness influencers, nutrition bloggers, and health-focused content creators who aligned with their brand values. The instant payout feature was particularly attractive to micro-influencers who previously avoided affiliate programs due to lengthy payment terms.",
      results: {
        text: "Within 18 months of launching their affiliate program, Oats Overnight saw remarkable growth. The brand expanded from their original flavors to over 30 SKUs and secured distribution deals with major retailers. Their affiliate channel now accounts for 35% of their total e-commerce revenue.",
        stats: [
          { label: "Revenue Growth", value: "428%" },
          { label: "Conversion Rate", value: "12.3%" },
          { label: "Customer Acquisition Cost", value: "-41%" },
          { label: "Affiliate Channel ROI", value: "11.2x" },
        ],
      },
      testimonial:
        "The affiliate program completely transformed our business. We went from struggling with expensive paid ads to having a community of passionate advocates driving consistent sales. The instant payout feature helped us attract quality partners who might have otherwise passed on traditional affiliate programs.",
    },
    {
      id: "christy-buss",
      name: "Christy Buss",
      title: "Founder",
      company: "HEDO Skincare",
      image: "/images/founders/christy-buss.png",
      challenge:
        "After developing a revolutionary peptide moisturizer that addressed her own skin concerns, Christy Buss launched HEDO Skincare in 2021. Despite having a premium product with exceptional results, HEDO struggled to break through in the oversaturated skincare market. Traditional influencer marketing proved expensive and inconsistent, while paid advertising yielded diminishing returns as privacy changes impacted targeting capabilities.",
      solution:
        "Christy implemented a data-driven affiliate strategy through AffiliateMarketing.com. The platform's advanced analytics helped identify the most effective content creators for HEDO's target demographic. Rather than pursuing mass exposure, HEDO focused on authentic partnerships with dermatologists, estheticians, and skincare enthusiasts who could credibly communicate the science behind their formulations.",
      results: {
        text: "HEDO Skincare experienced steady, sustainable growth through their affiliate program. Their approach of prioritizing education and authenticity over flashy promotions resonated with consumers seeking effective skincare solutions. The brand has maintained impressive profit margins while expanding their product line.",
        stats: [
          { label: "Year-over-Year Growth", value: "217%" },
          { label: "Average Order Value", value: "+32%" },
          { label: "Customer Retention", value: "76%" },
          { label: "New Product Launch Success", value: "3.8x" },
        ],
      },
      testimonial:
        "What I love about our affiliate program is the quality of relationships we've built. These aren't just promoters—they're genuine believers in our products who create thoughtful content that educates consumers. The platform's analytics have been invaluable in helping us understand which messaging and product features resonate most with different audiences.",
    },
    {
      id: "tiffany-hollywood",
      name: "Tiffany",
      title: "Founder & Formulator",
      company: "Hollywood Skin Bar",
      image: "/images/founders/tiffany-hollywood.png",
      challenge:
        "Tiffany launched Hollywood Skin Bar with a vision to create vibrant, effective body care products that stood out in a crowded market. Despite creating innovative formulations like her signature Pink Lemon Drop Body Whip, the brand struggled with seasonal sales fluctuations and high customer acquisition costs. As a self-funded entrepreneur, Tiffany needed marketing solutions that wouldn't require massive upfront investment.",
      solution:
        "Tiffany embraced AffiliateMarketing.com's platform to build a diverse affiliate network. She implemented a tiered commission structure that rewarded long-term partners and high performers. The platform's content creation tools helped affiliates showcase her colorful products effectively across social media. Tiffany also utilized the platform's A/B testing features to optimize affiliate landing pages and promotional messaging.",
      results: {
        text: "Hollywood Skin Bar transformed from a regional brand to a national presence with devoted customers across the country. The affiliate program helped smooth out seasonal sales fluctuations by creating consistent revenue streams. Tiffany has since expanded into retail partnerships while maintaining strong direct-to-consumer sales.",
        stats: [
          { label: "Social Media Visibility", value: "+385%" },
          { label: "Repeat Purchase Rate", value: "68%" },
          { label: "Off-Season Sales", value: "+127%" },
          { label: "Product Line Expansion", value: "8 New SKUs" },
        ],
      },
      testimonial:
        "As a founder wearing multiple hats, I needed a marketing channel that could deliver results without requiring constant hands-on management. Our affiliate program has become our most reliable growth driver. The instant payout feature has been a game-changer for attracting quality partners who promote our products with genuine enthusiasm.",
    },
    {
      id: "dan-fleyshman",
      name: "Dan Fleyshman",
      title: "Affiliate Manager",
      company: "Influencer Campaigns",
      image: "/images/founders/dan-fleyshman.png",
      challenge:
        "Dan Fleyshman, a veteran entrepreneur and marketing expert, managed affiliate programs for multiple influencer-led brands. He faced significant challenges with tracking attribution across various platforms, managing timely payments to hundreds of affiliates, and scaling programs efficiently. Traditional affiliate networks lacked the flexibility and influencer-focused features his clients needed.",
      solution:
        "Dan implemented AffiliateMarketing.com's enterprise solutions across his portfolio of brands. The platform's unified dashboard allowed his team to manage multiple programs simultaneously while maintaining brand-specific customizations. The instant payout system dramatically improved affiliate satisfaction and retention, while the advanced fraud detection features protected brands from invalid traffic and commission abuse.",
      results: {
        text: "Dan's strategic approach to affiliate marketing has generated millions in revenue for his clients. By centralizing management on a single platform, his team improved operational efficiency while delivering better experiences for both brands and affiliates. The data-driven insights have allowed for continuous optimization of commission structures and promotional strategies.",
        stats: [
          { label: "Affiliate Retention", value: "94%" },
          { label: "Program Management Efficiency", value: "+62%" },
          { label: "Invalid Traffic Reduction", value: "-87%" },
          { label: "Average Program Growth", value: "3.4x YoY" },
        ],
      },
      testimonial:
        "After managing affiliate programs on various platforms for over a decade, I've never seen a solution that so perfectly addresses the needs of modern influencer marketing. The instant payment feature alone has transformed how we recruit partners. We're now able to attract premium creators who previously avoided affiliate marketing due to payment delays and tracking concerns.",
    },
  ]

  return (
    <section className="py-24 bg-gradient-to-b from-[#0A0A14] to-[#0A1A2F]">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            SUCCESS STORIES
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Real Results from Real Entrepreneurs
          </h2>
          <p className="text-base md:text-lg text-white/70">
            Discover how these innovative founders transformed their businesses through strategic affiliate
            partnerships.
          </p>
        </div>

        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex justify-center mb-12">
            <TabsList className="bg-white/5 border border-white/10 p-1">
              {stories.map((story) => (
                <TabsTrigger
                  key={story.id}
                  value={story.id}
                  className="data-[state=active]:bg-white/10 data-[state=active]:text-white text-white/70 relative px-4 py-2"
                >
                  <span className="relative z-10">{story.name}</span>
                  {activeTab === story.id && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute inset-0 bg-white/10 rounded-sm"
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          {stories.map((story) => (
            <TabsContent key={story.id} value={story.id} className="mt-0">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                <div className="lg:col-span-1">
                  <div className="bg-white/5 border border-white/10 rounded-xl p-6 sticky top-24">
                    <div className="aspect-square rounded-lg overflow-hidden mb-6 bg-gradient-to-br from-[#0033CC]/20 to-[#00F0FF]/20 p-1">
                      <img
                        src={story.image || "/placeholder.svg"}
                        alt={story.name}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    </div>
                    <h3 className="text-xl font-semibold mb-1">{story.name}</h3>
                    <p className="text-white/60 mb-4">
                      {story.title}, {story.company}
                    </p>

                    <div className="pt-4 border-t border-white/10">
                      <div className="flex items-start space-x-2 text-white/80 mb-4">
                        <Quote className="h-5 w-5 text-[#00F0FF] mt-1 flex-shrink-0" />
                        <p className="italic text-sm">{story.testimonial}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-2">
                  <div className="space-y-8">
                    <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                      <h4 className="text-lg font-medium mb-4 flex items-center">
                        <span className="bg-[#FF3366]/20 text-[#FF3366] w-8 h-8 rounded-full flex items-center justify-center mr-3">
                          1
                        </span>
                        The Challenge
                      </h4>
                      <p className="text-white/80">{story.challenge}</p>
                    </div>

                    <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                      <h4 className="text-lg font-medium mb-4 flex items-center">
                        <span className="bg-[#FFB800]/20 text-[#FFB800] w-8 h-8 rounded-full flex items-center justify-center mr-3">
                          2
                        </span>
                        The Solution
                      </h4>
                      <p className="text-white/80">{story.solution}</p>
                    </div>

                    <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                      <h4 className="text-lg font-medium mb-4 flex items-center">
                        <span className="bg-[#00F0FF]/20 text-[#00F0FF] w-8 h-8 rounded-full flex items-center justify-center mr-3">
                          3
                        </span>
                        The Results
                      </h4>
                      <p className="text-white/80 mb-6">{story.results.text}</p>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {story.results.stats.map((stat, index) => (
                          <div key={index} className="bg-white/5 border border-white/10 rounded-lg p-4 text-center">
                            <p className="text-2xl font-bold text-[#00F0FF]">{stat.value}</p>
                            <p className="text-xs text-white/60">{stat.label}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex justify-center">
                      <button className="group flex items-center space-x-2 text-[#00F0FF] hover:text-white transition-colors">
                        <span>Read the full case study</span>
                        <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  )
}

