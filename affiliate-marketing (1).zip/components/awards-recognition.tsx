"use client"

import type React from "react"

import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import { Award, Star, TrendingUp, Trophy } from "lucide-react"

interface AwardItem {
  title: string
  organization: string
  date: string
  logo: string
  description: string
  icon: React.ReactNode
}

export function AwardsRecognition() {
  const awards: AwardItem[] = [
    {
      title: "Most Innovative Affiliate Platform",
      organization: "MarTech Breakthrough Awards",
      date: "April 2025",
      logo: "/placeholder.svg?height=60&width=120",
      description: "Recognized for revolutionary approach to affiliate marketing technology",
      icon: <Award className="h-8 w-8 text-yellow-400" />,
    },
    {
      title: "Best Fintech Integration",
      organization: "Affiliate Summit",
      date: "May 2025",
      logo: "/placeholder.svg?height=60&width=120",
      description: "Awarded for our instant payment system and financial technology",
      icon: <TrendingUp className="h-8 w-8 text-[#00F0FF]" />,
    },
    {
      title: "Top Creator Economy Platform",
      organization: "Creator Economy Awards",
      date: "July 2025",
      logo: "/placeholder.svg?height=60&width=120",
      description: "Voted #1 platform for content creators monetizing through affiliate marketing",
      icon: <Star className="h-8 w-8 text-purple-400" />,
    },
    {
      title: "Excellence in User Experience",
      organization: "Digital Experience Awards",
      date: "September 2025",
      logo: "/placeholder.svg?height=60&width=120",
      description: "Honored for exceptional user interface and platform experience",
      icon: <Trophy className="h-8 w-8 text-amber-500" />,
    },
  ]

  return (
    <section className="py-24 bg-gradient-to-b from-[#0A1A2F]/30 to-[#0A0A14]">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            AWARDS
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Awards & Recognition
          </h2>
          <p className="text-base md:text-lg text-white/70">
            Our platform has been recognized by industry leaders for innovation and excellence.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {awards.map((award, index) => (
            <motion.div
              key={award.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="bg-gradient-to-br from-[#0A1A2F]/80 to-[#0A0A14]/95 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-[#00F0FF]/30 transition-all duration-300"
            >
              <div className="flex items-start mb-4">
                <div className="mr-4 p-3 rounded-lg bg-white/5">{award.icon}</div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-1">{award.title}</h3>
                  <div className="flex items-center text-white/60 text-sm">
                    <span>{award.organization}</span>
                    <span className="mx-2">•</span>
                    <span>{award.date}</span>
                  </div>
                </div>
              </div>

              <p className="text-white/70 mb-4">{award.description}</p>

              <div className="mt-4 pt-4 border-t border-white/10">
                <div className="h-[60px] relative grayscale hover:grayscale-0 transition-all duration-300 opacity-70 hover:opacity-100">
                  <Image
                    src={award.logo || "/placeholder.svg"}
                    alt={award.organization}
                    fill
                    className="object-contain"
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

