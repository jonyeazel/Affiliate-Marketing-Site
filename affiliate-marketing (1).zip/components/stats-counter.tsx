"use client"

import { motion } from "framer-motion"
import { AnimatedCounter } from "@/components/animated-counter"

interface Stat {
  label: string
  value: number
  suffix?: string
  decimals?: number
  prefix?: string
}

export function StatsCounter() {
  const stats: Stat[] = [
    { label: "Affiliates on Platform", value: 15000, suffix: "+", prefix: "" },
    { label: "Average Commission Rate", value: 12.5, suffix: "%", decimals: 1, prefix: "" },
    { label: "Brands Onboarded", value: 2500, suffix: "+", prefix: "" },
    { label: "Paid Out to Affiliates", value: 8.5, suffix: "M", decimals: 1, prefix: "$" },
  ]

  return (
    <div className="py-16 bg-gradient-to-r from-[#0A1A2F] to-[#0A0A14]">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="text-center"
            >
              <div className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF] mb-2">
                {stat.prefix && <span className="inline-block">{stat.prefix}</span>}
                <AnimatedCounter end={stat.value} decimals={stat.decimals || 0} suffix={stat.suffix || ""} />
              </div>
              <p className="text-white/60 text-sm md:text-base">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

