"use client"

import { ArrowUpRight } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface OpportunityCardProps {
  name: string
  category: string
  commission: string
  matchScore: number
  onApplyNow: () => void
}

export default function OpportunityCard({ name, category, commission, matchScore, onApplyNow }: OpportunityCardProps) {
  return (
    <Card className="overflow-hidden">
      <div className="bg-muted p-4 flex items-center justify-center">
        <div className="w-16 h-16 rounded bg-background flex items-center justify-center">
          <img src="/placeholder.svg?height=64&width=64" alt={name} className="max-w-[80%] max-h-[80%]" />
        </div>
      </div>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <Badge variant="outline">{category}</Badge>
          <Badge className="bg-primary/10 text-primary">{matchScore}% Match</Badge>
        </div>
        <h3 className="font-medium text-lg mb-2">{name}</h3>
        <div className="text-sm text-muted-foreground mb-2">Commission: {commission}</div>
        <div className="text-sm text-muted-foreground">Matched based on your content and audience</div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex gap-2">
        <Button className="w-full" onClick={onApplyNow}>
          Apply Now
        </Button>
        <Button variant="outline" size="icon">
          <ArrowUpRight className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  )
}

