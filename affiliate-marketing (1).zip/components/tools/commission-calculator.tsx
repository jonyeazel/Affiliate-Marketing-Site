"use client"

import { useState } from "react"
import { Calculator, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function CommissionCalculator() {
  const [calculationType, setCalculationType] = useState("fixed")
  const [monthlyVisitors, setMonthlyVisitors] = useState(10000)
  const [conversionRate, setConversionRate] = useState(2)
  const [averageOrderValue, setAverageOrderValue] = useState(50)
  const [commissionRate, setCommissionRate] = useState(10)
  const [commissionAmount, setCommissionAmount] = useState(15)
  const [recurringCommission, setRecurringCommission] = useState(false)
  const [recurringMonths, setRecurringMonths] = useState(3)
  const [recurringRate, setRecurringRate] = useState(50)

  // Calculate results
  const calculateResults = () => {
    const conversions = (monthlyVisitors * conversionRate) / 100

    if (calculationType === "fixed") {
      const monthlyEarnings = conversions * commissionAmount
      const annualEarnings = monthlyEarnings * 12

      if (recurringCommission) {
        // Calculate recurring commissions
        let totalRecurringEarnings = 0
        for (let i = 1; i < recurringMonths; i++) {
          totalRecurringEarnings += conversions * commissionAmount * (recurringRate / 100)
        }

        return {
          conversions,
          monthlyEarnings: monthlyEarnings + totalRecurringEarnings,
          annualEarnings: (monthlyEarnings + totalRecurringEarnings) * 12,
          earningsPerVisitor: (monthlyEarnings + totalRecurringEarnings) / monthlyVisitors,
        }
      }

      return {
        conversions,
        monthlyEarnings,
        annualEarnings,
        earningsPerVisitor: monthlyEarnings / monthlyVisitors,
      }
    } else {
      const monthlyEarnings = conversions * averageOrderValue * (commissionRate / 100)
      const annualEarnings = monthlyEarnings * 12

      if (recurringCommission) {
        // Calculate recurring commissions
        let totalRecurringEarnings = 0
        for (let i = 1; i < recurringMonths; i++) {
          totalRecurringEarnings += conversions * averageOrderValue * (commissionRate / 100) * (recurringRate / 100)
        }

        return {
          conversions,
          monthlyEarnings: monthlyEarnings + totalRecurringEarnings,
          annualEarnings: (monthlyEarnings + totalRecurringEarnings) * 12,
          earningsPerVisitor: (monthlyEarnings + totalRecurringEarnings) / monthlyVisitors,
        }
      }

      return {
        conversions,
        monthlyEarnings,
        annualEarnings,
        earningsPerVisitor: monthlyEarnings / monthlyVisitors,
      }
    }
  }

  const results = calculateResults()

  return (
    <div className="space-y-6">
      <Tabs defaultValue="fixed" onValueChange={(value) => setCalculationType(value)}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="fixed">Fixed Commission</TabsTrigger>
          <TabsTrigger value="percentage">Percentage Commission</TabsTrigger>
        </TabsList>

        <div className="mt-6 grid gap-6 md:grid-cols-2">
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="monthly-visitors">Monthly Visitors</Label>
                <span className="text-sm text-muted-foreground">{monthlyVisitors.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-2">
                <Input
                  id="monthly-visitors"
                  type="number"
                  value={monthlyVisitors}
                  onChange={(e) => setMonthlyVisitors(Number.parseInt(e.target.value) || 0)}
                  className="w-full"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Label htmlFor="conversion-rate">Conversion Rate (%)</Label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="ml-1 h-4 w-4 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="max-w-xs">
                          The percentage of visitors who make a purchase through your affiliate link.
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <span className="text-sm text-muted-foreground">{conversionRate}%</span>
              </div>
              <div className="flex items-center gap-2">
                <Slider
                  id="conversion-rate"
                  min={0.1}
                  max={10}
                  step={0.1}
                  value={[conversionRate]}
                  onValueChange={(value) => setConversionRate(value[0])}
                />
              </div>
            </div>

            {calculationType === "percentage" && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="average-order-value">Average Order Value ($)</Label>
                  <span className="text-sm text-muted-foreground">${averageOrderValue}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Input
                    id="average-order-value"
                    type="number"
                    value={averageOrderValue}
                    onChange={(e) => setAverageOrderValue(Number.parseInt(e.target.value) || 0)}
                    className="w-full"
                  />
                </div>
              </div>
            )}

            {calculationType === "percentage" ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="commission-rate">Commission Rate (%)</Label>
                  <span className="text-sm text-muted-foreground">{commissionRate}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <Slider
                    id="commission-rate"
                    min={1}
                    max={50}
                    step={1}
                    value={[commissionRate]}
                    onValueChange={(value) => setCommissionRate(value[0])}
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="commission-amount">Commission Amount ($)</Label>
                  <span className="text-sm text-muted-foreground">${commissionAmount}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Input
                    id="commission-amount"
                    type="number"
                    value={commissionAmount}
                    onChange={(e) => setCommissionAmount(Number.parseInt(e.target.value) || 0)}
                    className="w-full"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="recurring-commission"
                  checked={recurringCommission}
                  onChange={(e) => setRecurringCommission(e.target.checked)}
                  className="mr-2"
                />
                <Label htmlFor="recurring-commission">Include Recurring Commissions</Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Info className="ml-1 h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="max-w-xs">
                        For subscription products where you earn commissions on recurring payments.
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>

              {recurringCommission && (
                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="space-y-2">
                    <Label htmlFor="recurring-months">Number of Months</Label>
                    <Select
                      value={recurringMonths.toString()}
                      onValueChange={(value) => setRecurringMonths(Number.parseInt(value))}
                    >
                      <SelectTrigger id="recurring-months">
                        <SelectValue placeholder="Select months" />
                      </SelectTrigger>
                      <SelectContent>
                        {[2, 3, 6, 12, 24].map((month) => (
                          <SelectItem key={month} value={month.toString()}>
                            {month} months
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="recurring-rate">Retention Rate (%)</Label>
                      <span className="text-sm text-muted-foreground">{recurringRate}%</span>
                    </div>
                    <Slider
                      id="recurring-rate"
                      min={10}
                      max={100}
                      step={5}
                      value={[recurringRate]}
                      onValueChange={(value) => setRecurringRate(value[0])}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          <div>
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium">Results</h3>
                    <Calculator className="h-5 w-5 text-muted-foreground" />
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="text-sm text-muted-foreground">Monthly Conversions</div>
                      <div className="text-2xl font-bold">{results.conversions.toFixed(0)}</div>
                    </div>

                    <div>
                      <div className="text-sm text-muted-foreground">Monthly Earnings</div>
                      <div className="text-3xl font-bold text-primary">${results.monthlyEarnings.toFixed(2)}</div>
                    </div>

                    <div>
                      <div className="text-sm text-muted-foreground">Annual Earnings</div>
                      <div className="text-2xl font-bold">${results.annualEarnings.toFixed(2)}</div>
                    </div>

                    <div>
                      <div className="text-sm text-muted-foreground">Earnings Per Visitor</div>
                      <div className="text-xl font-bold">${results.earningsPerVisitor.toFixed(3)}</div>
                    </div>
                  </div>

                  <div className="rounded-md bg-primary/10 p-4">
                    <h4 className="font-medium text-primary mb-2">Optimization Tip</h4>
                    <p className="text-sm">
                      {conversionRate < 2
                        ? "Increasing your conversion rate by just 1% could significantly boost your earnings. Consider optimizing your content and call-to-actions."
                        : conversionRate >= 2 && conversionRate < 5
                          ? "Your conversion rate is good. To increase earnings further, focus on driving more targeted traffic to your affiliate offers."
                          : "Your conversion rate is excellent! Consider expanding to additional affiliate programs or products to maximize your earnings."}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="mt-4 text-center">
              <Button>Save Calculation</Button>
            </div>
          </div>
        </div>
      </Tabs>
    </div>
  )
}

