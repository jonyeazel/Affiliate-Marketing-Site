"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { NavSidebar } from "@/components/nav-sidebar"
import { ContextNav } from "@/components/context-nav"

interface DashboardShellProps {
  children: React.ReactNode
}

export function DashboardShell({ children }: DashboardShellProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  return (
    <div className="flex h-screen bg-[#0A0A14] text-white">
      {/* Sidebar */}
      <motion.div
        initial={{ width: "16rem" }}
        animate={{ width: sidebarCollapsed ? "5rem" : "16rem" }}
        transition={{ duration: 0.3, ease: [0.32, 0.72, 0, 1] }}
        className="relative h-screen flex-shrink-0 overflow-hidden"
      >
        <NavSidebar />

        {/* Collapse Toggle */}
        <button
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className="absolute right-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-6 h-12 bg-[#0A1A2F] border border-white/10 rounded-full flex items-center justify-center hover:bg-[#0033CC]/20 transition-colors"
        >
          {sidebarCollapsed ? (
            <ChevronRight className="h-4 w-4 text-white/70" />
          ) : (
            <ChevronLeft className="h-4 w-4 text-white/70" />
          )}
        </button>
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-white/10 bg-[#0A0A14] flex items-center justify-between px-6">
          <h1 className="text-xl font-bold">Dashboard</h1>
          <ContextNav />
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto p-6 bg-[#050A14]">{children}</main>
      </div>
    </div>
  )
}

