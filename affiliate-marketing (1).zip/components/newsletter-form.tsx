"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { ArrowRight, Check, Mail } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { PulseEffect } from "@/components/pulse-effect"

export function NewsletterForm() {
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      setIsSubmitted(true)
      setEmail("")

      // Reset success message after 5 seconds
      setTimeout(() => {
        setIsSubmitted(false)
      }, 5000)
    }, 1500)
  }

  return (
    <div className="relative overflow-hidden rounded-xl border border-white/10 bg-gradient-to-br from-[#0A1A2F]/40 to-[#0A0A14]/80 backdrop-blur-sm p-8">
      <div className="absolute -top-24 -right-24 w-64 h-64 bg-[#00F0FF] rounded-full opacity-10 blur-3xl"></div>

      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-full bg-[#00F0FF]/20 flex items-center justify-center">
            <Mail className="h-5 w-5 text-[#00F0FF]" />
          </div>
          <h3 className="text-xl font-bold">Stay Updated</h3>
        </div>

        <p className="text-white/70 mb-6">Get the latest news, updates, and exclusive offers directly to your inbox.</p>

        {isSubmitted ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 text-[#00F0FF] bg-[#00F0FF]/10 p-3 rounded-lg"
          >
            <Check className="h-5 w-5" />
            <span>Thanks for subscribing! We'll be in touch soon.</span>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <Input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full bg-white/10 border-white/20 focus:border-[#00F0FF] h-12 pl-10"
              />
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50">
                <Mail className="h-4 w-4" />
              </div>
            </div>

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90 hover:scale-105 transition-all duration-300 group relative overflow-hidden h-12"
            >
              <span className="relative z-10">{isLoading ? "Subscribing..." : "Subscribe to Newsletter"}</span>
              {!isLoading && (
                <ArrowRight className="relative z-10 ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
              )}
              <PulseEffect />
            </Button>
          </form>
        )}

        <p className="text-xs text-white/50 mt-4">We respect your privacy. Unsubscribe at any time.</p>
      </div>
    </div>
  )
}

