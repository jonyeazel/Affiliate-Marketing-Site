"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { BarChart3, Users, Zap, ArrowUpRight } from "lucide-react"

export default function PlatformPreview() {
  const [activeTab, setActiveTab] = useState("analytics")

  return (
    <div className="rounded-lg border bg-card p-1 shadow-sm">
      <Tabs defaultValue="analytics" className="w-full" onValueChange={setActiveTab}>
        <div className="flex items-center justify-between px-4 pt-3">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger
              value="analytics"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <BarChart3 className="mr-2 h-4 w-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger
              value="partnerships"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <Users className="mr-2 h-4 w-4" />
              Partnerships
            </TabsTrigger>
            <TabsTrigger
              value="campaigns"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <Zap className="mr-2 h-4 w-4" />
              Campaigns
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="analytics" className="mt-6 p-4">
          <div className="aspect-video overflow-hidden rounded-lg border bg-background">
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-4">Performance Dashboard</h3>
              <div className="grid grid-cols-3 gap-4 mb-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">Revenue</div>
                    <div className="text-2xl font-bold">$12,486</div>
                    <div className="text-xs text-green-500 flex items-center mt-1">
                      +24% <ArrowUpRight className="h-3 w-3 ml-1" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">Conversions</div>
                    <div className="text-2xl font-bold">1,843</div>
                    <div className="text-xs text-green-500 flex items-center mt-1">
                      +12% <ArrowUpRight className="h-3 w-3 ml-1" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">Avg. Commission</div>
                    <div className="text-2xl font-bold">$6.78</div>
                    <div className="text-xs text-green-500 flex items-center mt-1">
                      +8% <ArrowUpRight className="h-3 w-3 ml-1" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="h-48 w-full bg-muted/30 rounded-md flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <BarChart3 className="h-10 w-10 mx-auto mb-2 opacity-50" />
                  <p>Interactive Analytics Dashboard</p>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="partnerships" className="mt-6 p-4">
          <div className="aspect-video overflow-hidden rounded-lg border bg-background">
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-4">Brand Partnerships</h3>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">Active Partnerships</div>
                    <div className="text-2xl font-bold">24</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">Recommended Matches</div>
                    <div className="text-2xl font-bold">18</div>
                  </CardContent>
                </Card>
              </div>

              <div className="h-48 w-full bg-muted/30 rounded-md flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <Users className="h-10 w-10 mx-auto mb-2 opacity-50" />
                  <p>Brand Partnership Marketplace</p>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="campaigns" className="mt-6 p-4">
          <div className="aspect-video overflow-hidden rounded-lg border bg-background">
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-4">Active Campaigns</h3>
              <div className="grid grid-cols-3 gap-4 mb-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">Total Campaigns</div>
                    <div className="text-2xl font-bold">12</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">Click-through Rate</div>
                    <div className="text-2xl font-bold">4.2%</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">Conversion Rate</div>
                    <div className="text-2xl font-bold">2.8%</div>
                  </CardContent>
                </Card>
              </div>

              <div className="h-48 w-full bg-muted/30 rounded-md flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <Zap className="h-10 w-10 mx-auto mb-2 opacity-50" />
                  <p>Campaign Management Dashboard</p>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

