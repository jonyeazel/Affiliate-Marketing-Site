"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { DollarSign, Clock, Users, Zap, CheckCircle, ArrowRight, Star, ShieldCheck } from "lucide-react"

interface Collab {
  id: number
  title: string
  brand: {
    name: string
    logo: string
    verified: boolean
  }
  category: string
  paymentType: string
  paymentValue: string
  requirements: string[]
  applicants: number
  maxApplicants: number
  timeLeft: string
  perks: string[]
}

export default function BrandCollabs() {
  const collabs: Collab[] = [
    {
      id: 1,
      title: "Lifestyle Content Creator Partnership",
      brand: {
        name: "Urban Outfitters",
        logo: "/placeholder.svg?height=40&width=40",
        verified: true,
      },
      category: "Fashion",
      paymentType: "Flat Fee + Commission",
      paymentValue: "$1,500 + 15%",
      requirements: [
        "10K+ followers on Instagram or TikTok",
        "Fashion/Lifestyle content focus",
        "18-30 age demographic",
        "Previous brand collaboration experience",
      ],
      applicants: 87,
      maxApplicants: 100,
      timeLeft: "2 days",
      perks: [
        "Free product selection ($500 value)",
        "Featured on brand's social channels",
        "Potential for long-term partnership",
      ],
    },
    {
      id: 2,
      title: "Gaming Peripheral Review Program",
      brand: {
        name: "TechGear",
        logo: "/placeholder.svg?height=40&width=40",
        verified: true,
      },
      category: "Gaming",
      paymentType: "Revenue Share",
      paymentValue: "25% + Bonus Tiers",
      requirements: [
        "5K+ subscribers on YouTube or Twitch",
        "Gaming content focus",
        "At least 3 tech reviews in portfolio",
        "Engagement rate above 5%",
      ],
      applicants: 42,
      maxApplicants: 75,
      timeLeft: "5 days",
      perks: [
        "Keep all review products ($800+ value)",
        "Early access to upcoming releases",
        "Invitation to annual creator summit",
      ],
    },
    {
      id: 3,
      title: "Wellness Challenge Sponsorship",
      brand: {
        name: "VitalLife",
        logo: "/placeholder.svg?height=40&width=40",
        verified: false,
      },
      category: "Health",
      paymentType: "Tiered Payment",
      paymentValue: "$500-$2,000",
      requirements: [
        "3K+ followers on any platform",
        "Health/Wellness content focus",
        "Authentic engagement with audience",
        "Willing to try 30-day product challenge",
      ],
      applicants: 63,
      maxApplicants: 150,
      timeLeft: "7 days",
      perks: [
        "3-month product supply ($350 value)",
        "Wellness coach consultation",
        "Custom affiliate code with tracking",
      ],
    },
  ]

  const [expandedCollab, setExpandedCollab] = useState<number | null>(null)

  const toggleExpand = (id: number) => {
    if (expandedCollab === id) {
      setExpandedCollab(null)
    } else {
      setExpandedCollab(id)
    }
  }

  return (
    <div className="space-y-6">
      {collabs.map((collab) => (
        <Card
          key={collab.id}
          className={`bg-[#111111] border-white/10 overflow-hidden transition-all duration-300 ${
            expandedCollab === collab.id ? "ring-2 ring-[#FF00FF]/50" : ""
          }`}
        >
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <Avatar className="h-12 w-12 rounded-md">
                <AvatarImage src={collab.brand.logo} alt={collab.brand.name} />
                <AvatarFallback>{collab.brand.name.charAt(0)}</AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-bold text-xl">{collab.title}</h3>
                  <Badge className="bg-[#FF00FF] text-white">{collab.category}</Badge>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-white/70">{collab.brand.name}</span>
                  {collab.brand.verified && <ShieldCheck className="h-4 w-4 text-[#00FFFF]" />}
                </div>

                <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-[#191919] rounded-md p-3">
                    <div className="flex items-center text-sm text-white/60 mb-1">
                      <DollarSign className="h-4 w-4 mr-1 text-[#FFFF00]" />
                      Payment
                    </div>
                    <div>
                      <div className="font-medium">{collab.paymentType}</div>
                      <div className="text-[#FFFF00] font-bold">{collab.paymentValue}</div>
                    </div>
                  </div>

                  <div className="bg-[#191919] rounded-md p-3">
                    <div className="flex items-center text-sm text-white/60 mb-1">
                      <Users className="h-4 w-4 mr-1 text-[#00FFFF]" />
                      Applicants
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium">
                          {collab.applicants}/{collab.maxApplicants}
                        </span>
                        <span className="text-sm text-white/60">
                          {Math.round((collab.applicants / collab.maxApplicants) * 100)}% full
                        </span>
                      </div>
                      <Progress
                        value={(collab.applicants / collab.maxApplicants) * 100}
                        className="h-2 bg-white/10"
                        indicatorClassName="bg-[#00FFFF]"
                      />
                    </div>
                  </div>

                  <div className="bg-[#191919] rounded-md p-3">
                    <div className="flex items-center text-sm text-white/60 mb-1">
                      <Clock className="h-4 w-4 mr-1 text-[#FF00FF]" />
                      Application Deadline
                    </div>
                    <div className="font-medium">Closes in {collab.timeLeft}</div>
                  </div>
                </div>

                {expandedCollab === collab.id && (
                  <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-3 flex items-center">
                        <CheckCircle className="h-4 w-4 mr-2 text-[#00FFFF]" />
                        Requirements
                      </h4>
                      <ul className="space-y-2">
                        {collab.requirements.map((req, index) => (
                          <li key={index} className="flex items-start">
                            <span className="text-[#00FFFF] mr-2">•</span>
                            <span className="text-white/80">{req}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-medium mb-3 flex items-center">
                        <Star className="h-4 w-4 mr-2 text-[#FFFF00]" />
                        Perks & Benefits
                      </h4>
                      <ul className="space-y-2">
                        {collab.perks.map((perk, index) => (
                          <li key={index} className="flex items-start">
                            <span className="text-[#FFFF00] mr-2">•</span>
                            <span className="text-white/80">{perk}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>

          <CardFooter className="p-4 pt-0 flex flex-col sm:flex-row gap-3">
            <Button className="flex-1 bg-gradient-to-r from-[#FF00FF] to-[#00FFFF] text-black font-bold">
              <Zap className="mr-2 h-4 w-4" />
              Apply Now
            </Button>
            <Button variant="outline" className="flex-1 border-white/20" onClick={() => toggleExpand(collab.id)}>
              {expandedCollab === collab.id ? "Show Less" : "View Details"}
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

