"use client"

import type React from "react"

import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import { Calendar, CheckCircle, Clock, ArrowRight } from "lucide-react"

interface RoadmapItem {
  title: string
  description: string
  date: string
  status: "completed" | "in-progress" | "upcoming"
  icon: React.ReactNode
}

export function Roadmap() {
  const roadmapItems: RoadmapItem[] = [
    {
      title: "Platform Launch",
      description: "Official launch of AffiliateMarketing.com with core features and initial brand partnerships.",
      date: "April 2025",
      status: "completed",
      icon: <CheckCircle className="h-6 w-6 text-green-400" />,
    },
    {
      title: "Mobile App Release",
      description: "Native iOS and Android apps with real-time notifications and on-the-go link management.",
      date: "June 2025",
      status: "in-progress",
      icon: <Clock className="h-6 w-6 text-[#00F0FF]" />,
    },
    {
      title: "AI Content Generator",
      description: "AI-powered tool to create optimized product descriptions and promotional content.",
      date: "August 2025",
      status: "upcoming",
      icon: <Calendar className="h-6 w-6 text-white/60" />,
    },
    {
      title: "Global Expansion",
      description: "Expansion to international markets with multi-currency support and localized partnerships.",
      date: "October 2025",
      status: "upcoming",
      icon: <Calendar className="h-6 w-6 text-white/60" />,
    },
    {
      title: "Blockchain Payments",
      description: "Integration of cryptocurrency payments and blockchain verification for transparent tracking.",
      date: "December 2025",
      status: "upcoming",
      icon: <Calendar className="h-6 w-6 text-white/60" />,
    },
    {
      title: "Enterprise Solutions",
      description: "Advanced tools and dedicated support for enterprise-level affiliate programs and agencies.",
      date: "February 2026",
      status: "upcoming",
      icon: <Calendar className="h-6 w-6 text-white/60" />,
    },
  ]

  return (
    <section className="py-24 bg-gradient-to-b from-[#0A0A14] to-[#0A1A2F]/30">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            ROADMAP
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Our Vision for the Future
          </h2>
          <p className="text-base md:text-lg text-white/70">
            We're constantly evolving. Here's what we're working on to revolutionize affiliate marketing.
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Timeline line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-[#00F0FF] to-[#0033CC]/30 transform md:translate-x-[-0.5px]"></div>

          <div className="space-y-12">
            {roadmapItems.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className={`relative flex flex-col md:flex-row ${
                  index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                {/* Timeline dot */}
                <div className="absolute left-4 md:left-1/2 w-8 h-8 rounded-full bg-[#0A0A14] border-4 border-[#00F0FF] transform translate-x-[-14px] md:translate-x-[-14px] z-10"></div>

                {/* Content */}
                <div className={`ml-16 md:ml-0 md:w-1/2 ${index % 2 === 0 ? "md:pr-12" : "md:pl-12"}`}>
                  <div
                    className={`p-6 rounded-xl ${
                      item.status === "completed"
                        ? "bg-gradient-to-br from-green-400/10 to-green-600/5 border border-green-400/20"
                        : item.status === "in-progress"
                          ? "bg-gradient-to-br from-[#00F0FF]/10 to-[#0033CC]/5 border border-[#00F0FF]/20"
                          : "bg-gradient-to-br from-[#0A1A2F]/40 to-[#0A0A14]/80 border border-white/10"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <h3
                        className={`text-xl font-bold ${
                          item.status === "completed"
                            ? "text-green-400"
                            : item.status === "in-progress"
                              ? "text-[#00F0FF]"
                              : "text-white"
                        }`}
                      >
                        {item.title}
                      </h3>
                      {item.icon}
                    </div>
                    <p className="text-white/70 mb-4">{item.description}</p>
                    <div className="flex items-center text-sm">
                      <Calendar className="h-4 w-4 mr-2 text-white/60" />
                      <span
                        className={`${
                          item.status === "completed"
                            ? "text-green-400"
                            : item.status === "in-progress"
                              ? "text-[#00F0FF]"
                              : "text-white/60"
                        }`}
                      >
                        {item.date}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Empty space for alternating layout */}
                <div className="hidden md:block md:w-1/2"></div>
              </motion.div>
            ))}
          </div>

          {/* Future indicator */}
          <div className="mt-12 text-center relative z-10">
            <div className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 border border-[#00F0FF]/30">
              <span className="text-white mr-2">Future Innovations</span>
              <ArrowRight className="h-4 w-4 text-[#00F0FF]" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

