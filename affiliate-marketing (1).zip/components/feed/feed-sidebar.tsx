"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, BarChart3, Zap, Users, ShoppingBag, Wallet, Award, Settings, HelpCircle, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

export default function FeedSidebar() {
  const pathname = usePathname()

  const navItems = [
    { icon: Home, label: "Home", href: "/feed" },
    { icon: BarChart3, label: "Dashboard", href: "/dashboard" },
    { icon: Zap, label: "Opportunities", href: "/opportunities" },
    { icon: Users, label: "Community", href: "/community" },
    { icon: ShoppingBag, label: "Marketplace", href: "/marketplace" },
    { icon: Wallet, label: "Earnings", href: "/earnings" },
  ]

  const isActive = (href: string) => {
    return pathname === href
  }

  return (
    <div className="space-y-6">
      {/* User Profile */}
      <div className="bg-[#111111] rounded-xl border border-white/10 p-4">
        <div className="flex items-center gap-3 mb-3">
          <Avatar className="h-12 w-12">
            <AvatarImage src="/placeholder.svg?height=48&width=48" alt="User" />
            <AvatarFallback>JD</AvatarFallback>
          </Avatar>
          <div>
            <div className="font-medium">Jordan Doe</div>
            <div className="text-sm text-white/60">@jordandoe</div>
          </div>
        </div>

        <div className="mb-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-sm text-white/60">Level 7</span>
            <span className="text-xs text-white/60">1,250/2,000 XP</span>
          </div>
          <Progress
            value={62.5}
            className="h-1.5 bg-white/10"
            indicatorClassName="bg-gradient-to-r from-[#FF00FF] to-[#00FFFF]"
          />
        </div>

        <div className="grid grid-cols-2 gap-2 text-center mb-3">
          <div className="bg-[#191919] rounded-md p-2">
            <div className="text-lg font-bold">$1,289</div>
            <div className="text-xs text-white/60">Available</div>
          </div>
          <div className="bg-[#191919] rounded-md p-2">
            <div className="text-lg font-bold">24</div>
            <div className="text-xs text-white/60">Active Links</div>
          </div>
        </div>

        <Button className="w-full bg-gradient-to-r from-[#00FFFF] to-[#FF00FF] text-black font-bold">
          <Award className="mr-2 h-4 w-4" />
          View Profile
        </Button>
      </div>

      {/* Navigation */}
      <div className="bg-[#111111] rounded-xl border border-white/10 p-2">
        <nav className="space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm ${
                isActive(item.href)
                  ? "bg-gradient-to-r from-[#FF00FF]/20 to-[#00FFFF]/20 text-white"
                  : "text-white/60 hover:text-white hover:bg-white/5"
              }`}
            >
              <item.icon className="h-4 w-4" />
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>
      </div>

      {/* Help & Settings */}
      <div className="bg-[#111111] rounded-xl border border-white/10 p-2">
        <nav className="space-y-1">
          <Button variant="ghost" className="w-full justify-start text-white/60 hover:text-white">
            <Settings className="h-4 w-4 mr-3" />
            <span className="text-sm">Settings</span>
          </Button>
          <Button variant="ghost" className="w-full justify-start text-white/60 hover:text-white">
            <HelpCircle className="h-4 w-4 mr-3" />
            <span className="text-sm">Help Center</span>
          </Button>
          <Button variant="ghost" className="w-full justify-start text-white/60 hover:text-white">
            <LogOut className="h-4 w-4 mr-3" />
            <span className="text-sm">Log Out</span>
          </Button>
        </nav>
      </div>
    </div>
  )
}

