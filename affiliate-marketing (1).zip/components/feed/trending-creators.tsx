"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sparkles } from "lucide-react"

interface Creator {
  id: string
  name: string
  username: string
  avatar: string
  isVerified: boolean
  earnings: number
  growth: number
  category: string
}

export default function TrendingCreators() {
  const [creators] = useState<Creator[]>([
    {
      id: "1",
      name: "Mia Chen",
      username: "miacreates",
      avatar: "/placeholder.svg?height=40&width=40",
      isVerified: true,
      earnings: 24893,
      growth: 43,
      category: "Tech",
    },
    {
      id: "2",
      name: "Alex Rivera",
      username: "alexcreates",
      avatar: "/placeholder.svg?height=40&width=40",
      isVerified: true,
      earnings: 32451,
      growth: 52,
      category: "Finance",
    },
    {
      id: "3",
      name: "Jordan Williams",
      username: "jordanwilliams",
      avatar: "/placeholder.svg?height=40&width=40",
      isVerified: false,
      earnings: 18762,
      growth: 28,
      category: "Fitness",
    },
    {
      id: "4",
      name: "Taylor Kim",
      username: "taylorkim",
      avatar: "/placeholder.svg?height=40&width=40",
      isVerified: true,
      earnings: 15932,
      growth: 37,
      category: "Fashion",
    },
  ])

  const [followedCreators, setFollowedCreators] = useState<string[]>([])

  const toggleFollow = (creatorId: string) => {
    if (followedCreators.includes(creatorId)) {
      setFollowedCreators((prev) => prev.filter((id) => id !== creatorId))
    } else {
      setFollowedCreators((prev) => [...prev, creatorId])
    }
  }

  return (
    <div className="space-y-3">
      {creators.map((creator, index) => (
        <motion.div
          key={creator.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
          className="flex items-center justify-between"
        >
          <div className="flex items-center gap-2">
            <div className="relative">
              <Avatar className="h-8 w-8">
                <AvatarImage src={creator.avatar} alt={creator.name} />
                <AvatarFallback>{creator.name.charAt(0)}</AvatarFallback>
              </Avatar>
              {creator.isVerified && (
                <div className="absolute -top-1 -right-1 bg-[#00FFFF] text-black rounded-full w-3.5 h-3.5 flex items-center justify-center">
                  <Sparkles className="h-2 w-2" />
                </div>
              )}
            </div>

            <div className="min-w-0">
              <div className="font-medium truncate">{creator.name}</div>
              <div className="flex items-center gap-1">
                <span className="text-xs text-white/60 truncate">@{creator.username}</span>
                <Badge className="h-4 px-1 text-[9px] bg-[#191919] text-white/80 border-none">{creator.category}</Badge>
              </div>
            </div>
          </div>

          <Button
            variant={followedCreators.includes(creator.id) ? "default" : "outline"}
            size="sm"
            className={`h-7 text-xs ${
              followedCreators.includes(creator.id)
                ? "bg-[#00FFFF] text-black hover:bg-[#00FFFF]/90"
                : "border-white/20"
            }`}
            onClick={() => toggleFollow(creator.id)}
          >
            {followedCreators.includes(creator.id) ? "Following" : "Follow"}
          </Button>
        </motion.div>
      ))}
    </div>
  )
}

