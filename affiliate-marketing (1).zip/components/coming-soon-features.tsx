"use client"

import type React from "react"

import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import {
  Bell,
  CreditCard,
  Globe,
  LineChart,
  MessageSquare,
  PhoneIcon as MobilePhone,
  Sparkles,
  Zap,
} from "lucide-react"

interface Feature {
  icon: React.ElementType
  title: string
  description: string
  comingSoon: string
}

export function ComingSoonFeatures() {
  const features: Feature[] = [
    {
      icon: MobilePhone,
      title: "Mobile App",
      description: "Manage your affiliate business on the go with our native mobile application.",
      comingSoon: "May 2025",
    },
    {
      icon: CreditCard,
      title: "Virtual Card",
      description: "Access your earnings instantly with our virtual card that works anywhere.",
      comingSoon: "May 2025",
    },
    {
      icon: Globe,
      title: "Global Marketplace",
      description: "Connect with international brands and expand your reach to new markets.",
      comingSoon: "July 2025",
    },
    {
      icon: LineChart,
      title: "Advanced Analytics",
      description: "Gain deeper insights with our AI-powered performance analytics dashboard.",
      comingSoon: "July 2025",
    },
    {
      icon: MessageSquare,
      title: "Community Forum",
      description: "Connect with other affiliates to share strategies and grow together.",
      comingSoon: "September 2025",
    },
    {
      icon: Bell,
      title: "Smart Alerts",
      description: "Get notified about high-converting opportunities tailored to your niche.",
      comingSoon: "September 2025",
    },
    {
      icon: Sparkles,
      title: "AI Content Generator",
      description: "Create high-converting affiliate content with our AI-powered tools.",
      comingSoon: "November 2025",
    },
    {
      icon: Zap,
      title: "Automated Campaigns",
      description: "Set up and optimize your affiliate campaigns with intelligent automation.",
      comingSoon: "November 2025",
    },
  ]

  return (
    <section className="py-24 bg-[#0A0A14]">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            ROADMAP
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Coming Soon
          </h2>
          <p className="text-base md:text-lg text-white/70">
            We're constantly innovating to bring you the most advanced affiliate marketing platform. Here's what's on
            our roadmap.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="bg-white/5 border border-white/10 rounded-lg p-6 hover:border-[#00F0FF]/30 hover:bg-white/10 transition-all duration-300"
            >
              <div className="h-12 w-12 rounded-full bg-gradient-to-br from-[#00F0FF]/20 to-[#0033CC]/20 flex items-center justify-center mb-4">
                <feature.icon className="h-6 w-6 text-[#00F0FF]" />
              </div>

              <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
              <p className="text-white/70 text-sm mb-4">{feature.description}</p>

              <div className="pt-4 border-t border-white/10 flex justify-between items-center">
                <span className="text-white/60 text-sm">Coming Soon</span>
                <Badge className="bg-[#00F0FF]/20 text-[#00F0FF] border-[#00F0FF]/30">{feature.comingSoon}</Badge>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

