"use client"

import { motion } from "framer-motion"
import { Star, Quote } from "lucide-react"
import Image from "next/image"

interface TestimonialCardProps {
  quote: string
  name: string
  role: string
  avatarUrl?: string
  delay?: number
  rating?: number
}

export function TestimonialCard({
  quote,
  name,
  role,
  avatarUrl = "/placeholder.svg?height=80&width=80",
  delay = 0,
  rating = 5,
}: TestimonialCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay, duration: 0.6 }}
      className="relative overflow-hidden group"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-[#00F0FF]/20 to-[#0033CC]/20 rounded-xl transform group-hover:scale-[1.03] transition-all duration-500 opacity-0 group-hover:opacity-100"></div>

      <div className="relative bg-gradient-to-br from-[#0A1A2F]/80 to-[#0A0A14]/95 backdrop-blur-sm rounded-xl p-8 border border-white/10 shadow-xl hover:border-[#00F0FF]/30 hover:shadow-[#00F0FF]/5 hover:-translate-y-1 transition-all duration-300">
        <div className="absolute top-6 right-6 opacity-10">
          <Quote className="h-16 w-16 text-[#00F0FF]" />
        </div>

        <div className="flex items-center mb-6">
          <div className="relative mr-4 h-16 w-16 rounded-full overflow-hidden border-2 border-[#00F0FF]/30 shadow-lg shadow-[#00F0FF]/10">
            <Image src={avatarUrl || "/placeholder.svg"} alt={name} fill className="object-cover" />
          </div>
          <div>
            <div className="font-medium text-lg">{name}</div>
            <div className="text-white/60 text-sm">{role}</div>
          </div>
        </div>

        <div className="flex mb-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              className={`h-5 w-5 ${i < rating ? "fill-yellow-400 text-yellow-400" : "fill-gray-700 text-gray-700"}`}
            />
          ))}
        </div>

        <blockquote className="mb-6 text-lg leading-relaxed relative">
          <span className="text-[#00F0FF] text-2xl font-serif absolute -left-2 -top-2">"</span>
          {quote}
          <span className="text-[#00F0FF] text-2xl font-serif">"</span>
        </blockquote>

        <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#00F0FF] to-[#0033CC] transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
      </div>
    </motion.div>
  )
}

