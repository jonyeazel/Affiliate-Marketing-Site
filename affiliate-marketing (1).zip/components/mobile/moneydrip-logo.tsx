"use client"

import { motion } from "framer-motion"
import Link from "next/link"

export default function MoneyDripLogo() {
  return (
    <Link href="/mobile" className="flex items-center gap-2">
      <div className="relative">
        <motion.div className="relative h-8 w-8" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          {/* Simplified logo with just two colors */}
          <div className="absolute h-8 w-8 bg-white opacity-20 rounded-sm transform rotate-45"></div>
          <div className="absolute h-6 w-6 top-1 left-1 bg-white opacity-40 rounded-sm transform rotate-45"></div>
          <div className="absolute h-4 w-4 top-2 left-2 bg-white opacity-60 rounded-sm transform rotate-45"></div>

          {/* MoneyDrip accent */}
          <div className="absolute h-4 w-4 bg-[#00CFCF] bottom-0 left-2 rounded-sm"></div>
        </motion.div>
      </div>
      <div className="flex flex-col">
        <span className="font-bold text-lg leading-none">MoneyDrip</span>
        <span className="text-[10px] text-white/60 leading-none">by AffiliateMarketing.com</span>
      </div>
    </Link>
  )
}

