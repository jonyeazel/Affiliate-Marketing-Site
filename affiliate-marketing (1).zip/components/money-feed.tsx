"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { DollarSign, ArrowUpRight, TrendingUp } from "lucide-react"

interface MoneyEvent {
  id: string
  user: {
    name: string
    username: string
    avatar: string
  }
  amount: number
  platform: string
  timestamp: Date
  isNew?: boolean
}

export default function MoneyFeed() {
  const [events, setEvents] = useState<MoneyEvent[]>([])

  // Initial data
  useEffect(() => {
    const initialEvents: MoneyEvent[] = [
      {
        id: "1",
        user: {
          name: "Kai Zhang",
          username: "kainotcrying",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        amount: 432.19,
        platform: "TikTok Shop",
        timestamp: new Date(Date.now() - 1000 * 60 * 2),
      },
      {
        id: "2",
        user: {
          name: "Zoe Rivera",
          username: "zoevibin",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        amount: 1289.45,
        platform: "Instagram",
        timestamp: new Date(Date.now() - 1000 * 60 * 5),
      },
      {
        id: "3",
        user: {
          name: "Tyler Johnson",
          username: "tylerunleashed",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        amount: 567.82,
        platform: "YouTube",
        timestamp: new Date(Date.now() - 1000 * 60 * 8),
      },
      {
        id: "4",
        user: {
          name: "Mia Wong",
          username: "miathoughts",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        amount: 892.31,
        platform: "TikTok",
        timestamp: new Date(Date.now() - 1000 * 60 * 12),
      },
      {
        id: "5",
        user: {
          name: "Jordan Lee",
          username: "jordanleecreates",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        amount: 1543.67,
        platform: "Twitch",
        timestamp: new Date(Date.now() - 1000 * 60 * 18),
      },
    ]

    setEvents(initialEvents)
  }, [])

  // Simulate new events coming in
  useEffect(() => {
    const names = ["Alex", "Jamie", "Taylor", "Morgan", "Casey", "Riley", "Jordan", "Quinn", "Avery", "Blake"]
    const usernames = [
      "vibesonly",
      "createordie",
      "digitalnomad",
      "contentking",
      "moneymoves",
      "hustle247",
      "createflow",
      "trendsetter",
    ]
    const platforms = ["TikTok", "Instagram", "YouTube", "Twitch", "Twitter", "Pinterest", "TikTok Shop"]

    const interval = setInterval(() => {
      const newEvent: MoneyEvent = {
        id: Date.now().toString(),
        user: {
          name: `${names[Math.floor(Math.random() * names.length)]} ${String.fromCharCode(65 + Math.floor(Math.random() * 26))}`,
          username: `${usernames[Math.floor(Math.random() * usernames.length)]}${Math.floor(Math.random() * 1000)}`,
          avatar: `/placeholder.svg?height=40&width=40`,
        },
        amount: Number.parseFloat((Math.random() * 2000 + 50).toFixed(2)),
        platform: platforms[Math.floor(Math.random() * platforms.length)],
        timestamp: new Date(),
        isNew: true,
      }

      setEvents((prev) => [newEvent, ...prev.slice(0, 4)])

      // Remove the "new" flag after animation
      setTimeout(() => {
        setEvents((prev) => prev.map((event) => (event.id === newEvent.id ? { ...event, isNew: false } : event)))
      }, 3000)
    }, 8000)

    return () => clearInterval(interval)
  }, [])

  const formatTime = (date: Date) => {
    const now = new Date()
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

    if (diffInSeconds < 60) return `${diffInSeconds}s ago`
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`
    return `${Math.floor(diffInSeconds / 3600)}h ago`
  }

  const getPlatformColor = (platform: string) => {
    switch (platform) {
      case "TikTok":
        return "bg-[#000000] text-white"
      case "TikTok Shop":
        return "bg-[#000000] text-white"
      case "Instagram":
        return "bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCAF45] text-white"
      case "YouTube":
        return "bg-[#FF0000] text-white"
      case "Twitch":
        return "bg-[#9146FF] text-white"
      case "Twitter":
        return "bg-[#1DA1F2] text-white"
      case "Pinterest":
        return "bg-[#E60023] text-white"
      default:
        return "bg-gray-800 text-white"
    }
  }

  return (
    <div className="bg-[#111111] rounded-xl border border-white/10 overflow-hidden">
      <div className="p-4 border-b border-white/10 flex justify-between items-center">
        <h3 className="font-medium flex items-center">
          <DollarSign className="mr-2 h-4 w-4 text-[#00FFFF]" />
          Live Earnings
        </h3>
        <Badge variant="outline" className="bg-[#222222] border-none text-white/60">
          <TrendingUp className="mr-1 h-3 w-3 text-[#00FFFF]" />
          3,219 creators online
        </Badge>
      </div>

      <div className="max-h-[500px] overflow-y-auto">
        <AnimatePresence>
          {events.map((event) => (
            <motion.div
              key={event.id}
              initial={event.isNew ? { opacity: 0, y: -20, backgroundColor: "rgba(0, 255, 255, 0.2)" } : false}
              animate={{ opacity: 1, y: 0, backgroundColor: "rgba(0, 0, 0, 0)" }}
              transition={{ duration: 0.5 }}
              className="p-4 border-b border-white/5 flex items-center hover:bg-white/5 transition-colors"
            >
              <Avatar className="h-10 w-10 mr-3">
                <AvatarImage src={event.user.avatar} alt={event.user.name} />
                <AvatarFallback>{event.user.name.charAt(0)}</AvatarFallback>
              </Avatar>

              <div className="flex-1 min-w-0">
                <div className="flex items-center">
                  <p className="font-medium truncate">{event.user.name}</p>
                  <span className="mx-1 text-white/40">•</span>
                  <p className="text-white/60 text-sm truncate">@{event.user.username}</p>
                </div>
                <div className="flex items-center mt-1">
                  <Badge className={`${getPlatformColor(event.platform)} text-xs mr-2`}>{event.platform}</Badge>
                  <span className="text-white/40 text-xs">{formatTime(event.timestamp)}</span>
                </div>
              </div>

              <div className="flex flex-col items-end ml-4">
                <div className="font-bold text-lg text-[#00FFFF]">${event.amount.toLocaleString()}</div>
                <button className="text-xs text-white/60 hover:text-white flex items-center mt-1">
                  view profile
                  <ArrowUpRight className="ml-1 h-3 w-3" />
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}

