"use client"

import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

interface IntegrationItem {
  name: string
  description: string
  logo: string
  category: "payment" | "analytics" | "marketing" | "ecommerce"
  comingSoon?: boolean
}

export function IntegrationShowcase() {
  const integrations: IntegrationItem[] = [
    {
      name: "Stripe",
      description: "Process payments and manage subscriptions with ease",
      logo: "/placeholder.svg?height=60&width=60",
      category: "payment",
    },
    {
      name: "PayPal",
      description: "Send and receive payments globally",
      logo: "/placeholder.svg?height=60&width=60",
      category: "payment",
    },
    {
      name: "Google Analytics",
      description: "Track and analyze your traffic and conversions",
      logo: "/placeholder.svg?height=60&width=60",
      category: "analytics",
    },
    {
      name: "Shopify",
      description: "Connect your store and track product sales",
      logo: "/placeholder.svg?height=60&width=60",
      category: "ecommerce",
    },
    {
      name: "Mailchimp",
      description: "Automate email campaigns for your affiliate promotions",
      logo: "/placeholder.svg?height=60&width=60",
      category: "marketing",
    },
    {
      name: "WooCommerce",
      description: "Integrate with your WordPress store",
      logo: "/placeholder.svg?height=60&width=60",
      category: "ecommerce",
    },
    {
      name: "HubSpot",
      description: "Manage your affiliate relationships and campaigns",
      logo: "/placeholder.svg?height=60&width=60",
      category: "marketing",
    },
    {
      name: "Segment",
      description: "Collect, clean and control your customer data",
      logo: "/placeholder.svg?height=60&width=60",
      category: "analytics",
    },
    {
      name: "Bitcoin",
      description: "Accept cryptocurrency payments",
      logo: "/placeholder.svg?height=60&width=60",
      category: "payment",
      comingSoon: true,
    },
    {
      name: "Zapier",
      description: "Connect with 3,000+ apps and automate workflows",
      logo: "/placeholder.svg?height=60&width=60",
      category: "marketing",
      comingSoon: true,
    },
  ]

  const categories = [
    { id: "payment", label: "Payment", color: "from-green-400/20 to-green-600/10" },
    { id: "analytics", label: "Analytics", color: "from-blue-400/20 to-blue-600/10" },
    { id: "marketing", label: "Marketing", color: "from-purple-400/20 to-purple-600/10" },
    { id: "ecommerce", label: "E-commerce", color: "from-amber-400/20 to-amber-600/10" },
  ]

  return (
    <section className="py-24 bg-gradient-to-b from-[#0A0A14] to-[#0A1A2F]/30">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            INTEGRATIONS
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Connect With Your Favorite Tools
          </h2>
          <p className="text-base md:text-lg text-white/70">
            AffiliateMarketing.com seamlessly integrates with the tools you already use.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6 max-w-6xl mx-auto mb-12">
          {integrations.map((integration, index) => {
            const category = categories.find((c) => c.id === integration.category)

            return (
              <motion.div
                key={integration.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05, duration: 0.5 }}
                className={`relative bg-gradient-to-br ${category?.color || "from-white/10 to-white/5"} backdrop-blur-sm rounded-xl p-4 border border-white/10 hover:border-[#00F0FF]/30 transition-all duration-300 group`}
              >
                {integration.comingSoon && (
                  <div className="absolute top-2 right-2">
                    <Badge variant="outline" className="text-xs bg-[#0A0A14]/80 border-white/20 text-white/60">
                      Coming Soon
                    </Badge>
                  </div>
                )}

                <div className="flex flex-col items-center text-center h-full">
                  <div className="relative h-12 w-12 mb-4">
                    <Image
                      src={integration.logo || "/placeholder.svg"}
                      alt={integration.name}
                      fill
                      className="object-contain"
                    />
                  </div>

                  <h3 className="font-medium text-white mb-2">{integration.name}</h3>
                  <p className="text-white/60 text-sm">{integration.description}</p>

                  <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Badge
                      variant="outline"
                      className={`text-xs border-${integration.category}-400/30 text-${integration.category}-400/80`}
                    >
                      {category?.label}
                    </Badge>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>

        <div className="text-center">
          <Button variant="outline" className="bg-white/5 border-white/10 hover:bg-white/10 text-white">
            View All Integrations
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}

