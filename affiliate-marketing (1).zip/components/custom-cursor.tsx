"use client"

import { useState, useEffect } from "react"

export default function CustomCursor() {
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [hidden, setHidden] = useState(true)
  const [clicked, setClicked] = useState(false)
  const [linkHovered, setLinkHovered] = useState(false)

  useEffect(() => {
    const mMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY })
      setHidden(false)
    }

    const mLeave = () => {
      setHidden(true)
    }

    const mDown = () => {
      setClicked(true)
      setTimeout(() => setClicked(false), 150)
    }

    // Check if hovering over links or buttons
    const handleLinkHover = () => {
      const elements = document.querySelectorAll('a, button, [role="button"]')

      elements.forEach((el) => {
        el.addEventListener("mouseenter", () => setLinkHovered(true))
        el.addEventListener("mouseleave", () => setLinkHovered(false))
      })
    }

    // Add event listeners
    document.addEventListener("mousemove", mMove)
    document.addEventListener("mouseleave", mLeave)
    document.addEventListener("mousedown", mDown)

    // Initial check for link elements
    handleLinkHover()

    // Re-check periodically for dynamically added elements
    const interval = setInterval(handleLinkHover, 2000)

    return () => {
      document.removeEventListener("mousemove", mMove)
      document.removeEventListener("mouseleave", mLeave)
      document.removeEventListener("mousedown", mDown)
      clearInterval(interval)
    }
  }, [])

  const cursorClasses = `
    fixed pointer-events-none z-50 rounded-full mix-blend-difference
    transition-transform duration-150 ease-out
    ${hidden ? "opacity-0" : "opacity-100"}
    ${clicked ? "scale-75" : ""}
    ${linkHovered ? "scale-150" : ""}
  `

  return (
    <>
      {/* Main cursor */}
      <div
        className={`${cursorClasses} w-6 h-6 bg-white`}
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          transform: `translate(-50%, -50%) ${clicked ? "scale(0.7)" : ""} ${linkHovered ? "scale(1.5)" : ""}`,
        }}
      />

      {/* Trailing cursor */}
      <div
        className={`${cursorClasses} w-10 h-10 bg-white/30 backdrop-blur-sm`}
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          transform: `translate(-50%, -50%) ${clicked ? "scale(1.2)" : ""} ${linkHovered ? "scale(0)" : ""}`,
          transition: "transform 150ms ease-out, opacity 150ms ease-out, left 80ms ease-out, top 80ms ease-out",
        }}
      />
    </>
  )
}

