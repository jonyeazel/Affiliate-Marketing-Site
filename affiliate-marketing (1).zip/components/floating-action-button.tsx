"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronUp, MessageCircle, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function FloatingActionButton() {
  const [isOpen, setIsOpen] = useState(false)
  const [showChat, setShowChat] = useState(false)

  const toggleOpen = () => {
    setIsOpen(!isOpen)
  }

  const openChat = () => {
    setShowChat(true)
    setIsOpen(false)
  }

  const closeChat = () => {
    setShowChat(false)
  }

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    })
    setIsOpen(false)
  }

  return (
    <>
      <div className="fixed bottom-6 right-6 z-40">
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.2 }}
              className="mb-4 flex flex-col items-end space-y-3"
            >
              <Button
                onClick={scrollToTop}
                className="h-12 w-12 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 transition-colors duration-300"
              >
                <ChevronUp className="h-6 w-6 text-white" />
              </Button>

              <Button
                onClick={openChat}
                className="h-12 w-12 rounded-full bg-gradient-to-r from-[#00F0FF] to-[#0033CC] hover:opacity-90 transition-opacity duration-300"
              >
                <MessageCircle className="h-6 w-6 text-white" />
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        <Button
          onClick={toggleOpen}
          className={`h-14 w-14 rounded-full ${
            isOpen
              ? "bg-white/10 backdrop-blur-sm border border-white/20"
              : "bg-gradient-to-r from-[#00F0FF] to-[#0033CC]"
          } hover:scale-105 transition-all duration-300 shadow-lg`}
        >
          {isOpen ? <X className="h-6 w-6 text-white" /> : <MessageCircle className="h-6 w-6 text-white" />}
        </Button>
      </div>

      <AnimatePresence>
        {showChat && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.3 }}
            className="fixed bottom-6 right-6 w-full max-w-md z-50"
          >
            <div className="bg-[#0A0A14] border border-white/10 rounded-lg shadow-2xl overflow-hidden">
              <div className="bg-gradient-to-r from-[#00F0FF] to-[#0033CC] p-4 flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-white flex items-center justify-center">
                    <MessageCircle className="h-4 w-4 text-[#0033CC]" />
                  </div>
                  <h3 className="font-bold text-white">Chat with Us</h3>
                </div>
                <Button onClick={closeChat} variant="ghost" className="h-8 w-8 p-0 text-white hover:bg-white/20">
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="h-80 p-4 overflow-y-auto">
                <div className="bg-white/10 p-3 rounded-lg mb-4 max-w-[80%]">
                  <p className="text-white">Hi there! How can we help you with affiliate marketing today?</p>
                  <p className="text-white/50 text-xs mt-1">Support • Just now</p>
                </div>
              </div>

              <div className="p-4 border-t border-white/10">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Type your message..."
                    className="w-full bg-white/10 border border-white/20 rounded-full py-3 px-4 pr-12 text-white placeholder:text-white/50 focus:outline-none focus:border-[#00F0FF]"
                  />
                  <Button className="absolute right-1 top-1 h-8 w-8 rounded-full bg-gradient-to-r from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M22 2L11 13"
                        stroke="white"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M22 2L15 22L11 13L2 9L22 2Z"
                        stroke="white"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

