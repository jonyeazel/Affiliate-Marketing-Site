"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart3,
  CreditCard,
  DollarSign,
  Link,
  LineChart,
  PieChart,
  Settings,
  ShoppingCart,
  Users,
} from "lucide-react"

export function DashboardPreview() {
  const [activeTab, setActiveTab] = useState("overview")

  const handleTabChange = (value: string) => {
    setActiveTab(value)
  }

  return (
    <section className="py-24 bg-[#0A0A14]">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            PLATFORM PREVIEW
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Your Powerful Dashboard
          </h2>
          <p className="text-base md:text-lg text-white/70">
            Everything you need to manage your affiliate business in one place. Intuitive, powerful, and designed for
            results.
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="relative">
            {/* Glow effect */}
            <div className="absolute -inset-1 bg-gradient-to-r from-[#00F0FF]/30 to-[#0033CC]/30 rounded-xl blur-lg opacity-70"></div>

            <div className="relative bg-[#0A0A14] border border-white/10 rounded-xl overflow-hidden">
              {/* Dashboard Header */}
              <div className="bg-gradient-to-r from-[#0A1A2F] to-[#0A0A14] p-4 border-b border-white/10 flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="relative w-8 h-8">
                    <div className="absolute inset-0 bg-[#00F0FF] rounded-full blur-sm opacity-60"></div>
                    <div className="relative w-8 h-8 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
                      <span className="font-bold text-xs">AM</span>
                    </div>
                  </div>
                  <span className="font-medium text-base">Dashboard</span>
                </div>

                <div className="flex items-center gap-4">
                  <div className="h-8 w-8 rounded-full bg-white/10 flex items-center justify-center cursor-pointer hover:bg-white/20 transition-colors duration-300">
                    <Settings className="h-4 w-4 text-white/70" />
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
                      <span className="font-bold text-xs">JD</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dashboard Navigation */}
              <div className="p-4 border-b border-white/10">
                <Tabs defaultValue="overview" onValueChange={handleTabChange}>
                  <TabsList className="bg-white/5 border border-white/10 flex-wrap overflow-x-auto whitespace-nowrap text-xs md:text-sm">
                    <TabsTrigger
                      value="overview"
                      className={`text-xs md:text-sm whitespace-nowrap ${
                        activeTab === "overview"
                          ? "data-[state=active]:bg-[#00F0FF] data-[state=active]:text-[#0A0A14]"
                          : ""
                      }`}
                    >
                      <LineChart className="h-3 w-3 md:h-4 md:w-4 mr-1 md:mr-2" />
                      Overview
                    </TabsTrigger>
                    <TabsTrigger
                      value="earnings"
                      className={`text-xs md:text-sm whitespace-nowrap ${
                        activeTab === "earnings"
                          ? "data-[state=active]:bg-[#00F0FF] data-[state=active]:text-[#0A0A14]"
                          : ""
                      }`}
                    >
                      <DollarSign className="h-3 w-3 md:h-4 md:w-4 mr-1 md:mr-2" />
                      Earnings
                    </TabsTrigger>
                    <TabsTrigger
                      value="links"
                      className={`text-xs md:text-sm whitespace-nowrap ${
                        activeTab === "links"
                          ? "data-[state=active]:bg-[#00F0FF] data-[state=active]:text-[#0A0A14]"
                          : ""
                      }`}
                    >
                      <Link className="h-3 w-3 md:h-4 md:w-4 mr-1 md:mr-2" />
                      Links
                    </TabsTrigger>
                    <TabsTrigger
                      value="programs"
                      className={`text-xs md:text-sm whitespace-nowrap ${
                        activeTab === "programs"
                          ? "data-[state=active]:bg-[#00F0FF] data-[state=active]:text-[#0A0A14]"
                          : ""
                      }`}
                    >
                      <ShoppingCart className="h-3 w-3 md:h-4 md:w-4 mr-1 md:mr-2" />
                      Programs
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="overview" className="mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                      <div className="bg-white/5 border border-white/10 rounded-lg p-4 hover:border-[#00F0FF]/30 transition-colors duration-300">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <p className="text-white/60 text-sm">Total Earnings</p>
                            <h3 className="text-2xl font-bold text-white">$8,547.63</h3>
                          </div>
                          <div className="h-10 w-10 rounded-full bg-[#00F0FF]/10 flex items-center justify-center">
                            <DollarSign className="h-5 w-5 text-[#00F0FF]" />
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-green-400 text-sm">+12.5%</span>
                          <span className="text-white/60 text-sm">from last month</span>
                        </div>
                      </div>

                      <div className="bg-white/5 border border-white/10 rounded-lg p-4 hover:border-[#00F0FF]/30 transition-colors duration-300">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <p className="text-white/60 text-sm">Conversion Rate</p>
                            <h3 className="text-2xl font-bold text-white">3.8%</h3>
                          </div>
                          <div className="h-10 w-10 rounded-full bg-[#00F0FF]/10 flex items-center justify-center">
                            <BarChart3 className="h-5 w-5 text-[#00F0FF]" />
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-green-400 text-sm">+0.5%</span>
                          <span className="text-white/60 text-sm">from last month</span>
                        </div>
                      </div>

                      <div className="bg-white/5 border border-white/10 rounded-lg p-4 hover:border-[#00F0FF]/30 transition-colors duration-300">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <p className="text-white/60 text-sm">Active Programs</p>
                            <h3 className="text-2xl font-bold text-white">12</h3>
                          </div>
                          <div className="h-10 w-10 rounded-full bg-[#00F0FF]/10 flex items-center justify-center">
                            <ShoppingCart className="h-5 w-5 text-[#00F0FF]" />
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[#00F0FF] text-sm">4 new</span>
                          <span className="text-white/60 text-sm">opportunities available</span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="md:col-span-2 bg-white/5 border border-white/10 rounded-lg p-4 hover:border-[#00F0FF]/30 transition-colors duration-300">
                        <div className="flex justify-between items-center mb-4">
                          <h3 className="font-medium">Earnings Overview</h3>
                          <div className="text-white/60 text-sm">Last 30 days</div>
                        </div>
                        <div className="h-64 w-full relative">
                          {/* Placeholder for chart */}
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="h-full w-full bg-gradient-to-r from-[#00F0FF]/10 to-[#0033CC]/10 rounded-lg">
                              <div className="h-full w-full flex items-center justify-center">
                                <LineChart className="h-16 w-16 text-[#00F0FF]/30" />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white/5 border border-white/10 rounded-lg p-4 hover:border-[#00F0FF]/30 transition-colors duration-300">
                        <div className="flex justify-between items-center mb-4">
                          <h3 className="font-medium">Traffic Sources</h3>
                          <div className="text-white/60 text-sm">Last 30 days</div>
                        </div>
                        <div className="h-64 w-full relative">
                          {/* Placeholder for chart */}
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="h-full w-full bg-gradient-to-r from-[#00F0FF]/10 to-[#0033CC]/10 rounded-lg">
                              <div className="h-full w-full flex items-center justify-center">
                                <PieChart className="h-16 w-16 text-[#00F0FF]/30" />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="earnings" className="mt-6">
                    <div className="bg-white/5 border border-white/10 rounded-lg p-6 mb-6">
                      <h3 className="text-xl font-bold mb-4">Recent Earnings</h3>
                      <div className="space-y-4">
                        {[1, 2, 3, 4].map((item) => (
                          <div
                            key={item}
                            className="flex justify-between items-center p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors duration-300"
                          >
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#00F0FF]/20 to-[#0033CC]/20 flex items-center justify-center">
                                <DollarSign className="h-5 w-5 text-[#00F0FF]" />
                              </div>
                              <div>
                                <div className="font-medium">Sale: Premium Product</div>
                                <div className="text-sm text-white/60">
                                  {item} hour{item !== 1 ? "s" : ""} ago
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-medium text-[#00F0FF]">+${(Math.random() * 100).toFixed(2)}</div>
                              <div className="text-xs text-white/60">Paid instantly</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-white/5 border border-white/10 rounded-lg p-6">
                        <h3 className="text-xl font-bold mb-4">Payment Methods</h3>
                        <div className="space-y-4">
                          <div className="p-3 bg-white/5 rounded-lg border border-[#00F0FF]/30 flex justify-between items-center">
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-[#00F0FF]/10 flex items-center justify-center">
                                <CreditCard className="h-5 w-5 text-[#00F0FF]" />
                              </div>
                              <div>
                                <div className="font-medium">Virtual Card</div>
                                <div className="text-sm text-white/60">Instant access to funds</div>
                              </div>
                            </div>
                            <Badge className="bg-[#00F0FF] text-[#0A0A14]">Default</Badge>
                          </div>

                          <div className="p-3 bg-white/5 rounded-lg flex justify-between items-center">
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center">
                                <CreditCard className="h-5 w-5 text-white/70" />
                              </div>
                              <div>
                                <div className="font-medium">Bank Transfer</div>
                                <div className="text-sm text-white/60">1-2 business days</div>
                              </div>
                            </div>
                            <Badge className="bg-white/10 text-white/70 hover:bg-white/20">Add</Badge>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white/5 border border-white/10 rounded-lg p-6">
                        <h3 className="text-xl font-bold mb-4">Top Performing Products</h3>
                        <div className="space-y-4">
                          {[1, 2, 3].map((item) => (
                            <div key={item} className="flex justify-between items-center">
                              <div className="flex items-center gap-2">
                                <div className="text-lg font-bold text-white/40">0{item}</div>
                                <div>
                                  <div className="font-medium">Product Name {item}</div>
                                  <div className="text-sm text-white/60">
                                    ${(Math.random() * 100).toFixed(2)} per sale
                                  </div>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="font-medium">${(Math.random() * 1000).toFixed(2)}</div>
                                <div className="text-sm text-white/60">{Math.floor(Math.random() * 50)} sales</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="links" className="mt-6">
                    <div className="bg-white/5 border border-white/10 rounded-lg p-6 mb-6">
                      <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-bold">Your Affiliate Links</h3>
                        <Badge className="bg-[#00F0FF] text-[#0A0A14] cursor-pointer">+ Create New Link</Badge>
                      </div>

                      <div className="space-y-4">
                        {[1, 2, 3].map((item) => (
                          <div
                            key={item}
                            className="p-4 bg-white/5 rounded-lg border border-white/10 hover:border-[#00F0FF]/30 transition-colors duration-300"
                          >
                            <div className="flex justify-between items-start mb-3">
                              <div>
                                <h4 className="font-medium">Product Link {item}</h4>
                                <p className="text-sm text-white/60 mt-1">
                                  https://affmkt.co/p/{item}abc{item * 3}
                                </p>
                              </div>
                              <Badge className="bg-white/10 text-white/70">Copy</Badge>
                            </div>

                            <div className="grid grid-cols-3 gap-4 mt-4">
                              <div>
                                <p className="text-white/60 text-xs">Clicks</p>
                                <p className="font-medium">{Math.floor(Math.random() * 1000)}</p>
                              </div>
                              <div>
                                <p className="text-white/60 text-xs">Conversions</p>
                                <p className="font-medium">{Math.floor(Math.random() * 100)}</p>
                              </div>
                              <div>
                                <p className="text-white/60 text-xs">Earnings</p>
                                <p className="font-medium text-[#00F0FF]">${(Math.random() * 1000).toFixed(2)}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="programs" className="mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {[1, 2, 3, 4].map((item) => (
                        <div
                          key={item}
                          className="bg-white/5 border border-white/10 rounded-lg p-6 hover:border-[#00F0FF]/30 transition-colors duration-300"
                        >
                          <div className="flex justify-between items-start mb-4">
                            <div className="flex items-center gap-3">
                              <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-[#00F0FF]/20 to-[#0033CC]/20 flex items-center justify-center">
                                <ShoppingCart className="h-6 w-6 text-[#00F0FF]" />
                              </div>
                              <div>
                                <h4 className="font-bold">Program {item}</h4>
                                <p className="text-sm text-white/60">Category {item}</p>
                              </div>
                            </div>
                            <Badge
                              className={
                                item % 2 === 0
                                  ? "bg-green-500/20 text-green-400 border-green-500/30"
                                  : "bg-[#00F0FF]/20 text-[#00F0FF] border-[#00F0FF]/30"
                              }
                            >
                              {item % 2 === 0 ? "Active" : "Featured"}
                            </Badge>
                          </div>

                          <div className="space-y-2 mb-4">
                            <div className="flex justify-between">
                              <span className="text-white/60">Commission</span>
                              <span className="font-medium">{10 + item * 2}%</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-white/60">Cookie Duration</span>
                              <span className="font-medium">{15 + item * 15} days</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-white/60">Earnings</span>
                              <span className="font-medium text-[#00F0FF]">${(Math.random() * 1000).toFixed(2)}</span>
                            </div>
                          </div>

                          <div className="pt-4 border-t border-white/10 flex justify-between items-center">
                            <div className="flex items-center gap-2">
                              <Users className="h-4 w-4 text-white/60" />
                              <span className="text-sm text-white/60">
                                {Math.floor(Math.random() * 1000)} affiliates
                              </span>
                            </div>
                            <Badge className="bg-[#00F0FF] text-[#0A0A14] cursor-pointer">Get Link</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

