"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

interface Metric {
  label: string
  value: string
  prefix?: string
  suffix?: string
}

export function SocialProofBar() {
  const [isVisible, setIsVisible] = useState(false)

  const metrics: Metric[] = [
    { label: "Active Users", value: "50,000", prefix: "+" },
    { label: "Total Earnings", value: "10", prefix: "$", suffix: "M+" },
    { label: "Avg. Commission", value: "12", suffix: "%" },
    { label: "Brand Partners", value: "2,500", prefix: "+" },
  ]

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{
        opacity: isVisible ? 1 : 0,
        y: isVisible ? 0 : 20,
      }}
      transition={{ duration: 0.5 }}
      className="fixed bottom-0 left-0 right-0 z-40 pointer-events-none"
    >
      <div className="max-w-7xl mx-auto px-4 mb-4 md:mb-8">
        <div className="bg-black/80 backdrop-blur-md border border-white/10 rounded-xl shadow-2xl overflow-hidden pointer-events-auto">
          <div className="flex flex-col md:flex-row items-center justify-between p-4">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></div>
              <p className="text-white/80 text-sm">
                <span className="font-medium">Live platform metrics</span> - Updated every 24 hours
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-10">
              {metrics.map((metric, index) => (
                <motion.div
                  key={metric.label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index + 0.5, duration: 0.3 }}
                  className="text-center"
                >
                  <p className="text-xl md:text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[#00F0FF] to-[#0033CC]">
                    {metric.prefix}
                    {metric.value}
                    {metric.suffix}
                  </p>
                  <p className="text-white/60 text-xs md:text-sm">{metric.label}</p>
                </motion.div>
              ))}
            </div>

            <button
              onClick={() => setIsVisible(false)}
              className="ml-4 text-white/40 hover:text-white transition-colors duration-300"
              aria-label="Close social proof bar"
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M12 4L4 12"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M4 4L12 12"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

