"use client"

import { useEffect } from "react"

export default function PreloadResources() {
  useEffect(() => {
    // Preload critical images
    const imagesToPreload = [
      "/images/hedo-moisturizer.png",
      "/images/coldlife-cooling.png",
      "/images/oats-overnight-pack.png",
      "/images/founders/brian-tate.png",
      "/images/founders/christy-buss.png",
      "/images/founders/tiffany-hollywood.png",
      "/images/founders/dan-fleyshman.png",
    ]

    imagesToPreload.forEach((src) => {
      const img = new Image()
      img.src = src
    })

    // Fix memory leaks by cleaning up preloaded resources
    return () => {
      // Cleanup function
    }
  }, [])

  return null
}

