"use client"

import { useState, useEffect } from "react"

interface AnimatedCounterProps {
  end: number
  decimals?: number
  suffix?: string
  duration?: number
}

export function AnimatedCounter({ end, decimals = 0, suffix = "", duration = 2000 }: AnimatedCounterProps) {
  const [count, setCount] = useState(0)

  useEffect(() => {
    const start = 0
    const increment = (end - start) / (duration / 16)
    let current = start

    const timer = setInterval(() => {
      current += increment
      if (current >= end) {
        clearInterval(timer)
        current = end
      }
      setCount(Number.parseFloat(current.toFixed(decimals)))
    }, 16)

    return () => clearInterval(timer)
  }, [end, decimals, duration])

  return (
    <span className="font-medium">
      {count.toLocaleString(undefined, {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      })}
      {suffix}
    </span>
  )
}

