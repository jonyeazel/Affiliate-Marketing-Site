import { cn } from "@/lib/utils"
import type { ReactNode } from "react"

interface GlowCardProps {
  children: ReactNode
  className?: string
}

export function GlowCard({ children, className }: GlowCardProps) {
  return (
    <div className="relative group">
      <div className="absolute -inset-0.5 bg-gradient-to-r from-[#00F0FF] to-[#0033CC] rounded-xl blur opacity-30 group-hover:opacity-50 transition duration-1000 group-hover:duration-300"></div>
      <div className={cn("relative", className)}>{children}</div>
    </div>
  )
}

