"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

export default function MarketTrendsChart({ data }) {
  // This is a simplified implementation - in a real app, you would use the actual data
  const chartData = data || [
    { month: "Jan", avgRate: 12.4 },
    { month: "Feb", avgRate: 12.6 },
    { month: "Mar", avgRate: 12.9 },
    { month: "Apr", avgRate: 13.2 },
    { month: "May", avgRate: 13.5 },
    { month: "Jun", avgRate: 13.8 },
  ]

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={chartData}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 10,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis domain={[12, 14]} />
        <Tooltip />
        <Legend />
        <Line
          type="monotone"
          dataKey="avgRate"
          name="Avg. Commission Rate (%)"
          stroke="hsl(var(--primary))"
          activeDot={{ r: 8 }}
        />
      </LineChart>
    </ResponsiveContainer>
  )
}

