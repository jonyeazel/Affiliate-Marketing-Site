"use client"

import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ZAxis } from "recharts"

export default function NicheOpportunityMap() {
  // This is a simplified implementation - in a real app, you would use the actual data
  const data = [
    { x: 85, y: 45, z: 200, name: "Sustainable Products" },
    { x: 78, y: 38, z: 180, name: "Remote Work Tools" },
    { x: 65, y: 32, z: 150, name: "Mental Wellness" },
    { x: 55, y: 28, z: 120, name: "Smart Home" },
    { x: 70, y: 25, z: 160, name: "Digital Education" },
    { x: 45, y: 20, z: 100, name: "Fitness Equipment" },
    { x: 35, y: 35, z: 90, name: "Home Decor" },
    { x: 25, y: 15, z: 70, name: "Beauty Products" },
    { x: 20, y: 25, z: 60, name: "Pet Supplies" },
    { x: 30, y: 40, z: 80, name: "Outdoor Gear" },
  ]

  return (
    <ResponsiveContainer width="100%" height="100%">
      <ScatterChart
        margin={{
          top: 20,
          right: 20,
          bottom: 20,
          left: 20,
        }}
      >
        <CartesianGrid />
        <XAxis
          type="number"
          dataKey="x"
          name="Market Size"
          unit="%"
          domain={[0, 100]}
          label={{ value: "Market Size", position: "bottom", offset: 0 }}
        />
        <YAxis
          type="number"
          dataKey="y"
          name="Growth Rate"
          unit="%"
          domain={[0, 50]}
          label={{ value: "Growth Rate", angle: -90, position: "left" }}
        />
        <ZAxis type="number" dataKey="z" range={[60, 200]} name="Opportunity Score" />
        <Tooltip cursor={{ strokeDasharray: "3 3" }} formatter={(value, name) => [value, name]} />
        <Scatter name="Niche Opportunities" data={data} fill="hsl(var(--primary))" />
      </ScatterChart>
    </ResponsiveContainer>
  )
}

