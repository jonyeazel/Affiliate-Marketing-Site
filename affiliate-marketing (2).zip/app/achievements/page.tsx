"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  Trophy,
  Star,
  Zap,
  Award,
  Gift,
  DollarSign,
  TrendingUp,
  Clock,
  CheckCircle,
  Lock,
  Search,
  Bell,
  Settings,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface Achievement {
  id: string
  title: string
  description: string
  icon: React.ElementType
  iconColor: string
  progress: number
  total: number
  reward: string
  rewardIcon: React.ElementType
  rewardColor: string
  isCompleted: boolean
  isLocked: boolean
  category: "earnings" | "engagement" | "growth" | "special"
}

export default function AchievementsPage() {
  const [activeTab, setActiveTab] = useState<string>("all")

  const achievements: Achievement[] = [
    {
      id: "1",
      title: "First $100",
      description: "Earn your first $100 through affiliate links",
      icon: DollarSign,
      iconColor: "#00FFFF",
      progress: 100,
      total: 100,
      reward: "$10 bonus",
      rewardIcon: Gift,
      rewardColor: "#FFFF00",
      isCompleted: true,
      isLocked: false,
      category: "earnings",
    },
    {
      id: "2",
      title: "Link Master",
      description: "Create 10 affiliate links",
      icon: Zap,
      iconColor: "#FF00FF",
      progress: 7,
      total: 10,
      reward: "Zero fee payout",
      rewardIcon: DollarSign,
      rewardColor: "#00FFFF",
      isCompleted: false,
      isLocked: false,
      category: "engagement",
    },
    {
      id: "3",
      title: "Conversion Pro",
      description: "Achieve 5% conversion rate on any link",
      icon: TrendingUp,
      iconColor: "#FFFF00",
      progress: 4.2,
      total: 5,
      reward: "Early access drops",
      rewardIcon: Star,
      rewardColor: "#FF00FF",
      isCompleted: false,
      isLocked: false,
      category: "growth",
    },
    {
      id: "4",
      title: "First $1,000",
      description: "Earn your first $1,000 through affiliate links",
      icon: DollarSign,
      iconColor: "#00FFFF",
      progress: 650,
      total: 1000,
      reward: "$25 bonus",
      rewardIcon: Gift,
      rewardColor: "#FFFF00",
      isCompleted: false,
      isLocked: false,
      category: "earnings",
    },
    {
      id: "5",
      title: "Social Butterfly",
      description: "Connect 3 social media accounts",
      icon: Award,
      iconColor: "#FF00FF",
      progress: 2,
      total: 3,
      reward: "Profile badge",
      rewardIcon: Award,
      rewardColor: "#FFFF00",
      isCompleted: false,
      isLocked: false,
      category: "engagement",
    },
    {
      id: "6",
      title: "Streak Master",
      description: "Log in for 7 consecutive days",
      icon: Zap,
      iconColor: "#FFFF00",
      progress: 5,
      total: 7,
      reward: "Exclusive theme",
      rewardIcon: Star,
      rewardColor: "#00FFFF",
      isCompleted: false,
      isLocked: false,
      category: "engagement",
    },
    {
      id: "7",
      title: "First $10,000",
      description: "Earn your first $10,000 through affiliate links",
      icon: DollarSign,
      iconColor: "#00FFFF",
      progress: 0,
      total: 10000,
      reward: "$100 bonus + VIP status",
      rewardIcon: Trophy,
      rewardColor: "#FFFF00",
      isCompleted: false,
      isLocked: true,
      category: "earnings",
    },
    {
      id: "8",
      title: "Viral Creator",
      description: "Have a link with over 1,000 clicks in a day",
      icon: TrendingUp,
      iconColor: "#FF00FF",
      progress: 0,
      total: 1000,
      reward: "Featured on homepage",
      rewardIcon: Star,
      rewardColor: "#FFFF00",
      isCompleted: false,
      isLocked: true,
      category: "growth",
    },
    {
      id: "9",
      title: "Early Adopter",
      description: "Joined during the beta phase",
      icon: Award,
      iconColor: "#FFFF00",
      progress: 1,
      total: 1,
      reward: "Limited edition badge",
      rewardIcon: Trophy,
      rewardColor: "#FF00FF",
      isCompleted: true,
      isLocked: false,
      category: "special",
    },
  ]

  const filteredAchievements =
    activeTab === "all" ? achievements : achievements.filter((achievement) => achievement.category === activeTab)

  const completedCount = achievements.filter((a) => a.isCompleted).length
  const totalCount = achievements.length
  const completionPercentage = Math.round((completedCount / totalCount) * 100)

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-black/80 border-b border-white/10">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2">
              <div className="relative h-8 w-8">
                <div className="absolute h-4 w-8 bg-[#FF00FF] top-0 rounded-sm"></div>
                <div className="absolute h-4 w-6 bg-[#00FFFF] bottom-0 left-1 rounded-sm"></div>
                <div className="absolute h-4 w-4 bg-[#FFFF00] bottom-0 right-1 rounded-sm"></div>
              </div>
              <span className="font-bold text-lg">moneydrip</span>
            </Link>

            <div className="hidden md:flex relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
              <Input
                placeholder="Search achievements..."
                className="pl-10 bg-white/5 border-white/10 focus:border-white/20 text-white"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-white/70 hover:text-white">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-white/70 hover:text-white">
              <Settings className="h-5 w-5" />
            </Button>
            <Avatar className="h-8 w-8">
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <div className="container py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="icon" className="h-10 w-10 border-white/20" asChild>
            <Link href="/dashboard">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Achievements</h1>
            <p className="text-white/60">Complete challenges to earn rewards and level up</p>
          </div>
        </div>

        {/* Progress Overview */}
        <Card className="bg-gradient-to-r from-[#FF00FF]/20 to-[#00FFFF]/20 border-white/10 mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="relative">
                <div className="h-32 w-32 rounded-full bg-[#191919] border-4 border-[#111111] flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-3xl font-bold">{completionPercentage}%</div>
                    <div className="text-sm text-white/60">Complete</div>
                  </div>
                </div>
                <div className="absolute -top-2 -right-2 bg-[#FFFF00] text-black rounded-full w-8 h-8 flex items-center justify-center">
                  <Trophy className="h-4 w-4" />
                </div>
              </div>

              <div className="flex-1">
                <h2 className="text-xl font-bold mb-2">Achievement Progress</h2>
                <p className="text-white/60 mb-4">
                  You've completed {completedCount} out of {totalCount} achievements. Keep going!
                </p>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                  <div className="bg-[#111111] rounded-lg p-3">
                    <div className="text-lg font-bold">
                      {achievements.filter((a) => a.category === "earnings" && a.isCompleted).length}/
                      {achievements.filter((a) => a.category === "earnings").length}
                    </div>
                    <div className="text-sm text-white/60">Earnings</div>
                  </div>
                  <div className="bg-[#111111] rounded-lg p-3">
                    <div className="text-lg font-bold">
                      {achievements.filter((a) => a.category === "engagement" && a.isCompleted).length}/
                      {achievements.filter((a) => a.category === "engagement").length}
                    </div>
                    <div className="text-sm text-white/60">Engagement</div>
                  </div>
                  <div className="bg-[#111111] rounded-lg p-3">
                    <div className="text-lg font-bold">
                      {achievements.filter((a) => a.category === "growth" && a.isCompleted).length}/
                      {achievements.filter((a) => a.category === "growth").length}
                    </div>
                    <div className="text-sm text-white/60">Growth</div>
                  </div>
                  <div className="bg-[#111111] rounded-lg p-3">
                    <div className="text-lg font-bold">
                      {achievements.filter((a) => a.category === "special" && a.isCompleted).length}/
                      {achievements.filter((a) => a.category === "special").length}
                    </div>
                    <div className="text-sm text-white/60">Special</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Achievements Tabs */}
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="bg-[#191919]">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="earnings">Earnings</TabsTrigger>
            <TabsTrigger value="engagement">Engagement</TabsTrigger>
            <TabsTrigger value="growth">Growth</TabsTrigger>
            <TabsTrigger value="special">Special</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Achievements Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAchievements.map((achievement) => (
            <motion.div
              key={achievement.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              <Card
                className={`${
                  achievement.isCompleted
                    ? "bg-gradient-to-br from-[#00FFFF]/20 to-[#FF00FF]/20"
                    : achievement.isLocked
                      ? "bg-[#111111] opacity-70"
                      : "bg-[#111111]"
                } border-white/10 overflow-hidden`}
              >
                {achievement.isCompleted && (
                  <div className="absolute top-0 right-0">
                    <div className="bg-[#00FFFF] text-black transform rotate-45 translate-y-2 px-4 py-1 text-xs font-bold">
                      COMPLETED
                    </div>
                  </div>
                )}

                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`h-10 w-10 rounded-full bg-[${achievement.iconColor}]/20 flex items-center justify-center`}
                      >
                        <achievement.icon className={`h-5 w-5 text-[${achievement.iconColor}]`} />
                      </div>
                      <div>
                        <CardTitle className="text-lg flex items-center gap-2">
                          {achievement.title}
                          {achievement.isLocked && <Lock className="h-4 w-4 text-white/40" />}
                        </CardTitle>
                        <CardDescription className="text-white/60">{achievement.description}</CardDescription>
                      </div>
                    </div>

                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div
                            className={`h-8 w-8 rounded-full bg-[${achievement.rewardColor}]/20 flex items-center justify-center`}
                          >
                            <achievement.rewardIcon className={`h-4 w-4 text-[${achievement.rewardColor}]`} />
                          </div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Reward: {achievement.reward}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </CardHeader>

                <CardContent>
                  <div className="mt-4">
                    <div className="flex items-center justify-between mb-1">
                      <div className="text-sm text-white/60">Progress</div>
                      <div className="text-sm font-medium">
                        {achievement.isCompleted ? (
                          <span className="flex items-center text-[#00FFFF]">
                            <CheckCircle className="mr-1 h-3 w-3" />
                            Complete
                          </span>
                        ) : (
                          <span>
                            {achievement.progress}/{achievement.total}
                            {achievement.category === "earnings" && " $"}
                            {achievement.category === "growth" && "%"}
                          </span>
                        )}
                      </div>
                    </div>

                    <Progress
                      value={(achievement.progress / achievement.total) * 100}
                      className="h-2 bg-white/10"
                      indicatorClassName={`bg-[${achievement.iconColor}]`}
                    />
                  </div>
                </CardContent>

                <CardFooter className="pt-0">
                  {achievement.isCompleted ? (
                    <div className="w-full text-center text-sm text-white/60">Completed on April 12, 2025</div>
                  ) : achievement.isLocked ? (
                    <div className="w-full text-center text-sm text-white/60 flex items-center justify-center">
                      <Lock className="mr-1 h-3 w-3" />
                      Complete previous achievements to unlock
                    </div>
                  ) : (
                    <div className="w-full text-center text-sm text-white/60 flex items-center justify-center">
                      <Clock className="mr-1 h-3 w-3" />
                      In progress
                    </div>
                  )}
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

