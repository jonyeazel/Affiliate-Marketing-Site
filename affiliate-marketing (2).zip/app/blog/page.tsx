import Link from "next/link"
import { ArrowRight, Calendar, Clock, Tag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"

export default function BlogPage() {
  const featuredPost = {
    id: 1,
    title: "The Future of Affiliate Marketing: AI, Creators, and Beyond",
    excerpt:
      "Explore how artificial intelligence and the creator economy are transforming affiliate marketing strategies and creating new opportunities.",
    category: "Trends",
    date: "March 15, 2025",
    readTime: "8 min read",
    image: "/placeholder.svg?height=400&width=800",
    author: {
      name: "Sarah Johnson",
      role: "Head of Content",
      avatar: "/placeholder.svg?height=40&width=40",
    },
  }

  const recentPosts = [
    {
      id: 2,
      title: "7 Proven Strategies to Increase Your Affiliate Conversion Rate",
      excerpt:
        "Learn tactical approaches to optimize your content and boost your affiliate marketing conversion rates.",
      category: "Strategy",
      date: "March 10, 2025",
      readTime: "6 min read",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 3,
      title: "How to Build Trust with Your Audience While Promoting Affiliate Products",
      excerpt:
        "Discover the balance between monetization and maintaining audience trust with authentic recommendations.",
      category: "Best Practices",
      date: "March 5, 2025",
      readTime: "5 min read",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 4,
      title: "The Complete Guide to FTC Disclosure Requirements for Affiliates",
      excerpt:
        "Stay compliant with this comprehensive breakdown of disclosure requirements across different platforms.",
      category: "Compliance",
      date: "February 28, 2025",
      readTime: "7 min read",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 5,
      title: "Affiliate Marketing for Beginners: From Zero to First Commission",
      excerpt:
        "A step-by-step guide for newcomers to start their affiliate marketing journey and earn their first commission.",
      category: "Beginners",
      date: "February 20, 2025",
      readTime: "10 min read",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 6,
      title: "Multi-Channel Attribution: Tracking Affiliate Success Across Platforms",
      excerpt: "Learn how to implement effective attribution models to understand your true affiliate marketing ROI.",
      category: "Analytics",
      date: "February 15, 2025",
      readTime: "8 min read",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 7,
      title: "Case Study: How This Creator Scaled to $50K/Month with Affiliate Marketing",
      excerpt: "An in-depth analysis of how one content creator built a sustainable affiliate marketing business.",
      category: "Case Study",
      date: "February 10, 2025",
      readTime: "12 min read",
      image: "/placeholder.svg?height=200&width=400",
    },
  ]

  const categories = [
    { name: "Strategy", count: 24 },
    { name: "Analytics", count: 18 },
    { name: "Beginners", count: 15 },
    { name: "Compliance", count: 12 },
    { name: "Case Study", count: 10 },
    { name: "Trends", count: 8 },
    { name: "Best Practices", count: 22 },
  ]

  return (
    <div className="bg-background">
      <div className="container py-12 md:py-24">
        <div className="mx-auto max-w-3xl text-center mb-16">
          <Badge className="mb-4" variant="secondary">
            Resources
          </Badge>
          <h1 className="mb-4 text-3xl font-bold sm:text-4xl md:text-5xl">Affiliate Marketing Insights & Strategies</h1>
          <p className="text-muted-foreground md:text-xl">
            Expert advice, industry trends, and practical tips to help you succeed in affiliate marketing.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-12 max-w-4xl mx-auto">
          <div className="flex-1">
            <Input placeholder="Search articles..." className="w-full" />
          </div>
          <Tabs defaultValue="all" className="w-full md:w-auto">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="guides">Guides</TabsTrigger>
              <TabsTrigger value="case-studies">Case Studies</TabsTrigger>
              <TabsTrigger value="tutorials">Tutorials</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Featured Post */}
        <div className="mb-16">
          <Card className="overflow-hidden border-none shadow-lg">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="order-2 md:order-1 p-6 md:p-8 flex flex-col justify-center">
                <div className="mb-4">
                  <Badge variant="secondary" className="mb-2">
                    {featuredPost.category}
                  </Badge>
                  <CardTitle className="text-2xl md:text-3xl mb-2">{featuredPost.title}</CardTitle>
                  <CardDescription className="text-base">{featuredPost.excerpt}</CardDescription>
                </div>
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>{featuredPost.date}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{featuredPost.readTime}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3 mb-6">
                  <div className="h-10 w-10 rounded-full overflow-hidden">
                    <img
                      src={featuredPost.author.avatar || "/placeholder.svg"}
                      alt={featuredPost.author.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="font-medium">{featuredPost.author.name}</div>
                    <div className="text-sm text-muted-foreground">{featuredPost.author.role}</div>
                  </div>
                </div>
                <Button asChild className="w-full md:w-auto">
                  <Link href={`/blog/${featuredPost.id}`}>
                    Read Article
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
              <div className="order-1 md:order-2">
                <img
                  src={featuredPost.image || "/placeholder.svg"}
                  alt={featuredPost.title}
                  className="h-full w-full object-cover aspect-video md:aspect-auto"
                />
              </div>
            </div>
          </Card>
        </div>

        {/* Recent Posts */}
        <div className="mb-16">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold">Recent Articles</h2>
            <Button variant="outline">
              View All
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {recentPosts.map((post) => (
              <Card key={post.id} className="overflow-hidden flex flex-col h-full">
                <div className="aspect-video overflow-hidden">
                  <img
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                </div>
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary">{post.category}</Badge>
                    <div className="text-xs text-muted-foreground">{post.date}</div>
                  </div>
                  <CardTitle className="text-xl">{post.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1">
                  <CardDescription className="text-base">{post.excerpt}</CardDescription>
                </CardContent>
                <CardFooter className="pt-0">
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Clock className="mr-1 h-4 w-4" />
                      {post.readTime}
                    </div>
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/blog/${post.id}`}>
                        Read More
                        <ArrowRight className="ml-1 h-3 w-3" />
                      </Link>
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>

        {/* Categories and Newsletter */}
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Popular Categories</CardTitle>
                <CardDescription>Browse articles by topic</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {categories.map((category) => (
                    <Link
                      key={category.name}
                      href={`/blog/category/${category.name.toLowerCase()}`}
                      className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-sm font-semibold transition-colors hover:bg-secondary"
                    >
                      <Tag className="mr-1 h-3 w-3" />
                      {category.name}
                      <span className="ml-1 text-xs text-muted-foreground">({category.count})</span>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          <div>
            <Card className="bg-primary text-primary-foreground">
              <CardHeader>
                <CardTitle>Subscribe to Our Newsletter</CardTitle>
                <CardDescription className="text-primary-foreground/80">
                  Get the latest affiliate marketing tips and strategies delivered to your inbox.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <Input placeholder="Your email address" className="bg-primary-foreground text-foreground" />
                  <Button className="w-full bg-background text-foreground hover:bg-background/90">Subscribe</Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

