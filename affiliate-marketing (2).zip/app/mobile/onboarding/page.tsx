"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ArrowRight, Check, ChevronLeft, DollarSign, Zap, Gift } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import MoneyDripLogo from "@/components/mobile/moneydrip-logo"

export default function OnboardingPage() {
  const [step, setStep] = useState(1)
  const [answers, setAnswers] = useState({
    role: "",
    experience: "",
    goal: "",
    platform: "",
    niche: "",
  })
  const [completed, setCompleted] = useState(false)

  const totalSteps = 5
  const progress = (step / totalSteps) * 100

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1)
      window.scrollTo(0, 0)
    } else {
      setCompleted(true)
    }
  }

  const handlePrevious = () => {
    if (step > 1) {
      setStep(step - 1)
      window.scrollTo(0, 0)
    }
  }

  const handleAnswerChange = (question: string, value: string) => {
    setAnswers({ ...answers, [question]: value })
  }

  if (completed) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col">
        <div className="flex items-center justify-center h-16 border-b border-white/10">
          <MoneyDripLogo />
        </div>

        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-6 w-20 h-20 rounded-full bg-[#00CFCF] flex items-center justify-center"
          >
            <Check className="h-10 w-10 text-black" />
          </motion.div>

          <h1 className="text-3xl font-bold mb-2">You're All Set!</h1>
          <p className="text-white/60 mb-8">Your personalized MoneyDrip experience is ready</p>

          <Card className="bg-[#111111] border-white/10 w-full mb-8">
            <div className="p-4">
              <h2 className="font-bold mb-4">Your Personalized Roadmap</h2>

              <div className="space-y-4">
                <div className="relative pl-8 pb-4 border-l-2 border-[#00CFCF]">
                  <div className="absolute left-[-8px] top-0 w-4 h-4 rounded-full bg-[#00CFCF]"></div>
                  <div className="mb-1">
                    <h3 className="text-lg font-medium">Get Started</h3>
                    <p className="text-sm text-white/60">Today</p>
                  </div>
                  <p className="text-sm">Create your first affiliate link and start earning immediately.</p>
                </div>

                <div className="relative pl-8 pb-4 border-l-2 border-[#00CFCF]/70">
                  <div className="absolute left-[-8px] top-0 w-4 h-4 rounded-full bg-[#00CFCF]/70"></div>
                  <div className="mb-1">
                    <h3 className="text-lg font-medium">Get Paid</h3>
                    <p className="text-sm text-white/60">Instantly</p>
                  </div>
                  <p className="text-sm">Cash out your earnings whenever you want, no waiting periods.</p>
                </div>

                <div className="relative pl-8 border-l-2 border-[#00CFCF]/40">
                  <div className="absolute left-[-8px] top-0 w-4 h-4 rounded-full bg-[#00CFCF]/40"></div>
                  <div className="mb-1">
                    <h3 className="text-lg font-medium">Grow</h3>
                    <p className="text-sm text-white/60">Ongoing</p>
                  </div>
                  <p className="text-sm">Find more opportunities that match your content and audience.</p>
                </div>
              </div>
            </div>
          </Card>

          <div className="w-full space-y-3">
            <Button className="w-full bg-[#00CFCF] text-black font-bold" href="/mobile">
              Start Earning Now
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>

            <Button variant="outline" className="w-full border-white/20">
              Explore Opportunities
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <div className="flex items-center h-16 px-4 border-b border-white/10">
        <Button variant="ghost" size="icon" onClick={handlePrevious} disabled={step === 1}>
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1 flex justify-center">
          <MoneyDripLogo />
        </div>
        <div className="w-10"></div> {/* Spacer for balance */}
      </div>

      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-xl font-bold">Personalize Your Experience</h1>
          <span className="text-sm font-medium text-white/60">
            {step}/{totalSteps}
          </span>
        </div>
        <Progress value={progress} className="h-1.5 mb-6" indicatorClassName="bg-[#00CFCF]" />

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {step === 1 && (
              <div className="space-y-4">
                <h2 className="text-lg font-medium">What best describes your role?</h2>
                <p className="text-white/60 text-sm">This helps us tailor your experience.</p>

                <RadioGroup
                  value={answers.role}
                  onValueChange={(value) => handleAnswerChange("role", value)}
                  className="grid gap-3 pt-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="creator" id="creator" className="peer sr-only" />
                    <Label
                      htmlFor="creator"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <div className="flex flex-col gap-1">
                        <span className="font-medium">Content Creator</span>
                        <span className="text-sm text-white/60">I create content and want to monetize it</span>
                      </div>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="affiliate" id="affiliate" className="peer sr-only" />
                    <Label
                      htmlFor="affiliate"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <div className="flex flex-col gap-1">
                        <span className="font-medium">Affiliate Marketer</span>
                        <span className="text-sm text-white/60">I promote products and earn commissions</span>
                      </div>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="brand" id="brand" className="peer sr-only" />
                    <Label
                      htmlFor="brand"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <div className="flex flex-col gap-1">
                        <span className="font-medium">Brand or Business</span>
                        <span className="text-sm text-white/60">I want to start or improve an affiliate program</span>
                      </div>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <h2 className="text-lg font-medium">What's your experience level?</h2>
                <p className="text-white/60 text-sm">We'll adjust the content to your expertise.</p>

                <RadioGroup
                  value={answers.experience}
                  onValueChange={(value) => handleAnswerChange("experience", value)}
                  className="grid gap-3 pt-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="beginner" id="beginner" className="peer sr-only" />
                    <Label
                      htmlFor="beginner"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">Beginner</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="intermediate" id="intermediate" className="peer sr-only" />
                    <Label
                      htmlFor="intermediate"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">Intermediate</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="advanced" id="advanced" className="peer sr-only" />
                    <Label
                      htmlFor="advanced"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">Advanced</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <h2 className="text-lg font-medium">What's your primary goal?</h2>
                <p className="text-white/60 text-sm">We'll focus your experience on this outcome.</p>

                <RadioGroup
                  value={answers.goal}
                  onValueChange={(value) => handleAnswerChange("goal", value)}
                  className="grid gap-3 pt-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="increase-revenue" id="increase-revenue" className="peer sr-only" />
                    <Label
                      htmlFor="increase-revenue"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#FFFFFF] peer-data-[state=checked]:bg-[#FFFFFF]/10"
                    >
                      <div className="flex items-center gap-3">
                        <DollarSign className="h-5 w-5 text-[#FFFFFF]" />
                        <span className="font-medium">Increase revenue</span>
                      </div>
                      <Check className="h-5 w-5 text-[#FFFFFF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="find-partners" id="find-partners" className="peer sr-only" />
                    <Label
                      htmlFor="find-partners"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#FFFFFF] peer-data-[state=checked]:bg-[#FFFFFF]/10"
                    >
                      <div className="flex items-center gap-3">
                        <Gift className="h-5 w-5 text-[#FFFFFF]" />
                        <span className="font-medium">Find the right partners</span>
                      </div>
                      <Check className="h-5 w-5 text-[#FFFFFF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="instant-payouts" id="instant-payouts" className="peer sr-only" />
                    <Label
                      htmlFor="instant-payouts"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#FFFFFF] peer-data-[state=checked]:bg-[#FFFFFF]/10"
                    >
                      <div className="flex items-center gap-3">
                        <Zap className="h-5 w-5 text-[#FFFFFF]" />
                        <span className="font-medium">Get paid faster</span>
                      </div>
                      <Check className="h-5 w-5 text-[#FFFFFF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-4">
                <h2 className="text-lg font-medium">Where do you create content?</h2>
                <p className="text-white/60 text-sm">Select your primary platform.</p>

                <RadioGroup
                  value={answers.platform}
                  onValueChange={(value) => handleAnswerChange("platform", value)}
                  className="grid gap-3 pt-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="tiktok" id="tiktok" className="peer sr-only" />
                    <Label
                      htmlFor="tiktok"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">TikTok</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="instagram" id="instagram" className="peer sr-only" />
                    <Label
                      htmlFor="instagram"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">Instagram</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="youtube" id="youtube" className="peer sr-only" />
                    <Label
                      htmlFor="youtube"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">YouTube</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="website" id="website" className="peer sr-only" />
                    <Label
                      htmlFor="website"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">Website/Blog</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {step === 5 && (
              <div className="space-y-4">
                <h2 className="text-lg font-medium">What's your content niche?</h2>
                <p className="text-white/60 text-sm">This helps us find the best opportunities for you.</p>

                <RadioGroup
                  value={answers.niche}
                  onValueChange={(value) => handleAnswerChange("niche", value)}
                  className="grid gap-3 pt-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="tech" id="tech" className="peer sr-only" />
                    <Label
                      htmlFor="tech"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">Tech & Gadgets</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="beauty" id="beauty" className="peer sr-only" />
                    <Label
                      htmlFor="beauty"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">Beauty & Fashion</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="fitness" id="fitness" className="peer sr-only" />
                    <Label
                      htmlFor="fitness"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">Fitness & Health</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="lifestyle" id="lifestyle" className="peer sr-only" />
                    <Label
                      htmlFor="lifestyle"
                      className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-white/10 bg-[#111111] p-4 hover:bg-[#191919] hover:border-white/20 peer-data-[state=checked]:border-[#00CFCF] peer-data-[state=checked]:bg-[#00CFCF]/10"
                    >
                      <span className="font-medium">Lifestyle & Home</span>
                      <Check className="h-5 w-5 text-[#00CFCF] opacity-0 peer-data-[state=checked]:opacity-100" />
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="mt-auto p-4">
        <Button
          className="w-full bg-[#00CFCF] text-black font-bold"
          onClick={handleNext}
          disabled={
            (step === 1 && !answers.role) ||
            (step === 2 && !answers.experience) ||
            (step === 3 && !answers.goal) ||
            (step === 4 && !answers.platform) ||
            (step === 5 && !answers.niche)
          }
        >
          {step === totalSteps ? "Complete" : "Continue"}
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>

        <div className="mt-4 text-center text-xs text-white/40">Powered by AffiliateMarketing.com</div>
      </div>
    </div>
  )
}

