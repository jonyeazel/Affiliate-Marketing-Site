import { redirect } from "next/navigation"

export function GET() {
  redirect("/mobile/landing-page")
}

