"use client"

import { useState } from "react"
import { TrendingUp, TrendingDown, DollarSign, Users, Link, Clock, ChevronRight, LineChart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { DashboardShell } from "@/components/dashboard-shell"

export default function DashboardPage() {
  const [timeRange, setTimeRange] = useState<"day" | "week" | "month" | "year">("month")

  return (
    <DashboardShell>
      <div className="space-y-6">
        {/* Welcome Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold">Welcome back, John</h1>
            <p className="text-white/70">Here's what's happening with your affiliate programs today.</p>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" className="border-white/10 hover:bg-white/5">
              Export Data
            </Button>
            <Button className="bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90">
              Create Link
            </Button>
          </div>
        </div>

        {/* Time Range Selector */}
        <div className="flex items-center gap-2 bg-white/5 p-1 rounded-lg w-fit">
          {(["day", "week", "month", "year"] as const).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
                timeRange === range
                  ? "bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white"
                  : "text-white/70 hover:text-white hover:bg-white/5"
              }`}
            >
              {range.charAt(0).toUpperCase() + range.slice(1)}
            </button>
          ))}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-[#0A0A14] border-white/10">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-white/70">Total Earnings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className="text-2xl font-bold">$4,550.80</div>
                <div className="flex items-center text-green-400 text-sm">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  <span>+12.5%</span>
                </div>
              </div>
              <p className="text-xs text-white/50 mt-1">vs. previous {timeRange}</p>
            </CardContent>
          </Card>

          <Card className="bg-[#0A0A14] border-white/10">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-white/70">Conversion Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className="text-2xl font-bold">3.2%</div>
                <div className="flex items-center text-red-400 text-sm">
                  <TrendingDown className="h-4 w-4 mr-1" />
                  <span>-0.8%</span>
                </div>
              </div>
              <p className="text-xs text-white/50 mt-1">vs. previous {timeRange}</p>
            </CardContent>
          </Card>

          <Card className="bg-[#0A0A14] border-white/10">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-white/70">Total Clicks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className="text-2xl font-bold">12,580</div>
                <div className="flex items-center text-green-400 text-sm">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  <span>+18.2%</span>
                </div>
              </div>
              <p className="text-xs text-white/50 mt-1">vs. previous {timeRange}</p>
            </CardContent>
          </Card>

          <Card className="bg-[#0A0A14] border-white/10">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-white/70">Active Programs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className="text-2xl font-bold">8</div>
                <Badge className="bg-[#00F0FF]/20 text-[#00F0FF] border-[#00F0FF]/30" variant="outline">
                  +2 New
                </Badge>
              </div>
              <p className="text-xs text-white/50 mt-1">2 pending applications</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="bg-[#0A0A14] border-white/10 lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Earnings Overview</CardTitle>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 rounded-full bg-[#00F0FF]"></div>
                    <span className="text-xs text-white/70">Earnings</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 rounded-full bg-white/30"></div>
                    <span className="text-xs text-white/70">Clicks</span>
                  </div>
                </div>
              </div>
              <CardDescription>Your earnings and clicks over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px] flex items-center justify-center">
              <LineChart className="h-16 w-16 text-white/20" />
              <span className="ml-4 text-white/50">Chart visualization goes here</span>
            </CardContent>
          </Card>

          <Card className="bg-[#0A0A14] border-white/10">
            <CardHeader>
              <CardTitle>Top Programs</CardTitle>
              <CardDescription>Your best performing affiliate programs</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 flex items-center justify-center">
                    <DollarSign className="h-5 w-5 text-purple-400" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">Tech Gadgets Pro</h4>
                      <span className="text-green-400">$1,245</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-purple-700 rounded-full"
                        style={{ width: "75%" }}
                      ></div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500/20 to-blue-700/20 flex items-center justify-center">
                    <DollarSign className="h-5 w-5 text-blue-400" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">Fitness Supplements</h4>
                      <span className="text-green-400">$980</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-blue-700 rounded-full"
                        style={{ width: "60%" }}
                      ></div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500/20 to-green-700/20 flex items-center justify-center">
                    <DollarSign className="h-5 w-5 text-green-400" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">Online Courses</h4>
                      <span className="text-green-400">$750</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-green-500 to-green-700 rounded-full"
                        style={{ width: "45%" }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full text-[#00F0FF] hover:bg-[#00F0FF]/10">
                View All Programs
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </CardFooter>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card className="bg-[#0A0A14] border-white/10">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recent Activity</CardTitle>
              <Button variant="ghost" className="text-[#00F0FF] hover:bg-[#00F0FF]/10">
                View All
              </Button>
            </div>
            <CardDescription>Your latest transactions and events</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center mt-1">
                  <DollarSign className="h-5 w-5 text-green-400" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-medium">Commission Earned</h4>
                      <p className="text-sm text-white/70">You earned a commission from Tech Gadgets Pro</p>
                    </div>
                    <div className="text-right">
                      <span className="text-green-400 font-medium">+$45.50</span>
                      <p className="text-xs text-white/50">2 hours ago</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center mt-1">
                  <Link className="h-5 w-5 text-blue-400" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-medium">New Link Created</h4>
                      <p className="text-sm text-white/70">You created a new affiliate link for Fitness Supplements</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-white/50">Yesterday</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center mt-1">
                  <Users className="h-5 w-5 text-purple-400" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-medium">Program Application</h4>
                      <p className="text-sm text-white/70">Your application for Beauty Products Inc. was approved</p>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30" variant="outline">
                        Approved
                      </Badge>
                      <p className="text-xs text-white/50 mt-1">2 days ago</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-yellow-500/10 flex items-center justify-center mt-1">
                  <Clock className="h-5 w-5 text-yellow-400" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-medium">Payout Processed</h4>
                      <p className="text-sm text-white/70">Your monthly payout of $1,245.80 has been processed</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-white/50">3 days ago</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recommended Programs */}
        <Card className="bg-[#0A0A14] border-white/10">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recommended Programs</CardTitle>
              <Button variant="ghost" className="text-[#00F0FF] hover:bg-[#00F0FF]/10">
                View All
              </Button>
            </div>
            <CardDescription>Programs that match your profile and audience</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="bg-white/5 rounded-lg p-4 border border-white/10 hover:border-[#00F0FF]/30 hover:bg-white/10 transition-all duration-300">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500/20 to-purple-700/20 flex items-center justify-center">
                    <DollarSign className="h-6 w-6 text-pink-400" />
                  </div>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30" variant="outline">
                    15% Commission
                  </Badge>
                </div>
                <h3 className="font-medium mb-1">Beauty Products Inc.</h3>
                <p className="text-sm text-white/70 mb-3">
                  Premium skincare and beauty products with high conversion rates
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex -space-x-2">
                      {[1, 2, 3].map((i) => (
                        <div
                          key={i}
                          className="w-6 h-6 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] border border-[#0A0A14]"
                        ></div>
                      ))}
                    </div>
                    <span className="text-xs text-white/50 ml-2">+120 affiliates</span>
                  </div>
                  <Button
                    size="sm"
                    className="bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90"
                  >
                    Apply
                  </Button>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4 border border-white/10 hover:border-[#00F0FF]/30 hover:bg-white/10 transition-all duration-300">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500/20 to-red-700/20 flex items-center justify-center">
                    <DollarSign className="h-6 w-6 text-orange-400" />
                  </div>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30" variant="outline">
                    20% Commission
                  </Badge>
                </div>
                <h3 className="font-medium mb-1">Home Fitness Equipment</h3>
                <p className="text-sm text-white/70 mb-3">High-quality home gym equipment with recurring commissions</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex -space-x-2">
                      {[1, 2, 3].map((i) => (
                        <div
                          key={i}
                          className="w-6 h-6 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] border border-[#0A0A14]"
                        ></div>
                      ))}
                    </div>
                    <span className="text-xs text-white/50 ml-2">+85 affiliates</span>
                  </div>
                  <Button
                    size="sm"
                    className="bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90"
                  >
                    Apply
                  </Button>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4 border border-white/10 hover:border-[#00F0FF]/30 hover:bg-white/10 transition-all duration-300">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500/20 to-indigo-700/20 flex items-center justify-center">
                    <DollarSign className="h-6 w-6 text-blue-400" />
                  </div>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30" variant="outline">
                    25% Commission
                  </Badge>
                </div>
                <h3 className="font-medium mb-1">Digital Marketing Course</h3>
                <p className="text-sm text-white/70 mb-3">Comprehensive online courses with high-ticket commissions</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex -space-x-2">
                      {[1, 2, 3].map((i) => (
                        <div
                          key={i}
                          className="w-6 h-6 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] border border-[#0A0A14]"
                        ></div>
                      ))}
                    </div>
                    <span className="text-xs text-white/50 ml-2">+210 affiliates</span>
                  </div>
                  <Button
                    size="sm"
                    className="bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90"
                  >
                    Apply
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}

