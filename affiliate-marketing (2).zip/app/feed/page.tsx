"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import {
  Heart,
  MessageCircle,
  Share2,
  DollarSign,
  Zap,
  Sparkles,
  TrendingUp,
  BarChart3,
  Users,
  Filter,
  ChevronDown,
  Search,
  Bell,
  Settings,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import FeedSidebar from "@/components/feed/feed-sidebar"
import TrendingCreators from "@/components/feed/trending-creators"

interface Post {
  id: string
  user: {
    name: string
    username: string
    avatar: string
    isVerified: boolean
  }
  content: string
  media?: string
  earnings: number
  likes: number
  comments: number
  shares: number
  timestamp: Date
  product?: {
    name: string
    image: string
    earnings: number
    platform: string
  }
  isNew?: boolean
}

export default function FeedPage() {
  const [activeTab, setActiveTab] = useState("for-you")
  const [posts, setPosts] = useState<Post[]>([])
  const [likedPosts, setLikedPosts] = useState<string[]>([])

  useEffect(() => {
    // Initial posts
    const initialPosts: Post[] = [
      {
        id: "1",
        user: {
          name: "Mia Chen",
          username: "miacreates",
          avatar: "/placeholder.svg?height=40&width=40",
          isVerified: true,
        },
        content:
          "just dropped my tech essentials collection and it's already converting at 8.2% 🤯 this collab with @techgear is insane! who else is in the tech niche?",
        media: "/placeholder.svg?height=400&width=600",
        earnings: 432.19,
        likes: 124,
        comments: 28,
        shares: 12,
        timestamp: new Date(Date.now() - 1000 * 60 * 30),
        product: {
          name: "Ultra Boost Headphones Pro",
          image: "/placeholder.svg?height=80&width=80",
          earnings: 432.19,
          platform: "TechGear",
        },
      },
      {
        id: "2",
        user: {
          name: "Alex Rivera",
          username: "alexcreates",
          avatar: "/placeholder.svg?height=40&width=40",
          isVerified: true,
        },
        content:
          "broke my personal record today! $1,289 in a single day from my finance guide links 📈 the key is building trust with your audience before recommending products",
        earnings: 1289.45,
        likes: 256,
        comments: 42,
        shares: 38,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
      },
      {
        id: "3",
        user: {
          name: "Jordan Williams",
          username: "jordanwilliams",
          avatar: "/placeholder.svg?height=40&width=40",
          isVerified: false,
        },
        content:
          "testing out this new fitness tracker and the affiliate program is paying 20% commission! already made $167 today just from my morning workout story 💪",
        media: "/placeholder.svg?height=400&width=600",
        earnings: 167.82,
        likes: 98,
        comments: 14,
        shares: 7,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5),
        product: {
          name: "FitPro Smart Watch",
          image: "/placeholder.svg?height=80&width=80",
          earnings: 167.82,
          platform: "ActiveLife",
        },
      },
      {
        id: "4",
        user: {
          name: "Taylor Kim",
          username: "taylorkim",
          avatar: "/placeholder.svg?height=40&width=40",
          isVerified: true,
        },
        content:
          "just hit level 25 on moneydrip! unlocked the zero instant payout fees perk and it's already saved me $45 this week. the grind is real but so worth it 🔥",
        earnings: 0,
        likes: 187,
        comments: 32,
        shares: 5,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 8),
      },
    ]

    setPosts(initialPosts)

    // Simulate new posts coming in
    const interval = setInterval(() => {
      const names = ["Zoe", "Kai", "Riley", "Morgan", "Jamie", "Casey", "Quinn", "Avery"]
      const usernames = [
        "zoecreates",
        "kaivibes",
        "rileydigital",
        "morgancontent",
        "jamietech",
        "caseystyle",
        "quinnreviews",
        "averylife",
      ]

      const newPost: Post = {
        id: Date.now().toString(),
        user: {
          name: `${names[Math.floor(Math.random() * names.length)]} ${String.fromCharCode(65 + Math.floor(Math.random() * 26))}`,
          username: `${usernames[Math.floor(Math.random() * usernames.length)]}`,
          avatar: `/placeholder.svg?height=40&width=40`,
          isVerified: Math.random() > 0.7,
        },
        content: [
          "just made my first $100 with moneydrip! this is way easier than i thought 🤑",
          "found this insane beauty product collab that's converting at 12%! who wants the link?",
          "hit $500 today from my tech reviews! moneydrip's instant payout feature is a game changer",
          "anyone else in the fitness niche? just joined a collab that's paying $45 per conversion 💪",
          "my audience is loving these product recommendations! made $230 today without being salesy",
          "the money feed is so addictive! seeing everyone's earnings is motivating me to create more content",
        ][Math.floor(Math.random() * 6)],
        media: Math.random() > 0.5 ? "/placeholder.svg?height=400&width=600" : undefined,
        earnings: Math.random() > 0.3 ? Number.parseFloat((Math.random() * 500 + 50).toFixed(2)) : 0,
        likes: Math.floor(Math.random() * 200 + 10),
        comments: Math.floor(Math.random() * 50 + 5),
        shares: Math.floor(Math.random() * 20 + 1),
        timestamp: new Date(),
        isNew: true,
      }

      if (Math.random() > 0.6 && newPost.earnings > 0) {
        newPost.product = {
          name: [
            "Premium Wireless Earbuds",
            "Skincare Essentials Kit",
            "Fitness Resistance Bands",
            "Smart Home Starter Pack",
            "Productivity Planner Pro",
          ][Math.floor(Math.random() * 5)],
          image: "/placeholder.svg?height=80&width=80",
          earnings: newPost.earnings,
          platform: ["TechGear", "GlowUp", "ActiveLife", "HomeHub", "WorkFlow"][Math.floor(Math.random() * 5)],
        }
      }

      setPosts((prev) => [newPost, ...prev])

      // Remove the "new" flag after animation
      setTimeout(() => {
        setPosts((prev) => prev.map((post) => (post.id === newPost.id ? { ...post, isNew: false } : post)))
      }, 3000)
    }, 45000) // New post every 45 seconds

    return () => clearInterval(interval)
  }, [])

  const toggleLike = (postId: string) => {
    if (likedPosts.includes(postId)) {
      setLikedPosts((prev) => prev.filter((id) => id !== postId))
      setPosts((prev) => prev.map((post) => (post.id === postId ? { ...post, likes: post.likes - 1 } : post)))
    } else {
      setLikedPosts((prev) => [...prev, postId])
      setPosts((prev) => prev.map((post) => (post.id === postId ? { ...post, likes: post.likes + 1 } : post)))
    }
  }

  const formatTime = (date: Date) => {
    const now = new Date()
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

    if (diffInSeconds < 60) return `${diffInSeconds}s ago`
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`
    return `${Math.floor(diffInSeconds / 86400)}d ago`
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-black/80 border-b border-white/10">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2">
              <div className="relative h-8 w-8">
                <div className="absolute h-4 w-8 bg-[#FF00FF] top-0 rounded-sm"></div>
                <div className="absolute h-4 w-6 bg-[#00FFFF] bottom-0 left-1 rounded-sm"></div>
                <div className="absolute h-4 w-4 bg-[#FFFF00] bottom-0 right-1 rounded-sm"></div>
              </div>
              <span className="font-bold text-lg">moneydrip</span>
            </Link>

            <div className="hidden md:flex relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
              <Input
                placeholder="Search creators, products..."
                className="pl-10 bg-white/5 border-white/10 focus:border-white/20 text-white"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-white/70 hover:text-white">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-white/70 hover:text-white">
              <Settings className="h-5 w-5" />
            </Button>
            <Avatar className="h-8 w-8">
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <div className="container py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="w-full lg:w-64 lg:flex-shrink-0">
            <div className="lg:sticky lg:top-24">
              <FeedSidebar />
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="mb-6">
              <div className="flex items-center justify-between">
                <TabsList className="bg-[#191919]">
                  <TabsTrigger value="for-you">For You</TabsTrigger>
                  <TabsTrigger value="following">Following</TabsTrigger>
                  <TabsTrigger value="trending">Trending</TabsTrigger>
                </TabsList>

                <div className="flex items-center gap-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm" className="border-white/20">
                        <Filter className="mr-2 h-4 w-4" />
                        Filter
                        <ChevronDown className="ml-2 h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-[#191919] border-white/10">
                      <DropdownMenuItem className="text-white/80 focus:text-white focus:bg-white/10">
                        All Posts
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-white/80 focus:text-white focus:bg-white/10">
                        Earnings Only
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-white/80 focus:text-white focus:bg-white/10">
                        Product Posts
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-white/80 focus:text-white focus:bg-white/10">
                        Tips & Advice
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </Tabs>

            <div className="space-y-6">
              <AnimatePresence>
                {posts.map((post) => (
                  <motion.div
                    key={post.id}
                    initial={post.isNew ? { opacity: 0, y: -20 } : false}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="bg-[#111111] rounded-xl border border-white/10 overflow-hidden"
                  >
                    <div className="p-4">
                      <div className="flex items-start gap-3 mb-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={post.user.avatar} alt={post.user.name} />
                          <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
                        </Avatar>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1">
                            <span className="font-medium">{post.user.name}</span>
                            {post.user.isVerified && (
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger>
                                    <Badge className="h-4 w-4 p-0 bg-[#00FFFF] text-black rounded-full flex items-center justify-center">
                                      <Sparkles className="h-2.5 w-2.5" />
                                    </Badge>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Verified Creator</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-white/60">@{post.user.username}</span>
                            <span className="text-white/40">•</span>
                            <span className="text-sm text-white/60">{formatTime(post.timestamp)}</span>
                          </div>
                        </div>

                        {post.earnings > 0 && (
                          <div className="flex items-center bg-[#191919] rounded-full px-3 py-1">
                            <DollarSign className="h-3.5 w-3.5 text-[#00FFFF] mr-1" />
                            <span className="font-medium text-[#00FFFF]">${post.earnings}</span>
                          </div>
                        )}
                      </div>

                      <p className="mb-4 whitespace-pre-line">{post.content}</p>

                      {post.media && (
                        <div className="mb-4 rounded-lg overflow-hidden">
                          <img
                            src={post.media || "/placeholder.svg"}
                            alt="Post media"
                            className="w-full h-auto object-cover"
                          />
                        </div>
                      )}

                      {post.product && (
                        <Card className="mb-4 bg-[#191919] border-white/10">
                          <CardContent className="p-3">
                            <div className="flex items-center gap-3">
                              <div className="h-16 w-16 bg-[#222222] rounded-md flex items-center justify-center overflow-hidden">
                                <img
                                  src={post.product.image || "/placeholder.svg"}
                                  alt={post.product.name}
                                  className="max-w-full max-h-full object-contain"
                                />
                              </div>

                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <div className="font-medium truncate">{post.product.name}</div>
                                    <div className="text-sm text-white/60">{post.product.platform}</div>
                                  </div>
                                  <div className="text-right">
                                    <div className="text-[#00FFFF] font-bold">${post.product.earnings}</div>
                                    <div className="text-xs text-white/60">earned</div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )}

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            className={`text-sm flex items-center gap-1.5 ${likedPosts.includes(post.id) ? "text-[#FF00FF]" : "text-white/60 hover:text-white"}`}
                            onClick={() => toggleLike(post.id)}
                          >
                            <Heart className={`h-4 w-4 ${likedPosts.includes(post.id) ? "fill-[#FF00FF]" : ""}`} />
                            {post.likes}
                          </Button>

                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-sm text-white/60 hover:text-white flex items-center gap-1.5"
                          >
                            <MessageCircle className="h-4 w-4" />
                            {post.comments}
                          </Button>

                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-sm text-white/60 hover:text-white flex items-center gap-1.5"
                          >
                            <Share2 className="h-4 w-4" />
                            {post.shares}
                          </Button>
                        </div>

                        {post.product && (
                          <Button
                            size="sm"
                            className="bg-gradient-to-r from-[#00FFFF] to-[#FF00FF] text-black font-medium"
                          >
                            <Zap className="mr-1.5 h-3.5 w-3.5" />
                            Get Link
                          </Button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="w-full lg:w-72 lg:flex-shrink-0">
            <div className="lg:sticky lg:top-24 space-y-6">
              <Card className="bg-[#111111] border-white/10">
                <CardContent className="p-4">
                  <h3 className="font-medium mb-4 flex items-center">
                    <TrendingUp className="mr-2 h-4 w-4 text-[#FFFF00]" />
                    Trending Creators
                  </h3>
                  <TrendingCreators />
                </CardContent>
              </Card>

              <Card className="bg-[#111111] border-white/10">
                <CardContent className="p-4">
                  <h3 className="font-medium mb-4 flex items-center">
                    <BarChart3 className="mr-2 h-4 w-4 text-[#00FFFF]" />
                    Top Categories
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-8 rounded-full bg-[#191919] flex items-center justify-center">
                          <span className="text-[#00FFFF]">💻</span>
                        </div>
                        <span>Tech</span>
                      </div>
                      <Badge className="bg-[#191919] text-white/80 border-none">+24% growth</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-8 rounded-full bg-[#191919] flex items-center justify-center">
                          <span className="text-[#FF00FF]">✨</span>
                        </div>
                        <span>Beauty</span>
                      </div>
                      <Badge className="bg-[#191919] text-white/80 border-none">+18% growth</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-8 rounded-full bg-[#191919] flex items-center justify-center">
                          <span className="text-[#FFFF00]">💪</span>
                        </div>
                        <span>Fitness</span>
                      </div>
                      <Badge className="bg-[#191919] text-white/80 border-none">+15% growth</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-[#FF00FF]/20 to-[#00FFFF]/20 border-white/10">
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2 flex items-center">
                    <Users className="mr-2 h-4 w-4 text-[#FFFF00]" />
                    Creator Challenges
                  </h3>
                  <p className="text-sm text-white/80 mb-4">Complete challenges to earn rewards</p>

                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">First $1,000 Earned</span>
                        <span className="text-xs text-white/60">$25 bonus</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1">
                          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-[#FF00FF] to-[#00FFFF]"
                              style={{ width: "65%" }}
                            ></div>
                          </div>
                        </div>
                        <span className="text-xs text-white/60">$650/$1,000</span>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">Share 5 Product Links</span>
                        <span className="text-xs text-white/60">Zero fee payout</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1">
                          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-[#FF00FF] to-[#00FFFF]"
                              style={{ width: "40%" }}
                            ></div>
                          </div>
                        </div>
                        <span className="text-xs text-white/60">2/5 links</span>
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">Reach Level 10</span>
                        <span className="text-xs text-white/60">Early access drops</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1">
                          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-[#FF00FF] to-[#00FFFF]"
                              style={{ width: "70%" }}
                            ></div>
                          </div>
                        </div>
                        <span className="text-xs text-white/60">Level 7/10</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

