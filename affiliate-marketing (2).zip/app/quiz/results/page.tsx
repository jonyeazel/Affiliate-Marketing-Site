"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import {
  ArrowRight,
  CheckCircle2,
  Download,
  Share2,
  Zap,
  Target,
  TrendingUp,
  BarChart3,
  Users,
  DollarSign,
  Sparkles,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import NewLogo from "@/components/new-logo"
import { cn } from "@/lib/utils"

// Mock data for the results
const mockResults = {
  role: "affiliate",
  experience: "intermediate",
  challenge: "scaling",
  platform: "social",
  firstName: "Alex",
  strengths: [
    { label: "Conversion Optimization", score: 85, icon: Target },
    { label: "Content Creation", score: 72, icon: Sparkles },
    { label: "Traffic Generation", score: 68, icon: Users },
    { label: "Analytics & Tracking", score: 55, icon: BarChart3 },
  ],
  recommendations: [
    {
      title: "Optimize Your Funnel",
      description: "Focus on improving your conversion rates by testing different landing pages and offers.",
      icon: Target,
      priority: "high",
    },
    {
      title: "Scale Your Winners",
      description: "Identify your top-performing campaigns and allocate more resources to scale them.",
      icon: TrendingUp,
      priority: "high",
    },
    {
      title: "Implement Better Tracking",
      description: "Set up more comprehensive tracking to identify which traffic sources convert best.",
      icon: BarChart3,
      priority: "medium",
    },
    {
      title: "Diversify Traffic Sources",
      description: "Expand beyond social media to reduce platform dependency and reach new audiences.",
      icon: Users,
      priority: "medium",
    },
  ],
  topOffers: [
    {
      name: "Premium SaaS Bundle",
      category: "Software",
      epc: "$2.45",
      commission: "40%",
      conversion: "3.8%",
    },
    {
      name: "Fitness Transformation",
      category: "Health",
      epc: "$1.87",
      commission: "75%",
      conversion: "2.5%",
    },
    {
      name: "Financial Masterclass",
      category: "Finance",
      epc: "$3.21",
      commission: "50%",
      conversion: "1.9%",
    },
  ],
  tools: [
    {
      name: "ClickTrackPro",
      category: "Analytics",
      description: "Advanced tracking solution for affiliate marketers",
    },
    {
      name: "ConversionBoost",
      category: "Optimization",
      description: "A/B testing and funnel optimization platform",
    },
    {
      name: "AffiliateMarketing.com Dashboard",
      category: "Management",
      description: "All-in-one platform for managing your affiliate business",
    },
  ],
}

export default function QuizResultsPage() {
  const [loading, setLoading] = useState(true)
  const [results, setResults] = useState<any>(null)

  useEffect(() => {
    // Simulate API call to get results
    const timer = setTimeout(() => {
      setResults(mockResults)
      setLoading(false)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-indigo-950 via-slate-950 to-slate-900 text-white flex flex-col items-center justify-center">
        <NewLogo size="xl" animated className="text-cyan-400" />
        <h2 className="text-2xl font-bold mt-8 mb-4 text-cyan-50">Analyzing Your Responses</h2>
        <div className="w-64 mb-8">
          <Progress value={75} className="h-2 bg-slate-800/80">
            <div className="h-full bg-gradient-to-r from-cyan-400 via-cyan-500 to-blue-500 rounded-full" />
          </Progress>
        </div>
        <p className="text-cyan-100/80 max-w-md text-center">
          We're creating your personalized affiliate marketing strategy based on your unique profile...
        </p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-950 via-slate-950 to-slate-900 text-white">
      <div className="container max-w-5xl mx-auto px-4 py-8 md:py-12">
        <div className="flex justify-center mb-6 md:mb-8">
          <NewLogo size="lg" animated className="text-cyan-400" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8 md:mb-12"
        >
          <div className="inline-flex items-center justify-center w-14 h-14 md:w-16 md:h-16 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 mb-4 shadow-lg shadow-cyan-900/20">
            <CheckCircle2 className="h-7 w-7 md:h-8 md:w-8" />
          </div>
          <h1 className="text-2xl md:text-4xl font-bold mb-2 md:mb-3 text-cyan-50">
            Your Personalized Affiliate Strategy
          </h1>
          <p className="text-lg md:text-xl text-cyan-100/80 max-w-2xl mx-auto">
            Hi {results.firstName}, we've analyzed your responses and created a custom roadmap to help you succeed.
          </p>
        </motion.div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-4 mx-auto mb-6 md:mb-8 bg-slate-900/60 border border-slate-700/50 rounded-xl overflow-hidden shadow-lg">
            <TabsTrigger
              value="overview"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-600 data-[state=active]:to-blue-600 data-[state=active]:text-white data-[state=active]:shadow-md text-slate-300 hover:text-white transition-all py-2 md:py-3"
            >
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="strategy"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-600 data-[state=active]:to-blue-600 data-[state=active]:text-white data-[state=active]:shadow-md text-slate-300 hover:text-white transition-all py-2 md:py-3"
            >
              Strategy
            </TabsTrigger>
            <TabsTrigger
              value="offers"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-600 data-[state=active]:to-blue-600 data-[state=active]:text-white data-[state=active]:shadow-md text-slate-300 hover:text-white transition-all py-2 md:py-3"
            >
              Offers
            </TabsTrigger>
            <TabsTrigger
              value="tools"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-600 data-[state=active]:to-blue-600 data-[state=active]:text-white data-[state=active]:shadow-md text-slate-300 hover:text-white transition-all py-2 md:py-3"
            >
              Tools
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
              <Card className="bg-slate-900/80 border-slate-700/50 col-span-1 md:col-span-2 shadow-xl hover:shadow-cyan-900/10 transition-all duration-300 backdrop-blur-sm">
                <CardHeader className="pb-4 md:pb-6">
                  <CardTitle className="text-cyan-50">Your Affiliate Profile</CardTitle>
                  <CardDescription className="text-cyan-100/60">
                    Based on your responses, here's your current affiliate marketing profile
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-5 md:space-y-6">
                    <div>
                      <h3 className="text-base md:text-lg font-medium mb-2 md:mb-3 text-cyan-50">Your Strengths</h3>
                      <div className="space-y-3 md:space-y-4">
                        {results.strengths.map((strength: any, index: number) => (
                          <div key={index}>
                            <div className="flex justify-between items-center mb-1">
                              <div className="flex items-center">
                                <strength.icon className="h-4 w-4 mr-2 text-cyan-400" />
                                <span className="text-cyan-100 text-sm md:text-base">{strength.label}</span>
                              </div>
                              <span className="text-xs md:text-sm font-medium text-cyan-100">{strength.score}%</span>
                            </div>
                            <Progress value={strength.score} className="h-1.5 md:h-2 bg-slate-800/80">
                              <div
                                className={cn(
                                  "h-full rounded-full",
                                  strength.score > 80
                                    ? "bg-gradient-to-r from-emerald-400 to-emerald-500"
                                    : strength.score > 60
                                      ? "bg-gradient-to-r from-cyan-400 to-cyan-500"
                                      : "bg-gradient-to-r from-amber-400 to-amber-500",
                                )}
                              />
                            </Progress>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-base md:text-lg font-medium mb-2 md:mb-3 text-cyan-50">Your Focus Areas</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
                        <div className="bg-slate-800/50 rounded-lg p-3 md:p-4 border border-slate-700/70">
                          <div className="flex items-center mb-1 md:mb-2">
                            <Target className="h-4 w-4 md:h-5 md:w-5 text-cyan-400 mr-2" />
                            <h4 className="font-medium text-sm md:text-base text-cyan-50">Primary Challenge</h4>
                          </div>
                          <p className="text-xs md:text-sm text-cyan-100/80">
                            Scaling profitably while maintaining ROI
                          </p>
                        </div>
                        <div className="bg-slate-800/50 rounded-lg p-3 md:p-4 border border-slate-700/70">
                          <div className="flex items-center mb-1 md:mb-2">
                            <Users className="h-4 w-4 md:h-5 md:w-5 text-cyan-400 mr-2" />
                            <h4 className="font-medium text-sm md:text-base text-cyan-50">Main Platform</h4>
                          </div>
                          <p className="text-xs md:text-sm text-cyan-100/80">
                            Social media marketing and content creation
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-900/80 border-slate-700/50 shadow-xl hover:shadow-cyan-900/10 transition-all duration-300 backdrop-blur-sm">
                <CardHeader className="pb-4 md:pb-6">
                  <CardTitle className="text-cyan-50">Next Steps</CardTitle>
                  <CardDescription className="text-cyan-100/60">Your immediate action items</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 md:space-y-4">
                    {results.recommendations.slice(0, 3).map((rec: any, index: number) => (
                      <div key={index} className="flex items-start gap-2 md:gap-3">
                        <div
                          className={cn(
                            "flex-shrink-0 w-7 h-7 md:w-8 md:h-8 rounded-full flex items-center justify-center",
                            rec.priority === "high"
                              ? "bg-gradient-to-r from-cyan-500 to-blue-600 shadow-md shadow-cyan-900/30"
                              : "bg-slate-800",
                          )}
                        >
                          <rec.icon className="h-3.5 w-3.5 md:h-4 md:w-4" />
                        </div>
                        <div>
                          <h4 className="font-medium text-sm md:text-base text-cyan-50">{rec.title}</h4>
                          <p className="text-xs md:text-sm text-cyan-100/60">{rec.description}</p>
                        </div>
                      </div>
                    ))}

                    <Button className="w-full mt-2 md:mt-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:opacity-90 hover:shadow-lg hover:shadow-cyan-900/20 transition-all duration-300 text-xs md:text-sm py-1.5 h-auto">
                      View Full Strategy
                      <ArrowRight className="ml-1 md:ml-2 h-3 w-3 md:h-4 md:w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="strategy">
            <Card className="bg-slate-900/80 border-slate-700/50 shadow-xl hover:shadow-cyan-900/10 transition-all duration-300 backdrop-blur-sm">
              <CardHeader className="pb-4 md:pb-6">
                <CardTitle className="text-cyan-50">Your 90-Day Growth Strategy</CardTitle>
                <CardDescription className="text-cyan-100/60">
                  A step-by-step plan to improve your affiliate marketing results
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6 md:space-y-8">
                  <div className="relative pl-6 md:pl-8 pb-6 md:pb-8 border-l-2 border-slate-700/70">
                    <div className="absolute left-[-4px] md:left-[-8px] top-0 w-3 h-3 md:w-4 md:h-4 rounded-full bg-gradient-to-r from-cyan-400 to-cyan-500 shadow-md shadow-cyan-900/30"></div>
                    <div className="mb-1 md:mb-2">
                      <h3 className="text-base md:text-lg font-semibold text-cyan-50">
                        Phase 1: Optimization (Days 1-30)
                      </h3>
                      <p className="text-xs md:text-sm text-cyan-100/60">Focus on improving what's already working</p>
                    </div>
                    <p className="text-xs md:text-sm text-cyan-100/80">
                      Start by analyzing your current campaigns to identify your top performers. Implement A/B testing
                      on your landing pages and creatives to increase conversion rates. Set up comprehensive tracking to
                      measure all key metrics.
                    </p>
                    <div className="mt-3 md:mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 md:gap-3">
                      <div className="bg-slate-800/40 p-2 md:p-3 rounded-lg border border-slate-700/50 flex items-start">
                        <Target className="h-3.5 w-3.5 md:h-4 md:w-4 text-cyan-400 mr-1.5 md:mr-2 mt-0.5" />
                        <span className="text-xs md:text-sm text-cyan-100/80">Optimize your top 3 campaigns</span>
                      </div>
                      <div className="bg-slate-800/40 p-2 md:p-3 rounded-lg border border-slate-700/50 flex items-start">
                        <BarChart3 className="h-3.5 w-3.5 md:h-4 md:w-4 text-cyan-400 mr-1.5 md:mr-2 mt-0.5" />
                        <span className="text-xs md:text-sm text-cyan-100/80">Implement proper tracking</span>
                      </div>
                    </div>
                  </div>

                  <div className="relative pl-6 md:pl-8 pb-6 md:pb-8 border-l-2 border-slate-700/70">
                    <div className="absolute left-[-4px] md:left-[-8px] top-0 w-3 h-3 md:w-4 md:h-4 rounded-full bg-gradient-to-r from-cyan-400/80 to-cyan-500/80 shadow-md shadow-cyan-900/20"></div>
                    <div className="mb-1 md:mb-2">
                      <h3 className="text-base md:text-lg font-semibold text-cyan-50">
                        Phase 2: Expansion (Days 31-60)
                      </h3>
                      <p className="text-xs md:text-sm text-cyan-100/60">Scale what works and test new opportunities</p>
                    </div>
                    <p className="text-xs md:text-sm text-cyan-100/80">
                      Once you've optimized your existing campaigns, it's time to scale them by increasing your budget
                      and expanding to new audiences. Simultaneously, begin testing new offers that align with your
                      audience's interests.
                    </p>
                    <div className="mt-3 md:mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 md:gap-3">
                      <div className="bg-slate-800/40 p-2 md:p-3 rounded-lg border border-slate-700/50 flex items-start">
                        <TrendingUp className="h-3.5 w-3.5 md:h-4 md:w-4 text-cyan-400 mr-1.5 md:mr-2 mt-0.5" />
                        <span className="text-xs md:text-sm text-cyan-100/80">Scale successful campaigns</span>
                      </div>
                      <div className="bg-slate-800/40 p-2 md:p-3 rounded-lg border border-slate-700/50 flex items-start">
                        <Sparkles className="h-3.5 w-3.5 md:h-4 md:w-4 text-cyan-400 mr-1.5 md:mr-2 mt-0.5" />
                        <span className="text-xs md:text-sm text-cyan-100/80">Test 3 new offer types</span>
                      </div>
                    </div>
                  </div>

                  <div className="relative pl-6 md:pl-8">
                    <div className="absolute left-[-4px] md:left-[-8px] top-0 w-3 h-3 md:w-4 md:h-4 rounded-full bg-gradient-to-r from-cyan-400/60 to-cyan-500/60 shadow-md shadow-cyan-900/10"></div>
                    <div className="mb-1 md:mb-2">
                      <h3 className="text-base md:text-lg font-semibold text-cyan-50">
                        Phase 3: Diversification (Days 61-90)
                      </h3>
                      <p className="text-xs md:text-sm text-cyan-100/60">Reduce risk and maximize opportunities</p>
                    </div>
                    <p className="text-xs md:text-sm text-cyan-100/80">
                      In the final phase, focus on diversifying your traffic sources and offer portfolio to reduce
                      dependency on any single platform or product. Begin building systems that will allow you to scale
                      further in the future.
                    </p>
                    <div className="mt-3 md:mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 md:gap-3">
                      <div className="bg-slate-800/40 p-2 md:p-3 rounded-lg border border-slate-700/50 flex items-start">
                        <Users className="h-3.5 w-3.5 md:h-4 md:w-4 text-cyan-400 mr-1.5 md:mr-2 mt-0.5" />
                        <span className="text-xs md:text-sm text-cyan-100/80">Add 2 new traffic sources</span>
                      </div>
                      <div className="bg-slate-800/40 p-2 md:p-3 rounded-lg border border-slate-700/50 flex items-start">
                        <Zap className="h-3.5 w-3.5 md:h-4 md:w-4 text-cyan-400 mr-1.5 md:mr-2 mt-0.5" />
                        <span className="text-xs md:text-sm text-cyan-100/80">Build automation systems</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col sm:flex-row gap-3 md:gap-4 pt-4 md:pt-6 border-t border-slate-700/50">
                <Button className="w-full sm:w-auto bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:opacity-90 hover:shadow-lg hover:shadow-cyan-900/20 transition-all duration-300 text-xs md:text-sm py-1.5 h-auto">
                  <Download className="mr-1.5 md:mr-2 h-3.5 w-3.5 md:h-4 md:w-4" />
                  Download Full Strategy
                </Button>
                <Button
                  variant="outline"
                  className="w-full sm:w-auto border-slate-700/70 text-cyan-100 hover:bg-slate-800 hover:text-cyan-50 text-xs md:text-sm py-1.5 h-auto"
                >
                  <Share2 className="mr-1.5 md:mr-2 h-3.5 w-3.5 md:h-4 md:w-4" />
                  Share Strategy
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="offers">
            <Card className="bg-slate-900/80 border-slate-700/50 shadow-xl hover:shadow-cyan-900/10 transition-all duration-300 backdrop-blur-sm">
              <CardHeader className="pb-4 md:pb-6">
                <CardTitle className="text-cyan-50">Recommended High-EPC Offers</CardTitle>
                <CardDescription className="text-cyan-100/60">
                  Based on your profile, these offers are likely to perform well for you
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto -mx-4 px-4">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-slate-700/70">
                        <th className="text-left py-2 md:py-3 px-2 md:px-4 text-xs md:text-sm text-cyan-50">
                          Offer Name
                        </th>
                        <th className="text-left py-2 md:py-3 px-2 md:px-4 text-xs md:text-sm text-cyan-50">
                          Category
                        </th>
                        <th className="text-left py-2 md:py-3 px-2 md:px-4 text-xs md:text-sm text-cyan-50">EPC</th>
                        <th className="text-left py-2 md:py-3 px-2 md:px-4 text-xs md:text-sm text-cyan-50">
                          Commission
                        </th>
                        <th className="text-left py-2 md:py-3 px-2 md:px-4 text-xs md:text-sm text-cyan-50">
                          Conv. Rate
                        </th>
                        <th className="text-left py-2 md:py-3 px-2 md:px-4 text-xs md:text-sm text-cyan-50">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.topOffers.map((offer: any, index: number) => (
                        <tr key={index} className="border-b border-slate-700/50 hover:bg-slate-800/30">
                          <td className="py-2 md:py-3 px-2 md:px-4 font-medium text-xs md:text-sm text-cyan-50">
                            {offer.name}
                          </td>
                          <td className="py-2 md:py-3 px-2 md:px-4 text-xs md:text-sm text-cyan-100/80">
                            {offer.category}
                          </td>
                          <td className="py-2 md:py-3 px-2 md:px-4 text-xs md:text-sm text-cyan-400 font-medium">
                            {offer.epc}
                          </td>
                          <td className="py-2 md:py-3 px-2 md:px-4 text-xs md:text-sm text-cyan-100/80">
                            {offer.commission}
                          </td>
                          <td className="py-2 md:py-3 px-2 md:px-4 text-xs md:text-sm text-cyan-100/80">
                            {offer.conversion}
                          </td>
                          <td className="py-2 md:py-3 px-2 md:px-4">
                            <Button
                              size="sm"
                              className="bg-gradient-to-r from-cyan-400 to-blue-500 text-white hover:opacity-90 hover:shadow-lg hover:shadow-cyan-900/20 transition-all duration-300 text-xs py-1 h-auto"
                            >
                              Get Link
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="mt-6 md:mt-8 bg-slate-800/40 p-3 md:p-4 rounded-lg border border-slate-700/50">
                  <div className="flex items-start">
                    <Zap className="h-4 w-4 md:h-5 md:w-5 text-cyan-400 mr-2 md:mr-3 mt-0.5" />
                    <div>
                      <h3 className="font-medium mb-1 text-sm md:text-base text-cyan-50">Premium Offer Access</h3>
                      <p className="text-xs md:text-sm text-cyan-100/80 mb-3">
                        Unlock access to our exclusive high-EPC offers that aren't available on other networks. These
                        offers have been thoroughly tested and proven to convert.
                      </p>
                      <Button className="bg-gradient-to-r from-cyan-400 to-blue-500 text-white hover:opacity-90 hover:shadow-lg hover:shadow-cyan-900/20 transition-all duration-300 text-xs md:text-sm py-1.5 h-auto">
                        Unlock Premium Offers
                        <ArrowRight className="ml-1.5 md:ml-2 h-3 w-3 md:h-4 md:w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tools">
            <Card className="bg-slate-900/80 border-slate-700/50 shadow-xl hover:shadow-cyan-900/10 transition-all duration-300 backdrop-blur-sm">
              <CardHeader className="pb-4 md:pb-6">
                <CardTitle className="text-cyan-50">Recommended Tools & Resources</CardTitle>
                <CardDescription className="text-cyan-100/60">
                  These tools will help you implement your strategy more effectively
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
                  {results.tools.map((tool: any, index: number) => (
                    <div key={index} className="bg-slate-800/40 rounded-lg border border-slate-700/50 overflow-hidden">
                      <div className="h-24 md:h-32 bg-gradient-to-r from-slate-800/90 to-slate-800/70 flex items-center justify-center">
                        <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-900/20">
                          {index === 0 ? (
                            <BarChart3 className="h-6 w-6 md:h-8 md:w-8" />
                          ) : index === 1 ? (
                            <Target className="h-6 w-6 md:h-8 md:w-8" />
                          ) : (
                            <DollarSign className="h-6 w-6 md:h-8 md:w-8" />
                          )}
                        </div>
                      </div>
                      <div className="p-3 md:p-4">
                        <h3 className="font-medium mb-1 text-sm md:text-base text-cyan-50">{tool.name}</h3>
                        <p className="text-xs md:text-sm text-cyan-100/60 mb-2 md:mb-3">{tool.category}</p>
                        <p className="text-xs md:text-sm text-cyan-100/80 mb-3 md:mb-4">{tool.description}</p>
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full border-slate-700/70 text-cyan-100 hover:bg-slate-800 hover:text-cyan-50 text-xs py-1 h-auto"
                        >
                          Learn More
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 md:mt-8 text-center">
                  <h3 className="text-lg md:text-xl font-bold mb-2 md:mb-3 text-cyan-50">
                    Ready to Implement Your Strategy?
                  </h3>
                  <p className="text-xs md:text-sm text-cyan-100/80 mb-4 md:mb-6 max-w-2xl mx-auto">
                    Get access to our full platform with advanced tools, analytics, and support to execute your
                    strategy.
                  </p>
                  <div className="flex flex-col sm:flex-row justify-center gap-3 md:gap-4">
                    <Button
                      size="lg"
                      className="bg-gradient-to-r from-cyan-400 to-blue-500 text-white hover:opacity-90 hover:shadow-lg hover:shadow-cyan-900/20 transition-all duration-300 text-xs md:text-sm py-2 h-auto"
                    >
                      Join AffiliateMarketing.com
                    </Button>
                    <Button
                      size="lg"
                      variant="outline"
                      className="border-slate-700/70 text-cyan-100 hover:bg-slate-800 hover:text-cyan-50 text-xs md:text-sm py-2 h-auto"
                    >
                      Schedule a Demo
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-6 md:mt-12 text-center">
          <Link href="/" className="text-cyan-100/60 hover:text-cyan-50 transition-colors text-xs md:text-sm">
            Return to Homepage
          </Link>
        </div>
      </div>
    </div>
  )
}

