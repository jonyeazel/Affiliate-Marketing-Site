import { NextResponse } from "next/server"

export async function GET(request: Request) {
  // In a real application, this would fetch the user's earnings data from a database

  // Simulate processing time
  await new Promise((resolve) => setTimeout(resolve, 300))

  // Sample data
  const earnings = {
    summary: {
      available: 1245.78,
      pending: 532.45,
      total: 1778.23,
      lastPayout: {
        amount: 876.5,
        date: "2025-02-28T14:30:00Z",
        method: "Bank Transfer",
      },
    },
    recentTransactions: [
      {
        id: "txn_1",
        type: "commission",
        amount: 45.32,
        program: "TechGadgets Pro",
        product: "Wireless Headphones",
        status: "available",
        date: "2025-03-15T10:30:00Z",
      },
      {
        id: "txn_2",
        type: "commission",
        amount: 120.0,
        program: "FitnessPro",
        product: "Home Workout Program",
        status: "available",
        date: "2025-03-14T15:45:00Z",
      },
      {
        id: "txn_3",
        type: "commission",
        amount: 64.8,
        program: "HomeEssentials",
        product: "Smart Kitchen Appliances",
        status: "available",
        date: "2025-03-12T09:15:00Z",
      },
      {
        id: "txn_4",
        type: "commission",
        amount: 89.75,
        program: "TechGadgets Pro",
        product: "Smartphone Accessories",
        status: "pending",
        date: "2025-03-16T11:20:00Z",
      },
      {
        id: "txn_5",
        type: "payout",
        amount: -876.5,
        method: "Bank Transfer",
        status: "completed",
        date: "2025-02-28T14:30:00Z",
      },
    ],
    monthlyEarnings: [
      { month: "Jan", earnings: 1245.32 },
      { month: "Feb", earnings: 1532.87 },
      { month: "Mar", earnings: 1778.23 },
    ],
    programBreakdown: [
      { program: "TechGadgets Pro", earnings: 845.32, percentage: 47.5 },
      { program: "FitnessPro", earnings: 632.45, percentage: 35.6 },
      { program: "HomeEssentials", earnings: 201.7, percentage: 11.3 },
      { program: "Other Programs", earnings: 98.76, percentage: 5.6 },
    ],
  }

  return NextResponse.json({ success: true, earnings })
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { amount, method } = body

    // In a real application, this would:
    // 1. Validate the payout request
    // 2. Process the payout
    // 3. Update the user's balance
    // 4. Return the transaction details

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Calculate fee (1% with min $0.50, max $10)
    const fee = Math.min(10, Math.max(0.5, amount * 0.01))
    const netAmount = amount - fee

    return NextResponse.json({
      success: true,
      transaction: {
        id: `txn_${Date.now()}`,
        type: "payout",
        amount: -amount,
        fee: fee,
        netAmount: -netAmount,
        method: method,
        status: "processing",
        date: new Date().toISOString(),
        estimatedArrival: "1-3 hours",
      },
    })
  } catch (error) {
    console.error("Error processing payout:", error)
    return NextResponse.json({ success: false, error: "Failed to process payout" }, { status: 500 })
  }
}

