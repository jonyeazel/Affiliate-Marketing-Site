import Link from "next/link"
import {
  Search,
  Filter,
  Star,
  ArrowRight,
  ChevronDown,
  Check,
  Zap,
  DollarSign,
  Users,
  Globe,
  ShoppingCart,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"

export default function MarketplacePage() {
  const featuredPrograms = [
    {
      id: 1,
      name: "TechGadgets Pro",
      logo: "/placeholder.svg?height=80&width=80",
      category: "Electronics & Technology",
      commission: "Up to 15%",
      cookieDuration: "45 days",
      rating: 4.8,
      reviews: 245,
      description: "Premium electronics and gadgets with high conversion rates and excellent customer support.",
      featured: true,
    },
    {
      id: 2,
      name: "FitnessPro",
      logo: "/placeholder.svg?height=80&width=80",
      category: "Health & Wellness",
      commission: "12-20%",
      cookieDuration: "60 days",
      rating: 4.7,
      reviews: 189,
      description: "Leading fitness equipment, supplements, and digital products with competitive commissions.",
      featured: true,
    },
    {
      id: 3,
      name: "StyleHub",
      logo: "/placeholder.svg?height=80&width=80",
      category: "Fashion & Accessories",
      commission: "10-15%",
      cookieDuration: "30 days",
      rating: 4.5,
      reviews: 156,
      description: "Trendy fashion brands and accessories with frequent promotions and bonus incentives.",
      featured: true,
    },
  ]

  const programs = [
    {
      id: 4,
      name: "HomeEssentials",
      logo: "/placeholder.svg?height=80&width=80",
      category: "Home & Lifestyle",
      commission: "8-12%",
      cookieDuration: "30 days",
      rating: 4.3,
      reviews: 124,
      description: "Quality home goods, furniture, and decor with reliable shipping and customer service.",
    },
    {
      id: 5,
      name: "TravelEscape",
      logo: "/placeholder.svg?height=80&width=80",
      category: "Travel & Leisure",
      commission: "Up to 8%",
      cookieDuration: "90 days",
      rating: 4.6,
      reviews: 178,
      description: "Hotels, flights, and vacation packages with extended cookie duration and competitive rates.",
    },
    {
      id: 6,
      name: "BeautyEssentials",
      logo: "/placeholder.svg?height=80&width=80",
      category: "Beauty & Skincare",
      commission: "15-25%",
      cookieDuration: "45 days",
      rating: 4.4,
      reviews: 132,
      description: "Premium skincare, makeup, and beauty products with high average order value.",
    },
    {
      id: 7,
      name: "DigitalTools Pro",
      logo: "/placeholder.svg?height=80&width=80",
      category: "Software & Digital Products",
      commission: "20-40%",
      cookieDuration: "120 days",
      rating: 4.9,
      reviews: 210,
      description: "SaaS products, digital tools, and online courses with recurring commissions available.",
    },
    {
      id: 8,
      name: "PetSupplies Plus",
      logo: "/placeholder.svg?height=80&width=80",
      category: "Pets & Animals",
      commission: "10-15%",
      cookieDuration: "30 days",
      rating: 4.2,
      reviews: 98,
      description: "Pet food, supplies, and accessories with loyal customer base and repeat purchases.",
    },
    {
      id: 9,
      name: "GourmetKitchen",
      logo: "/placeholder.svg?height=80&width=80",
      category: "Food & Cooking",
      commission: "8-12%",
      cookieDuration: "30 days",
      rating: 4.5,
      reviews: 145,
      description: "Gourmet food products, kitchen tools, and meal kits with strong conversion rates.",
    },
  ]

  const categories = [
    "Electronics & Technology",
    "Health & Wellness",
    "Fashion & Accessories",
    "Home & Lifestyle",
    "Travel & Leisure",
    "Beauty & Skincare",
    "Software & Digital Products",
    "Pets & Animals",
    "Food & Cooking",
    "Finance & Investing",
    "Education & Courses",
  ]

  return (
    <div className="bg-background">
      <div className="container py-12 md:py-24">
        <div className="mx-auto max-w-3xl text-center mb-16">
          <Badge className="mb-4" variant="secondary">
            Marketplace
          </Badge>
          <h1 className="mb-4 text-3xl font-bold sm:text-4xl md:text-5xl">Find the Perfect Affiliate Programs</h1>
          <p className="text-muted-foreground md:text-xl">
            Browse thousands of affiliate programs across all niches to find the best fit for your audience.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-12">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search programs by name, category, or keyword..." className="pl-10" />
            </div>
            <Button variant="outline" className="md:w-auto">
              <Filter className="mr-2 h-4 w-4" />
              Advanced Filters
            </Button>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
              <TabsList>
                <TabsTrigger value="all">All Programs</TabsTrigger>
                <TabsTrigger value="featured">Featured</TabsTrigger>
                <TabsTrigger value="new">New</TabsTrigger>
                <TabsTrigger value="trending">Trending</TabsTrigger>
              </TabsList>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Sort by:</span>
                <Select defaultValue="recommended">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recommended">Recommended</SelectItem>
                    <SelectItem value="commission-high">Highest Commission</SelectItem>
                    <SelectItem value="commission-low">Lowest Commission</SelectItem>
                    <SelectItem value="rating-high">Highest Rating</SelectItem>
                    <SelectItem value="cookie-duration">Cookie Duration</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {/* Filters Sidebar */}
                <div className="hidden md:block">
                  <Card>
                    <CardHeader>
                      <CardTitle>Filters</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Category Filter */}
                      <div>
                        <h3 className="font-medium mb-3">Categories</h3>
                        <div className="space-y-2">
                          {categories.slice(0, 6).map((category) => (
                            <div key={category} className="flex items-center space-x-2">
                              <Checkbox id={`category-${category}`} />
                              <label
                                htmlFor={`category-${category}`}
                                className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                {category}
                              </label>
                            </div>
                          ))}
                          <Button variant="link" className="p-0 h-auto text-sm">
                            Show more
                            <ChevronDown className="ml-1 h-3 w-3" />
                          </Button>
                        </div>
                      </div>

                      {/* Commission Rate Filter */}
                      <div>
                        <h3 className="font-medium mb-3">Commission Rate</h3>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox id="commission-low" />
                            <label
                              htmlFor="commission-low"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              Under 10%
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="commission-medium" />
                            <label
                              htmlFor="commission-medium"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              10-20%
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="commission-high" />
                            <label
                              htmlFor="commission-high"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              20-30%
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="commission-very-high" />
                            <label
                              htmlFor="commission-very-high"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              30%+
                            </label>
                          </div>
                        </div>
                      </div>

                      {/* Cookie Duration Filter */}
                      <div>
                        <h3 className="font-medium mb-3">Cookie Duration</h3>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox id="cookie-30" />
                            <label
                              htmlFor="cookie-30"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              30 days or less
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="cookie-60" />
                            <label
                              htmlFor="cookie-60"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              31-60 days
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="cookie-90" />
                            <label
                              htmlFor="cookie-90"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              61-90 days
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="cookie-90-plus" />
                            <label
                              htmlFor="cookie-90-plus"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              90+ days
                            </label>
                          </div>
                        </div>
                      </div>

                      {/* Rating Filter */}
                      <div>
                        <h3 className="font-medium mb-3">Minimum Rating</h3>
                        <div className="space-y-6">
                          <Slider defaultValue={[4]} max={5} step={0.1} />
                          <div className="flex items-center justify-between">
                            <span className="text-sm">3.0</span>
                            <span className="text-sm">4.0</span>
                            <span className="text-sm">5.0</span>
                          </div>
                        </div>
                      </div>

                      <Button className="w-full">Apply Filters</Button>
                    </CardContent>
                  </Card>
                </div>

                {/* Programs List */}
                <div className="md:col-span-3 space-y-8">
                  {/* Featured Programs */}
                  <div className="space-y-4">
                    <h2 className="text-2xl font-bold">Featured Programs</h2>
                    <div className="grid gap-4">
                      {featuredPrograms.map((program) => (
                        <Card key={program.id} className="overflow-hidden">
                          <div className="flex flex-col md:flex-row">
                            <div className="p-6 flex items-center justify-center md:border-r md:w-48">
                              <div className="w-20 h-20 flex items-center justify-center bg-muted rounded-lg">
                                <img
                                  src={program.logo || "/placeholder.svg"}
                                  alt={program.name}
                                  className="max-w-full max-h-full"
                                />
                              </div>
                            </div>
                            <div className="flex-1 p-6">
                              <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                                <div>
                                  <div className="flex items-center gap-2 mb-1">
                                    <h3 className="font-bold text-xl">{program.name}</h3>
                                    {program.featured && (
                                      <Badge variant="secondary" className="bg-primary/10 text-primary">
                                        <Zap className="mr-1 h-3 w-3" />
                                        Featured
                                      </Badge>
                                    )}
                                  </div>
                                  <p className="text-sm text-muted-foreground">{program.category}</p>
                                </div>
                                <div className="flex items-center mt-2 md:mt-0">
                                  <div className="flex items-center">
                                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                    <span className="ml-1 font-medium">{program.rating}</span>
                                  </div>
                                  <span className="mx-2 text-muted-foreground">•</span>
                                  <span className="text-sm text-muted-foreground">{program.reviews} reviews</span>
                                </div>
                              </div>
                              <p className="mb-4">{program.description}</p>
                              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                                <div className="flex items-center">
                                  <DollarSign className="h-4 w-4 text-muted-foreground mr-2" />
                                  <div>
                                    <div className="text-sm font-medium">Commission</div>
                                    <div className="text-sm text-muted-foreground">{program.commission}</div>
                                  </div>
                                </div>
                                <div className="flex items-center">
                                  <Globe className="h-4 w-4 text-muted-foreground mr-2" />
                                  <div>
                                    <div className="text-sm font-medium">Cookie Duration</div>
                                    <div className="text-sm text-muted-foreground">{program.cookieDuration}</div>
                                  </div>
                                </div>
                                <div className="flex items-center">
                                  <ShoppingCart className="h-4 w-4 text-muted-foreground mr-2" />
                                  <div>
                                    <div className="text-sm font-medium">Products</div>
                                    <div className="text-sm text-muted-foreground">1,200+</div>
                                  </div>
                                </div>
                              </div>
                              <div className="flex flex-col sm:flex-row gap-3">
                                <Button asChild>
                                  <Link href={`/marketplace/${program.id}`}>
                                    View Program
                                    <ArrowRight className="ml-2 h-4 w-4" />
                                  </Link>
                                </Button>
                                <Button variant="outline">Apply Now</Button>
                              </div>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>

                  {/* All Programs */}
                  <div className="space-y-4">
                    <h2 className="text-2xl font-bold">All Programs</h2>
                    <div className="grid gap-4">
                      {programs.map((program) => (
                        <Card key={program.id}>
                          <div className="p-6">
                            <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-4">
                              <div className="w-16 h-16 flex items-center justify-center bg-muted rounded-lg">
                                <img
                                  src={program.logo || "/placeholder.svg"}
                                  alt={program.name}
                                  className="max-w-full max-h-full"
                                />
                              </div>
                              <div className="flex-1">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                                  <div>
                                    <h3 className="font-bold text-lg">{program.name}</h3>
                                    <p className="text-sm text-muted-foreground">{program.category}</p>
                                  </div>
                                  <div className="flex items-center mt-2 sm:mt-0">
                                    <div className="flex items-center">
                                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                                      <span className="ml-1 font-medium">{program.rating}</span>
                                    </div>
                                    <span className="mx-2 text-muted-foreground">•</span>
                                    <span className="text-sm text-muted-foreground">{program.reviews} reviews</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <p className="mb-4">{program.description}</p>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                              <div className="flex items-center">
                                <DollarSign className="h-4 w-4 text-muted-foreground mr-2" />
                                <div>
                                  <div className="text-sm font-medium">Commission</div>
                                  <div className="text-sm text-muted-foreground">{program.commission}</div>
                                </div>
                              </div>
                              <div className="flex items-center">
                                <Globe className="h-4 w-4 text-muted-foreground mr-2" />
                                <div>
                                  <div className="text-sm font-medium">Cookie Duration</div>
                                  <div className="text-sm text-muted-foreground">{program.cookieDuration}</div>
                                </div>
                              </div>
                              <div className="flex items-center">
                                <Users className="h-4 w-4 text-muted-foreground mr-2" />
                                <div>
                                  <div className="text-sm font-medium">Affiliates</div>
                                  <div className="text-sm text-muted-foreground">500+</div>
                                </div>
                              </div>
                            </div>
                            <div className="flex flex-col sm:flex-row gap-3">
                              <Button variant="outline" asChild>
                                <Link href={`/marketplace/${program.id}`}>
                                  View Program
                                  <ArrowRight className="ml-2 h-4 w-4" />
                                </Link>
                              </Button>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>

                  {/* Pagination */}
                  <div className="flex items-center justify-center space-x-2">
                    <Button variant="outline" size="icon" disabled>
                      <ChevronDown className="h-4 w-4 rotate-90" />
                    </Button>
                    <Button variant="outline" size="sm" className="h-8 w-8">
                      1
                    </Button>
                    <Button variant="outline" size="sm" className="h-8 w-8">
                      2
                    </Button>
                    <Button variant="outline" size="sm" className="h-8 w-8">
                      3
                    </Button>
                    <span>...</span>
                    <Button variant="outline" size="sm" className="h-8 w-8">
                      12
                    </Button>
                    <Button variant="outline" size="icon">
                      <ChevronDown className="h-4 w-4 -rotate-90" />
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Join as a Brand CTA */}
        <div className="mt-16">
          <Card className="bg-primary text-primary-foreground">
            <div className="grid md:grid-cols-2 gap-6">
              <CardContent className="pt-6 md:pt-10">
                <div className="space-y-4">
                  <h2 className="text-2xl font-bold">Are You a Brand or Business?</h2>
                  <p className="text-primary-foreground/80">
                    List your affiliate program in our marketplace and connect with thousands of qualified affiliates
                    and content creators.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>Reach thousands of active affiliates</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>AI-powered affiliate matching</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>Comprehensive program management tools</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>Detailed performance analytics</span>
                    </li>
                  </ul>
                  <Button className="bg-background text-foreground hover:bg-background/90">
                    List Your Program
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
              <div className="hidden md:flex items-center justify-center p-6">
                <div className="w-full max-w-sm h-64 bg-primary-foreground/10 rounded-lg flex items-center justify-center">
                  <Users className="h-24 w-24 text-primary-foreground/30" />
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}

