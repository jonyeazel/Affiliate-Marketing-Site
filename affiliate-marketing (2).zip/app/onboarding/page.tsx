"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowRight, Check, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function OnboardingPage() {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    role: "",
    experience: "",
    goals: [],
    website: "",
    niche: "",
    bio: "",
  })

  const totalSteps = 4
  const progress = (step / totalSteps) * 100

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1)
      window.scrollTo(0, 0)
    } else {
      // Submit and redirect
      window.location.href = "/dashboard"
    }
  }

  const handlePrevious = () => {
    if (step > 1) {
      setStep(step - 1)
      window.scrollTo(0, 0)
    }
  }

  const handleInputChange = (field, value) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleGoalToggle = (goal) => {
    const currentGoals = [...formData.goals]
    if (currentGoals.includes(goal)) {
      setFormData({
        ...formData,
        goals: currentGoals.filter((g) => g !== goal),
      })
    } else {
      setFormData({
        ...formData,
        goals: [...currentGoals, goal],
      })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      <div className="container max-w-3xl py-12">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-6">
            <ChevronRight className="mr-2 h-4 w-4 rotate-180" />
            Back to home
          </Link>
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-2xl font-bold md:text-3xl">Set Up Your Account</h1>
            <span className="text-sm font-medium text-muted-foreground">
              Step {step} of {totalSteps}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <Card className="border-none shadow-lg">
          <CardContent className="pt-6">
            {step === 1 && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Tell us about yourself</h2>
                <p className="text-muted-foreground">This helps us personalize your experience.</p>

                <div className="space-y-4 pt-4">
                  <div>
                    <h3 className="font-medium mb-3">What best describes your role?</h3>
                    <RadioGroup
                      value={formData.role}
                      onValueChange={(value) => handleInputChange("role", value)}
                      className="grid gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="affiliate" id="affiliate" className="peer sr-only" />
                        <Label
                          htmlFor="affiliate"
                          className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
                        >
                          <div className="flex flex-col gap-1">
                            <span className="font-medium">Affiliate Marketer</span>
                            <span className="text-sm text-muted-foreground">
                              I promote products and earn commissions
                            </span>
                          </div>
                          <Check className="h-5 w-5 text-primary opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="creator" id="creator" className="peer sr-only" />
                        <Label
                          htmlFor="creator"
                          className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
                        >
                          <div className="flex flex-col gap-1">
                            <span className="font-medium">Content Creator</span>
                            <span className="text-sm text-muted-foreground">
                              I create content and want to monetize it
                            </span>
                          </div>
                          <Check className="h-5 w-5 text-primary opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="brand" id="brand" className="peer sr-only" />
                        <Label
                          htmlFor="brand"
                          className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
                        >
                          <div className="flex flex-col gap-1">
                            <span className="font-medium">Brand or Business</span>
                            <span className="text-sm text-muted-foreground">
                              I want to start or improve an affiliate program
                            </span>
                          </div>
                          <Check className="h-5 w-5 text-primary opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="agency" id="agency" className="peer sr-only" />
                        <Label
                          htmlFor="agency"
                          className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
                        >
                          <div className="flex flex-col gap-1">
                            <span className="font-medium">Agency or Consultant</span>
                            <span className="text-sm text-muted-foreground">
                              I manage affiliate programs for clients
                            </span>
                          </div>
                          <Check className="h-5 w-5 text-primary opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div>
                    <h3 className="font-medium mb-3">What's your experience level with affiliate marketing?</h3>
                    <RadioGroup
                      value={formData.experience}
                      onValueChange={(value) => handleInputChange("experience", value)}
                      className="grid gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="beginner" id="beginner" className="peer sr-only" />
                        <Label
                          htmlFor="beginner"
                          className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
                        >
                          <span className="font-medium">Beginner (0-1 years)</span>
                          <Check className="h-5 w-5 text-primary opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="intermediate" id="intermediate" className="peer sr-only" />
                        <Label
                          htmlFor="intermediate"
                          className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
                        >
                          <span className="font-medium">Intermediate (1-3 years)</span>
                          <Check className="h-5 w-5 text-primary opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="advanced" id="advanced" className="peer sr-only" />
                        <Label
                          htmlFor="advanced"
                          className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
                        >
                          <span className="font-medium">Advanced (3-5 years)</span>
                          <Check className="h-5 w-5 text-primary opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="expert" id="expert" className="peer sr-only" />
                        <Label
                          htmlFor="expert"
                          className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
                        >
                          <span className="font-medium">Expert (5+ years)</span>
                          <Check className="h-5 w-5 text-primary opacity-0 peer-data-[state=checked]:opacity-100" />
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Your goals and objectives</h2>
                <p className="text-muted-foreground">Select all that apply to you.</p>

                <div className="space-y-4 pt-4">
                  <div className="grid gap-4">
                    {[
                      { id: "increase-revenue", label: "Increase affiliate revenue" },
                      { id: "find-programs", label: "Find new affiliate programs" },
                      { id: "improve-conversion", label: "Improve conversion rates" },
                      { id: "grow-audience", label: "Grow my audience" },
                      { id: "create-program", label: "Create/improve my affiliate program" },
                      { id: "recruit-affiliates", label: "Recruit quality affiliates" },
                      { id: "learn-strategies", label: "Learn new strategies and tactics" },
                      { id: "network", label: "Network with other affiliates" },
                    ].map((goal) => (
                      <div key={goal.id} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={goal.id}
                          checked={formData.goals.includes(goal.id)}
                          onChange={() => handleGoalToggle(goal.id)}
                          className="peer sr-only"
                        />
                        <Label
                          htmlFor={goal.id}
                          className="flex flex-1 cursor-pointer items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-checked:border-primary"
                        >
                          <span className="font-medium">{goal.label}</span>
                          <Check
                            className={`h-5 w-5 text-primary ${formData.goals.includes(goal.id) ? "opacity-100" : "opacity-0"}`}
                          />
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Your profile information</h2>
                <p className="text-muted-foreground">Tell us more about your business or content.</p>

                <div className="space-y-6 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="website">Website or Blog URL</Label>
                    <Input
                      id="website"
                      placeholder="https://yourwebsite.com"
                      value={formData.website}
                      onChange={(e) => handleInputChange("website", e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Optional - Enter your main website or content platform
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="niche">Primary Niche or Industry</Label>
                    <Input
                      id="niche"
                      placeholder="e.g., Technology, Health & Wellness, Finance"
                      value={formData.niche}
                      onChange={(e) => handleInputChange("niche", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio or Description</Label>
                    <Textarea
                      id="bio"
                      placeholder="Tell us a bit about yourself or your business"
                      value={formData.bio}
                      onChange={(e) => handleInputChange("bio", e.target.value)}
                      className="min-h-[120px]"
                    />
                    <p className="text-xs text-muted-foreground">This will be visible on your public profile</p>
                  </div>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">You're all set!</h2>
                <p className="text-muted-foreground">Review your information and complete your account setup.</p>

                <div className="space-y-6 pt-4">
                  <Card className="bg-muted/50">
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <h3 className="text-sm font-medium text-muted-foreground">Role</h3>
                          <p className="font-medium">
                            {formData.role
                              ? formData.role.charAt(0).toUpperCase() + formData.role.slice(1)
                              : "Not specified"}
                          </p>
                        </div>

                        <div>
                          <h3 className="text-sm font-medium text-muted-foreground">Experience Level</h3>
                          <p className="font-medium">
                            {formData.experience
                              ? formData.experience.charAt(0).toUpperCase() + formData.experience.slice(1)
                              : "Not specified"}
                          </p>
                        </div>

                        <div>
                          <h3 className="text-sm font-medium text-muted-foreground">Goals</h3>
                          {formData.goals.length > 0 ? (
                            <ul className="list-disc pl-5">
                              {formData.goals.map((goal) => (
                                <li key={goal}>
                                  {goal
                                    .split("-")
                                    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                                    .join(" ")}
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <p className="font-medium">No goals specified</p>
                          )}
                        </div>

                        {formData.website && (
                          <div>
                            <h3 className="text-sm font-medium text-muted-foreground">Website</h3>
                            <p className="font-medium">{formData.website}</p>
                          </div>
                        )}

                        {formData.niche && (
                          <div>
                            <h3 className="text-sm font-medium text-muted-foreground">Niche/Industry</h3>
                            <p className="font-medium">{formData.niche}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <div className="rounded-md bg-primary/10 p-4">
                    <h4 className="font-medium text-primary mb-2">What's Next?</h4>
                    <p className="text-sm">
                      Based on your profile, we'll customize your dashboard with relevant tools, resources, and
                      affiliate program recommendations to help you achieve your goals.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="mt-8 flex justify-between">
          <Button variant="outline" onClick={handlePrevious} disabled={step === 1}>
            Previous
          </Button>
          <Button
            onClick={handleNext}
            disabled={
              (step === 1 && (!formData.role || !formData.experience)) || (step === 2 && formData.goals.length === 0)
            }
          >
            {step === totalSteps ? "Complete Setup" : "Continue"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

