import Link from "next/link"
import {
  MessageSquare,
  Users,
  Lightbulb,
  ArrowRight,
  Calendar,
  Clock,
  Heart,
  MessageCircle,
  Bookmark,
  TrendingUp,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function CommunityPage() {
  const featuredDiscussions = [
    {
      id: 1,
      title: "What's working in affiliate marketing in 2025?",
      excerpt:
        "I'd love to hear what strategies and niches are performing well for everyone this year. I've seen some interesting shifts in...",
      category: "Strategy",
      author: {
        name: "Alex Morgan",
        avatar: "/placeholder.svg?height=40&width=40",
        role: "Content Creator",
      },
      date: "2 hours ago",
      replies: 24,
      likes: 18,
      views: 342,
    },
    {
      id: 2,
      title: "How are you handling FTC disclosure requirements?",
      excerpt:
        "With the recent updates to FTC guidelines, I'm curious how everyone is implementing disclosures across different platforms...",
      category: "Compliance",
      author: {
        name: "Sarah Johnson",
        avatar: "/placeholder.svg?height=40&width=40",
        role: "Marketing Director",
      },
      date: "1 day ago",
      replies: 36,
      likes: 29,
      views: 512,
    },
    {
      id: 3,
      title: "Best affiliate programs for beginners in 2025",
      excerpt:
        "I'm just getting started with affiliate marketing and looking for recommendations on beginner-friendly programs with good support...",
      category: "Beginners",
      author: {
        name: "Michael Chen",
        avatar: "/placeholder.svg?height=40&width=40",
        role: "Affiliate Marketer",
      },
      date: "3 days ago",
      replies: 42,
      likes: 35,
      views: 678,
    },
  ]

  const upcomingEvents = [
    {
      id: 1,
      title: "Affiliate Marketing Masterclass: Advanced Strategies",
      date: "March 25, 2025",
      time: "1:00 PM - 3:00 PM EST",
      host: "John Smith, Affiliate Marketing Expert",
      attendees: 156,
      image: "/placeholder.svg?height=100&width=200",
    },
    {
      id: 2,
      title: "Q&A Session: Scaling Your Affiliate Business",
      date: "April 2, 2025",
      time: "11:00 AM - 12:00 PM EST",
      host: "Emma Davis, 7-Figure Affiliate",
      attendees: 98,
      image: "/placeholder.svg?height=100&width=200",
    },
    {
      id: 3,
      title: "Panel Discussion: The Future of Creator Partnerships",
      date: "April 10, 2025",
      time: "2:00 PM - 3:30 PM EST",
      host: "Multiple Industry Experts",
      attendees: 124,
      image: "/placeholder.svg?height=100&width=200",
    },
  ]

  const popularGroups = [
    {
      id: 1,
      name: "Affiliate SEO Strategies",
      members: 2456,
      posts: 1245,
      image: "/placeholder.svg?height=60&width=60",
    },
    {
      id: 2,
      name: "Social Media Affiliates",
      members: 1876,
      posts: 986,
      image: "/placeholder.svg?height=60&width=60",
    },
    {
      id: 3,
      name: "Beginner Affiliate Support",
      members: 3254,
      posts: 2145,
      image: "/placeholder.svg?height=60&width=60",
    },
    {
      id: 4,
      name: "Advanced Affiliate Tactics",
      members: 1245,
      posts: 876,
      image: "/placeholder.svg?height=60&width=60",
    },
  ]

  return (
    <div className="bg-background">
      <div className="container py-12 md:py-24">
        <div className="mx-auto max-w-3xl text-center mb-16">
          <Badge className="mb-4" variant="secondary">
            Community
          </Badge>
          <h1 className="mb-4 text-3xl font-bold sm:text-4xl md:text-5xl">Join the Affiliate Marketing Community</h1>
          <p className="text-muted-foreground md:text-xl">
            Connect with fellow affiliates, share strategies, and learn from industry experts.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 mt-8">
            <Button size="lg">
              Join Community
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline">
              Browse Discussions
            </Button>
          </div>
        </div>

        <Tabs defaultValue="discussions" className="w-full max-w-5xl mx-auto">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="discussions">
              <MessageSquare className="mr-2 h-4 w-4" />
              Discussions
            </TabsTrigger>
            <TabsTrigger value="groups">
              <Users className="mr-2 h-4 w-4" />
              Groups
            </TabsTrigger>
            <TabsTrigger value="events">
              <Calendar className="mr-2 h-4 w-4" />
              Events
            </TabsTrigger>
          </TabsList>

          <TabsContent value="discussions" className="mt-6">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="md:w-3/4">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold">Featured Discussions</h2>
                  <Button variant="outline">Start New Discussion</Button>
                </div>

                <div className="space-y-4">
                  {featuredDiscussions.map((discussion) => (
                    <Card key={discussion.id}>
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={discussion.author.avatar} alt={discussion.author.name} />
                            <AvatarFallback>{discussion.author.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="secondary">{discussion.category}</Badge>
                              <span className="text-xs text-muted-foreground">{discussion.date}</span>
                            </div>
                            <Link href={`/community/discussions/${discussion.id}`} className="hover:underline">
                              <h3 className="text-xl font-semibold mb-2">{discussion.title}</h3>
                            </Link>
                            <p className="text-muted-foreground mb-4">{discussion.excerpt}</p>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <div className="flex items-center mr-4">
                                <MessageCircle className="mr-1 h-4 w-4" />
                                {discussion.replies} replies
                              </div>
                              <div className="flex items-center mr-4">
                                <Heart className="mr-1 h-4 w-4" />
                                {discussion.likes} likes
                              </div>
                              <div className="flex items-center">
                                <TrendingUp className="mr-1 h-4 w-4" />
                                {discussion.views} views
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <div className="mt-6 text-center">
                  <Button variant="outline">
                    View All Discussions
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="md:w-1/4 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Popular Topics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">Strategy</Badge>
                      <Badge variant="secondary">SEO</Badge>
                      <Badge variant="secondary">Social Media</Badge>
                      <Badge variant="secondary">Beginners</Badge>
                      <Badge variant="secondary">Compliance</Badge>
                      <Badge variant="secondary">Tools</Badge>
                      <Badge variant="secondary">Case Studies</Badge>
                      <Badge variant="secondary">Conversion</Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Top Contributors</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Sarah Johnson" />
                          <AvatarFallback>SJ</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">Sarah Johnson</div>
                          <div className="text-xs text-muted-foreground">245 contributions</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Michael Chen" />
                          <AvatarFallback>MC</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">Michael Chen</div>
                          <div className="text-xs text-muted-foreground">198 contributions</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Alex Morgan" />
                          <AvatarFallback>AM</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">Alex Morgan</div>
                          <div className="text-xs text-muted-foreground">176 contributions</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="groups" className="mt-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Popular Groups</h2>
              <Button variant="outline">Create New Group</Button>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {popularGroups.map((group) => (
                <Card key={group.id} className="overflow-hidden">
                  <div className="aspect-video bg-muted flex items-center justify-center">
                    <img
                      src={group.image || "/placeholder.svg"}
                      alt={group.name}
                      className="h-16 w-16 object-cover rounded-full"
                    />
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle>{group.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Users className="mr-1 h-4 w-4" />
                      <span>{group.members.toLocaleString()} members</span>
                      <span className="mx-2">•</span>
                      <MessageSquare className="mr-1 h-4 w-4" />
                      <span>{group.posts.toLocaleString()} posts</span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Join Group</Button>
                  </CardFooter>
                </Card>
              ))}
            </div>

            <div className="mt-8">
              <Card>
                <CardHeader>
                  <CardTitle>Find Groups by Category</CardTitle>
                  <CardDescription>Browse groups based on your interests</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-3">
                    <Button variant="outline" className="justify-start">
                      <Lightbulb className="mr-2 h-4 w-4" />
                      Strategy & Tactics
                    </Button>
                    <Button variant="outline" className="justify-start">
                      <Users className="mr-2 h-4 w-4" />
                      Beginners
                    </Button>
                    <Button variant="outline" className="justify-start">
                      <TrendingUp className="mr-2 h-4 w-4" />
                      Advanced Affiliates
                    </Button>
                    <Button variant="outline" className="justify-start">
                      <MessageCircle className="mr-2 h-4 w-4" />
                      Niche Discussions
                    </Button>
                    <Button variant="outline" className="justify-start">
                      <Bookmark className="mr-2 h-4 w-4" />
                      Program Reviews
                    </Button>
                    <Button variant="outline" className="justify-start">
                      <Heart className="mr-2 h-4 w-4" />
                      Success Stories
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="events" className="mt-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Upcoming Events</h2>
              <Button variant="outline">Submit Event</Button>
            </div>

            <div className="space-y-6">
              {upcomingEvents.map((event) => (
                <Card key={event.id}>
                  <div className="flex flex-col md:flex-row">
                    <div className="md:w-1/4 p-6">
                      <div className="aspect-video bg-muted rounded-md overflow-hidden">
                        <img
                          src={event.image || "/placeholder.svg"}
                          alt={event.title}
                          className="h-full w-full object-cover"
                        />
                      </div>
                    </div>
                    <div className="flex-1 p-6">
                      <h3 className="text-xl font-semibold mb-2">{event.title}</h3>
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6 mb-4">
                        <div className="flex items-center text-sm">
                          <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
                          {event.date}
                        </div>
                        <div className="flex items-center text-sm">
                          <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                          {event.time}
                        </div>
                        <div className="flex items-center text-sm">
                          <Users className="mr-2 h-4 w-4 text-muted-foreground" />
                          {event.attendees} attending
                        </div>
                      </div>
                      <p className="mb-4 text-muted-foreground">Hosted by: {event.host}</p>
                      <div className="flex flex-col sm:flex-row gap-3">
                        <Button>Register Now</Button>
                        <Button variant="outline">Add to Calendar</Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            <div className="mt-8">
              <Card className="bg-primary text-primary-foreground">
                <CardHeader>
                  <CardTitle>Host Your Own Event</CardTitle>
                  <CardDescription className="text-primary-foreground/80">
                    Share your knowledge and connect with the community by hosting a virtual event.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="mb-6">
                    Whether you're an experienced affiliate marketer or have specialized knowledge to share, hosting an
                    event is a great way to build your reputation and help others succeed.
                  </p>
                  <Button className="bg-background text-foreground hover:bg-background/90">Learn About Hosting</Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

