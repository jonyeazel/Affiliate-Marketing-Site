"use client"

import { useState } from "react"
import Link from "next/link"
import { Tabs } from "@/components/ui/tabs"
import { Accordion } from "@/components/ui/accordion"
import { ProductComparison } from "@/components/ui/product-comparison"
import { TestimonialSlider } from "@/components/ui/testimonial-slider"
import { DropdownMenu } from "@/components/ui/dropdown-menu"
import { Modal } from "@/components/ui/modal"
import { Settings, User, LogOut, ChevronRight } from "lucide-react"
import AnimatedElement from "@/components/animated-element"

export default function ComponentsDemo() {
  const [isModalOpen, setIsModalOpen] = useState(false)

  // Example data for tabs
  const tabsData = [
    {
      label: "For Affiliates",
      content: (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Affiliate Benefits</h3>
          <ul className="list-disc pl-5 space-y-2">
            <li>Instant payments directly to your account</li>
            <li>Higher commission rates than industry standard</li>
            <li>Advanced analytics and tracking</li>
            <li>Dedicated affiliate manager</li>
          </ul>
        </div>
      ),
    },
    {
      label: "For Brands",
      content: (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Brand Benefits</h3>
          <ul className="list-disc pl-5 space-y-2">
            <li>Access to our network of high-quality affiliates</li>
            <li>Real-time performance tracking</li>
            <li>Fraud protection and verification</li>
            <li>Custom commission structures</li>
          </ul>
        </div>
      ),
    },
    {
      label: "Getting Started",
      content: (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Quick Start Guide</h3>
          <ol className="list-decimal pl-5 space-y-2">
            <li>Create your account</li>
            <li>Complete your profile</li>
            <li>Browse available programs</li>
            <li>Apply to join programs</li>
            <li>Start promoting and earning</li>
          </ol>
        </div>
      ),
    },
  ]

  // Example data for dropdown
  const dropdownItems = [
    {
      label: "Account Settings",
      icon: Settings,
      onClick: () => console.log("Settings clicked"),
    },
    {
      label: "Your Profile",
      icon: User,
      onClick: () => console.log("Profile clicked"),
    },
    {
      label: "Sign out",
      icon: LogOut,
      onClick: () => console.log("Sign out clicked"),
    },
  ]

  // Example data for accordion
  const accordionItems = [
    {
      title: "How do I get paid?",
      content:
        "You get paid instantly when a sale is made through your affiliate link. The commission is automatically transferred to your connected account with no waiting period.",
    },
    {
      title: "What commission rates can I expect?",
      content:
        "Commission rates vary by program, but our average rates are 15-30% for digital products and 5-15% for physical products, which is higher than industry standards.",
    },
    {
      title: "How do I track my performance?",
      content:
        "Our comprehensive dashboard provides real-time analytics on clicks, conversions, earnings, and more. You can filter by date, program, and campaign to get detailed insights.",
    },
    {
      title: "Is there a minimum payout threshold?",
      content: "No, there is no minimum payout threshold. You get paid for every sale, regardless of the amount.",
    },
  ]

  // Example data for product comparison
  const comparisonProducts = [
    {
      name: "AffiliateMarketing.com",
      features: {
        payment: "Instant",
        commissionRate: "Up to 30%",
        tracking: "Real-time",
        support: "24/7 Dedicated",
        minimumPayout: "$0",
        fraudProtection: true,
        mobileApp: true,
      },
    },
    {
      name: "Traditional Platform",
      features: {
        payment: "30-90 days",
        commissionRate: "Up to 10%",
        tracking: "Delayed",
        support: "Email only",
        minimumPayout: "$50-$100",
        fraudProtection: false,
        mobileApp: false,
      },
    },
  ]

  const comparisonFeatures = [
    { id: "payment", name: "Payment Schedule" },
    { id: "commissionRate", name: "Commission Rate" },
    { id: "tracking", name: "Tracking" },
    { id: "support", name: "Support" },
    { id: "minimumPayout", name: "Minimum Payout" },
    { id: "fraudProtection", name: "Fraud Protection" },
    { id: "mobileApp", name: "Mobile App" },
  ]

  // Example data for testimonials
  const testimonials = [
    {
      name: "Alex Chen",
      role: "Tech & Lifestyle Blogger",
      rating: 5,
      quote:
        "I've been in affiliate marketing for 7 years, and this is the platform I've been waiting for. The instant payments alone are worth it, but the AI matching has connected me with brands I never would have found otherwise.",
      company: "TechLifeDaily.com",
    },
    {
      name: "Sarah Johnson",
      role: "CMO",
      rating: 5,
      quote:
        "As a DTC brand, finding the right affiliates has always been our biggest challenge. This platform solved that problem instantly. We're seeing 3x the ROI compared to our previous affiliate program.",
      company: "Fashion Brand Inc.",
    },
    {
      name: "Michael Rodriguez",
      role: "Fitness Influencer",
      rating: 4,
      quote:
        "The unified dashboard is a game-changer. I used to spend hours jumping between different affiliate platforms. Now I can manage everything in one place and focus on creating content that converts.",
      company: "FitWithMike",
    },
  ]

  return (
    <div className="min-h-screen bg-[#0A0A14] text-white py-12">
      <div className="container mx-auto px-4">
        <AnimatedElement animation="fade-in" className="mb-12 text-center">
          <h1 className="text-4xl font-bold mb-4">Component Library</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            A showcase of the UI components available for your affiliate marketing website.
          </p>
        </AnimatedElement>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
          <AnimatedElement animation="slide-right" delay={200} className="space-y-6">
            <div className="bg-white/5 rounded-lg border border-white/10 p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Settings className="mr-2 h-5 w-5 text-[#00F0FF]" />
                Dropdown Menu
              </h2>
              <div className="p-4 bg-white/5 rounded-lg">
                <DropdownMenu buttonText="User Menu" items={dropdownItems} />
              </div>
            </div>

            <div className="bg-white/5 rounded-lg border border-white/10 p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Settings className="mr-2 h-5 w-5 text-[#00F0FF]" />
                Modal Dialog
              </h2>
              <div className="p-4 bg-white/5 rounded-lg">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(true)}
                  className="px-4 py-2 bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white rounded-md hover:opacity-90 transition-opacity"
                >
                  Open Modal
                </button>

                <Modal
                  isOpen={isModalOpen}
                  setIsOpen={setIsModalOpen}
                  title="Contact Us"
                  description="Fill out the form below and we'll get back to you as soon as possible."
                >
                  <form className="mt-4 space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-sm focus:border-[#00F0FF] focus:ring-[#00F0FF] sm:text-sm"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Email
                      </label>
                      <input
                        type="email"
                        id="email"
                        className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-sm focus:border-[#00F0FF] focus:ring-[#00F0FF] sm:text-sm"
                        placeholder="you@example.com"
                      />
                    </div>
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Message
                      </label>
                      <textarea
                        id="message"
                        rows={4}
                        className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-sm focus:border-[#00F0FF] focus:ring-[#00F0FF] sm:text-sm"
                        placeholder="Your message"
                      />
                    </div>
                    <div className="flex justify-end space-x-3">
                      <button
                        type="button"
                        onClick={() => setIsModalOpen(false)}
                        className="px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-2 bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white rounded-md hover:opacity-90 transition-opacity"
                      >
                        Send Message
                      </button>
                    </div>
                  </form>
                </Modal>
              </div>
            </div>
          </AnimatedElement>

          <AnimatedElement animation="slide-left" delay={400} className="space-y-6">
            <div className="bg-white/5 rounded-lg border border-white/10 p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Settings className="mr-2 h-5 w-5 text-[#00F0FF]" />
                Tabs
              </h2>
              <div className="p-4 bg-white/5 rounded-lg">
                <Tabs tabs={tabsData} />
              </div>
            </div>

            <div className="bg-white/5 rounded-lg border border-white/10 p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Settings className="mr-2 h-5 w-5 text-[#00F0FF]" />
                Accordion
              </h2>
              <div className="p-4 bg-white/5 rounded-lg">
                <Accordion items={accordionItems} />
              </div>
            </div>
          </AnimatedElement>
        </div>

        <div className="space-y-12">
          <AnimatedElement animation="slide-up" delay={600}>
            <div className="bg-white/5 rounded-lg border border-white/10 p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Settings className="mr-2 h-5 w-5 text-[#00F0FF]" />
                Product Comparison
              </h2>
              <div className="p-4 bg-white/5 rounded-lg overflow-hidden">
                <ProductComparison products={comparisonProducts} features={comparisonFeatures} />
              </div>
            </div>
          </AnimatedElement>

          <AnimatedElement animation="slide-up" delay={800}>
            <div className="bg-white/5 rounded-lg border border-white/10 p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Settings className="mr-2 h-5 w-5 text-[#00F0FF]" />
                Testimonial Slider
              </h2>
              <div className="p-4 bg-white/5 rounded-lg">
                <TestimonialSlider testimonials={testimonials} />
              </div>
            </div>
          </AnimatedElement>
        </div>

        <AnimatedElement animation="fade-in" delay={1000} className="mt-12 text-center">
          <p className="text-gray-400 mb-4">
            These components are built with Headless UI and styled with Tailwind CSS and daisyUI.
          </p>
          <Link
            href="/"
            className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white rounded-md hover:opacity-90 transition-opacity"
          >
            Back to Home
            <ChevronRight className="ml-2 h-4 w-4" />
          </Link>
        </AnimatedElement>
      </div>
    </div>
  )
}

