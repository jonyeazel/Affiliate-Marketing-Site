"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  Settings,
  Edit,
  Share2,
  Trophy,
  Star,
  Sparkles,
  DollarSign,
  TrendingUp,
  BarChart3,
  Search,
  Bell,
  LinkIcon,
  ExternalLink,
  Copy,
  CheckCircle,
  Gift,
  Zap,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Progress } from "@/components/ui/progress"

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("stats")
  const [copiedLink, setCopiedLink] = useState<string | null>(null)

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopiedLink(text)
    setTimeout(() => setCopiedLink(null), 2000)
  }

  const userStats = {
    level: 7,
    xp: 1250,
    xpNeeded: 2000,
    totalEarnings: 4289.45,
    activeLinks: 24,
    followers: 128,
    following: 87,
    achievements: 9,
    completedAchievements: 3,
    conversionRate: 8.2,
    avgEarningsPerLink: 178.73,
  }

  const badges = [
    { id: "1", name: "Early Adopter", icon: Star, color: "#FFFF00", description: "Joined during beta" },
    { id: "2", name: "Rising Star", icon: TrendingUp, color: "#FF00FF", description: "5 consecutive days of earnings" },
    { id: "3", name: "Verified Creator", icon: Sparkles, color: "#00FFFF", description: "Identity verified" },
  ]

  const links = [
    {
      id: "1",
      url: "amzn.to/3xYz123",
      fullUrl: "https://amzn.to/3xYz123",
      product: "Ultra Boost Headphones Pro",
      clicks: 342,
      conversions: 28,
      earnings: 432.19,
    },
    {
      id: "2",
      url: "shpfy.com/b/aB12c",
      fullUrl: "https://shpfy.com/b/aB12c",
      product: "Glow Serum Collection",
      clicks: 218,
      conversions: 19,
      earnings: 289.45,
    },
    {
      id: "3",
      url: "techft.co/watch2",
      fullUrl: "https://techft.co/watch2",
      product: "FitPro Smart Watch",
      clicks: 156,
      conversions: 12,
      earnings: 167.82,
    },
  ]

  const recentActivity = [
    {
      id: "1",
      type: "earnings",
      amount: 42.5,
      product: "Ultra Boost Headphones Pro",
      timestamp: new Date(Date.now() - 1000 * 60 * 30),
    },
    {
      id: "2",
      type: "achievement",
      name: "First $100",
      reward: "$10 bonus",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
    },
    {
      id: "3",
      type: "link",
      product: "Glow Serum Collection",
      clicks: 24,
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5),
    },
    {
      id: "4",
      type: "earnings",
      amount: 18.75,
      product: "FitPro Smart Watch",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 8),
    },
    { id: "5", type: "level", level: 7, timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24) },
  ]

  const formatTime = (date: Date) => {
    const now = new Date()
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

    if (diffInSeconds < 60) return `${diffInSeconds}s ago`
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`
    return `${Math.floor(diffInSeconds / 86400)}d ago`
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-black/80 border-b border-white/10">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2">
              <div className="relative h-8 w-8">
                <div className="absolute h-4 w-8 bg-[#FF00FF] top-0 rounded-sm"></div>
                <div className="absolute h-4 w-6 bg-[#00FFFF] bottom-0 left-1 rounded-sm"></div>
                <div className="absolute h-4 w-4 bg-[#FFFF00] bottom-0 right-1 rounded-sm"></div>
              </div>
              <span className="font-bold text-lg">moneydrip</span>
            </Link>

            <div className="hidden md:flex relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
              <Input
                placeholder="Search..."
                className="pl-10 bg-white/5 border-white/10 focus:border-white/20 text-white"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-white/70 hover:text-white">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-white/70 hover:text-white">
              <Settings className="h-5 w-5" />
            </Button>
            <Avatar className="h-8 w-8">
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <div className="container py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="icon" className="h-10 w-10 border-white/20" asChild>
            <Link href="/dashboard">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold">My Profile</h1>
            <p className="text-white/60">View and manage your creator profile</p>
          </div>
        </div>

        {/* Profile Header */}
        <div className="relative mb-8">
          <div className="h-48 rounded-xl bg-gradient-to-r from-[#FF00FF]/30 to-[#00FFFF]/30 overflow-hidden">
            <div className="absolute inset-0 bg-[url('/placeholder.svg?height=400&width=1200')] opacity-20 bg-cover bg-center"></div>
          </div>

          <div className="absolute -bottom-16 left-8 h-32 w-32 rounded-full border-4 border-black bg-[#111111] overflow-hidden">
            <Avatar className="h-full w-full">
              <AvatarImage src="/placeholder.svg?height=128&width=128" alt="Jordan Doe" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
          </div>

          <div className="absolute bottom-4 right-4 flex gap-2">
            <Button variant="outline" size="sm" className="border-white/20 bg-black/50 backdrop-blur-md">
              <Edit className="mr-2 h-4 w-4" />
              Edit Profile
            </Button>
            <Button variant="outline" size="sm" className="border-white/20 bg-black/50 backdrop-blur-md">
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
          </div>
        </div>

        {/* Profile Info */}
        <div className="mt-20 mb-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-bold">Jordan Doe</h2>
                <Badge className="bg-[#00FFFF] text-black">
                  <Sparkles className="mr-1 h-3 w-3" />
                  Verified
                </Badge>
              </div>
              <p className="text-white/60">@jordandoe</p>
              <p className="mt-2 max-w-xl">
                Tech enthusiast and content creator. Sharing honest reviews and monetization tips. Join me on this
                journey! 🚀
              </p>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-xl font-bold">{userStats.followers}</div>
                <div className="text-sm text-white/60">Followers</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold">{userStats.following}</div>
                <div className="text-sm text-white/60">Following</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold">${userStats.totalEarnings.toLocaleString()}</div>
                <div className="text-sm text-white/60">Earned</div>
              </div>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {badges.map((badge) => (
              <TooltipProvider key={badge.id}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className={`h-8 w-8 rounded-full bg-[${badge.color}]/20 flex items-center justify-center`}>
                      <badge.icon className={`h-4 w-4 text-[${badge.color}]`} />
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="font-medium">{badge.name}</p>
                    <p className="text-xs text-white/60">{badge.description}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ))}
          </div>
        </div>

        {/* Level Progress */}
        <Card className="bg-[#111111] border-white/10 mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="relative">
                <div className="h-24 w-24 rounded-full bg-[#191919] border-4 border-[#111111] flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{userStats.level}</div>
                    <div className="text-xs text-white/60">Level</div>
                  </div>
                </div>
                <div className="absolute -top-2 -right-2 bg-[#FF00FF] text-black rounded-full w-6 h-6 flex items-center justify-center">
                  <Star className="h-3 w-3" />
                </div>
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium">Level Progress</h3>
                  <span className="text-sm text-white/60">
                    {userStats.xp}/{userStats.xpNeeded} XP
                  </span>
                </div>

                <Progress
                  value={(userStats.xp / userStats.xpNeeded) * 100}
                  className="h-2 mb-4 bg-white/10"
                  indicatorClassName="bg-gradient-to-r from-[#FF00FF] to-[#00FFFF]"
                />

                <div className="text-sm text-white/60">
                  <span className="text-[#00FFFF]">{userStats.xpNeeded - userStats.xp} XP</span> needed to reach Level{" "}
                  {userStats.level + 1}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="bg-[#191919]">
            <TabsTrigger value="stats">Stats</TabsTrigger>
            <TabsTrigger value="links">Links</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          <TabsContent value="stats" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-[#111111] border-white/10">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-white/60 flex items-center">
                    <DollarSign className="mr-2 h-4 w-4 text-[#00FFFF]" />
                    Total Earnings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${userStats.totalEarnings.toLocaleString()}</div>
                  <p className="text-xs text-white/40 mt-1">Lifetime earnings</p>
                </CardContent>
              </Card>

              <Card className="bg-[#111111] border-white/10">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-white/60 flex items-center">
                    <LinkIcon className="mr-2 h-4 w-4 text-[#FF00FF]" />
                    Active Links
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{userStats.activeLinks}</div>
                  <p className="text-xs text-white/40 mt-1">Across 8 platforms</p>
                </CardContent>
              </Card>

              <Card className="bg-[#111111] border-white/10">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-white/60 flex items-center">
                    <TrendingUp className="mr-2 h-4 w-4 text-[#FFFF00]" />
                    Conversion Rate
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{userStats.conversionRate}%</div>
                  <p className="text-xs text-white/40 mt-1">Industry avg: 3.4%</p>
                </CardContent>
              </Card>

              <Card className="bg-[#111111] border-white/10">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-white/60 flex items-center">
                    <BarChart3 className="mr-2 h-4 w-4 text-[#00FFFF]" />
                    Avg. Per Link
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${userStats.avgEarningsPerLink}</div>
                  <p className="text-xs text-white/40 mt-1">Per active link</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <Card className="bg-[#111111] border-white/10">
                <CardHeader>
                  <CardTitle>Earnings by Platform</CardTitle>
                  <CardDescription className="text-white/60">Where your revenue comes from</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-[#00FFFF]"></div>
                          <span>Amazon Associates</span>
                        </div>
                        <div className="font-medium">$1,845.32</div>
                      </div>
                      <Progress value={42} className="h-2 bg-white/10" indicatorClassName="bg-[#00FFFF]" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-[#FF00FF]"></div>
                          <span>Shopify Partners</span>
                        </div>
                        <div className="font-medium">$1,289.45</div>
                      </div>
                      <Progress value={32} className="h-2 bg-white/10" indicatorClassName="bg-[#FF00FF]" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-[#FFFF00]"></div>
                          <span>TikTok Shop</span>
                        </div>
                        <div className="font-medium">$821.87</div>
                      </div>
                      <Progress value={21} className="h-2 bg-white/10" indicatorClassName="bg-[#FFFF00]" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-white/60"></div>
                          <span>Other Platforms</span>
                        </div>
                        <div className="font-medium">$332.81</div>
                      </div>
                      <Progress value={5} className="h-2 bg-white/10" indicatorClassName="bg-white/60" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[#111111] border-white/10">
                <CardHeader>
                  <CardTitle>Audience Demographics</CardTitle>
                  <CardDescription className="text-white/60">Who engages with your content</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h4 className="text-sm font-medium mb-2">Age Groups</h4>
                      <div className="grid grid-cols-5 gap-2">
                        <div className="space-y-1">
                          <div className="h-24 bg-white/10 rounded-md overflow-hidden">
                            <div className="bg-[#00FFFF] h-[30%] w-full"></div>
                          </div>
                          <div className="text-xs text-center text-white/60">18-24</div>
                        </div>
                        <div className="space-y-1">
                          <div className="h-24 bg-white/10 rounded-md overflow-hidden">
                            <div className="bg-[#00FFFF] h-[65%] w-full"></div>
                          </div>
                          <div className="text-xs text-center text-white/60">25-34</div>
                        </div>
                        <div className="space-y-1">
                          <div className="h-24 bg-white/10 rounded-md overflow-hidden">
                            <div className="bg-[#00FFFF] h-[45%] w-full"></div>
                          </div>
                          <div className="text-xs text-center text-white/60">35-44</div>
                        </div>
                        <div className="space-y-1">
                          <div className="h-24 bg-white/10 rounded-md overflow-hidden">
                            <div className="bg-[#00FFFF] h-[25%] w-full"></div>
                          </div>
                          <div className="text-xs text-center text-white/60">45-54</div>
                        </div>
                        <div className="space-y-1">
                          <div className="h-24 bg-white/10 rounded-md overflow-hidden">
                            <div className="bg-[#00FFFF] h-[15%] w-full"></div>
                          </div>
                          <div className="text-xs text-center text-white/60">55+</div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium mb-2">Top Locations</h4>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span>United States</span>
                          <span>42%</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>United Kingdom</span>
                          <span>18%</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Canada</span>
                          <span>12%</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Australia</span>
                          <span>8%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="links" className="mt-6">
            <Card className="bg-[#111111] border-white/10">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>My Links</CardTitle>
                    <CardDescription className="text-white/60">Your active affiliate links</CardDescription>
                  </div>
                  <Button className="bg-gradient-to-r from-[#00FFFF] to-[#FF00FF] text-black font-medium">
                    Create New Link
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {links.map((link) => (
                    <div key={link.id} className="bg-[#191919] rounded-lg p-4">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <LinkIcon className="h-4 w-4 text-[#00FFFF]" />
                            <span className="font-medium">{link.product}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-6 px-2 text-white/60 hover:text-white"
                                    onClick={() => copyToClipboard(link.fullUrl)}
                                  >
                                    {link.url}
                                    {copiedLink === link.fullUrl ? (
                                      <CheckCircle className="ml-1 h-3 w-3 text-[#00FFFF]" />
                                    ) : (
                                      <Copy className="ml-1 h-3 w-3" />
                                    )}
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Click to copy full link</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                            <Button variant="ghost" size="sm" className="h-6 px-2 text-white/60 hover:text-white">
                              <ExternalLink className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="text-center">
                            <div className="text-sm text-white/60">Clicks</div>
                            <div className="font-medium">{link.clicks}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm text-white/60">Conv.</div>
                            <div className="font-medium">{link.conversions}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-sm text-white/60">Earned</div>
                            <div className="font-medium text-[#00FFFF]">${link.earnings}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full border-white/20">
                  View All Links
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="activity" className="mt-6">
            <Card className="bg-[#111111] border-white/10">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription className="text-white/60">Your latest actions and achievements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity) => (
                    <div key={activity.id} className="flex items-start gap-4">
                      <div
                        className={`h-10 w-10 rounded-full flex items-center justify-center ${
                          activity.type === "earnings"
                            ? "bg-[#00FFFF]/20"
                            : activity.type === "achievement"
                              ? "bg-[#FFFF00]/20"
                              : activity.type === "link"
                                ? "bg-[#FF00FF]/20"
                                : "bg-white/20"
                        }`}
                      >
                        {activity.type === "earnings" && <DollarSign className="h-5 w-5 text-[#00FFFF]" />}
                        {activity.type === "achievement" && <Trophy className="h-5 w-5 text-[#FFFF00]" />}
                        {activity.type === "link" && <LinkIcon className="h-5 w-5 text-[#FF00FF]" />}
                        {activity.type === "level" && <Star className="h-5 w-5 text-white" />}
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div className="font-medium">
                            {activity.type === "earnings" && `Earned $${activity.amount}`}
                            {activity.type === "achievement" && `Unlocked "${activity.name}" achievement`}
                            {activity.type === "link" && `Created link for "${activity.product}"`}
                            {activity.type === "level" && `Reached Level ${activity.level}`}
                          </div>
                          <div className="text-sm text-white/60">{formatTime(activity.timestamp)}</div>
                        </div>
                        <div className="text-sm text-white/60 mt-1">
                          {activity.type === "earnings" && `From ${activity.product}`}
                          {activity.type === "achievement" && `Reward: ${activity.reward}`}
                          {activity.type === "link" && `${activity.clicks} clicks so far`}
                          {activity.type === "level" && "Keep up the great work!"}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full border-white/20">
                  View All Activity
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="achievements" className="mt-6">
            <Card className="bg-[#111111] border-white/10">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Achievements</CardTitle>
                    <CardDescription className="text-white/60">
                      {userStats.completedAchievements}/{userStats.achievements} achievements completed
                    </CardDescription>
                  </div>
                  <Button variant="outline" className="border-white/20" asChild>
                    <Link href="/achievements">View All Achievements</Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="bg-gradient-to-br from-[#00FFFF]/20 to-[#FF00FF]/20 border-white/10">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-[#00FFFF]/20 flex items-center justify-center">
                            <DollarSign className="h-4 w-4 text-[#00FFFF]" />
                          </div>
                          <CardTitle className="text-base">First $100</CardTitle>
                        </div>
                        <Badge className="bg-[#00FFFF] text-black">Completed</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-white/60 mb-2">Earn your first $100 through affiliate links</p>
                      <div className="text-xs text-white/40 flex items-center">
                        <Gift className="h-3 w-3 mr-1 text-[#FFFF00]" />
                        Reward: $10 bonus
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-[#191919] border-white/10">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-[#FF00FF]/20 flex items-center justify-center">
                            <Zap className="h-4 w-4 text-[#FF00FF]" />
                          </div>
                          <CardTitle className="text-base">Link Master</CardTitle>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-white/60 mb-2">Create 10 affiliate links</p>
                      <div className="flex items-center justify-between mb-1">
                        <div className="text-xs text-white/40 flex items-center">
                          <Gift className="h-3 w-3 mr-1 text-[#00FFFF]" />
                          Reward: Zero fee payout
                        </div>
                        <div className="text-xs">7/10</div>
                      </div>
                      <Progress value={70} className="h-1.5 bg-white/10" indicatorClassName="bg-[#FF00FF]" />
                    </CardContent>
                  </Card>

                  <Card className="bg-[#191919] border-white/10">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-[#FFFF00]/20 flex items-center justify-center">
                            <TrendingUp className="h-4 w-4 text-[#FFFF00]" />
                          </div>
                          <CardTitle className="text-base">Conversion Pro</CardTitle>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-white/60 mb-2">Achieve 5% conversion rate on any link</p>
                      <div className="flex items-center justify-between mb-1">
                        <div className="text-xs text-white/40 flex items-center">
                          <Gift className="h-3 w-3 mr-1 text-[#FF00FF]" />
                          Reward: Early access drops
                        </div>
                        <div className="text-xs">4.2%/5%</div>
                      </div>
                      <Progress value={84} className="h-1.5 bg-white/10" indicatorClassName="bg-[#FFFF00]" />
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

