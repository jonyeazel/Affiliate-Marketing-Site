import Link from "next/link"
import { Calculator, LineChart, Link2, FileText, ArrowRight, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import CommissionCalculator from "@/components/tools/commission-calculator"

export default function ToolsPage() {
  const tools = [
    {
      id: "commission-calculator",
      title: "Commission Calculator",
      description: "Calculate potential earnings from your affiliate marketing efforts",
      icon: <Calculator className="h-6 w-6" />,
      category: "calculators",
    },
    {
      id: "link-generator",
      title: "Affiliate Link Generator",
      description: "Create and manage trackable affiliate links for any program",
      icon: <Link2 className="h-6 w-6" />,
      category: "links",
    },
    {
      id: "earnings-predictor",
      title: "Earnings Predictor",
      description: "Forecast your potential affiliate earnings based on traffic and conversion data",
      icon: <LineChart className="h-6 w-6" />,
      category: "calculators",
    },
    {
      id: "disclosure-generator",
      title: "Disclosure Generator",
      description: "Create FTC-compliant affiliate disclosures for your content",
      icon: <FileText className="h-6 w-6" />,
      category: "compliance",
    },
  ]

  return (
    <div className="bg-background">
      <div className="container py-12 md:py-24">
        <div className="mx-auto max-w-3xl text-center mb-16">
          <Badge className="mb-4" variant="secondary">
            Tools
          </Badge>
          <h1 className="mb-4 text-3xl font-bold sm:text-4xl md:text-5xl">Affiliate Marketing Tools & Calculators</h1>
          <p className="text-muted-foreground md:text-xl">
            Free tools to help you plan, optimize, and grow your affiliate marketing business.
          </p>
        </div>

        <Tabs defaultValue="all" className="w-full max-w-4xl mx-auto mb-12">
          <div className="flex justify-center mb-8">
            <TabsList>
              <TabsTrigger value="all">All Tools</TabsTrigger>
              <TabsTrigger value="calculators">Calculators</TabsTrigger>
              <TabsTrigger value="links">Link Tools</TabsTrigger>
              <TabsTrigger value="compliance">Compliance</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="all">
            <div className="grid gap-6 md:grid-cols-2">
              {tools.map((tool) => (
                <Card key={tool.id} className="transition-all hover:shadow-md">
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <div className="rounded-full bg-primary/10 p-3 text-primary">{tool.icon}</div>
                      <div>
                        <CardTitle>{tool.title}</CardTitle>
                        <CardDescription>{tool.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardFooter>
                    <Button asChild className="w-full">
                      <Link href={`/tools/${tool.id}`}>
                        Use Tool
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="calculators">
            <div className="grid gap-6 md:grid-cols-2">
              {tools
                .filter((tool) => tool.category === "calculators")
                .map((tool) => (
                  <Card key={tool.id} className="transition-all hover:shadow-md">
                    <CardHeader>
                      <div className="flex items-center gap-4">
                        <div className="rounded-full bg-primary/10 p-3 text-primary">{tool.icon}</div>
                        <div>
                          <CardTitle>{tool.title}</CardTitle>
                          <CardDescription>{tool.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href={`/tools/${tool.id}`}>
                          Use Tool
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="links">
            <div className="grid gap-6 md:grid-cols-2">
              {tools
                .filter((tool) => tool.category === "links")
                .map((tool) => (
                  <Card key={tool.id} className="transition-all hover:shadow-md">
                    <CardHeader>
                      <div className="flex items-center gap-4">
                        <div className="rounded-full bg-primary/10 p-3 text-primary">{tool.icon}</div>
                        <div>
                          <CardTitle>{tool.title}</CardTitle>
                          <CardDescription>{tool.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href={`/tools/${tool.id}`}>
                          Use Tool
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="compliance">
            <div className="grid gap-6 md:grid-cols-2">
              {tools
                .filter((tool) => tool.category === "compliance")
                .map((tool) => (
                  <Card key={tool.id} className="transition-all hover:shadow-md">
                    <CardHeader>
                      <div className="flex items-center gap-4">
                        <div className="rounded-full bg-primary/10 p-3 text-primary">{tool.icon}</div>
                        <div>
                          <CardTitle>{tool.title}</CardTitle>
                          <CardDescription>{tool.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardFooter>
                      <Button asChild className="w-full">
                        <Link href={`/tools/${tool.id}`}>
                          Use Tool
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Featured Tool: Commission Calculator */}
        <div className="max-w-5xl mx-auto">
          <Card className="border-none shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-primary/10 p-3 text-primary">
                  <Calculator className="h-6 w-6" />
                </div>
                <div>
                  <CardTitle className="text-2xl">Commission Calculator</CardTitle>
                  <CardDescription>
                    Calculate your potential earnings from affiliate marketing based on your traffic, conversion rate,
                    and commission structure.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <CommissionCalculator />
            </CardContent>
          </Card>
        </div>

        {/* Premium Tools CTA */}
        <div className="mt-16 max-w-5xl mx-auto">
          <Card className="bg-primary text-primary-foreground">
            <div className="grid md:grid-cols-2 gap-6">
              <CardContent className="pt-6 md:pt-10">
                <div className="space-y-4">
                  <h2 className="text-2xl font-bold">Unlock Premium Tools</h2>
                  <p className="text-primary-foreground/80">
                    Get access to our full suite of advanced affiliate marketing tools with a Pro or Enterprise
                    subscription.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>Advanced link management system</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>AI-powered content optimization</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>Competitor analysis tools</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="mr-2 h-4 w-4" />
                      <span>Advanced performance analytics</span>
                    </li>
                  </ul>
                  <Button className="bg-background text-foreground hover:bg-background/90">
                    View Pricing
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
              <div className="hidden md:flex items-center justify-center p-6">
                <div className="w-full max-w-sm h-64 bg-primary-foreground/10 rounded-lg flex items-center justify-center">
                  <LineChart className="h-24 w-24 text-primary-foreground/30" />
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}

