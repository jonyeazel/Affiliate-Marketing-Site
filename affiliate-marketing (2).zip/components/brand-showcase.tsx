"use client"

import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { useState } from "react"

interface Brand {
  name: string
  logo: string
  category: string
  commission?: number
}

export function BrandShowcase() {
  const [page, setPage] = useState(0)
  const brandsPerPage = 8

  const brands: Brand[] = [
    // Health & Wellness
    { name: "HEDO", logo: "/images/hedo-moisturizer.png", category: "Skincare", commission: 18 },
    { name: "Coldlife", logo: "/images/coldlife-cooling.png", category: "Wellness Tech", commission: 22 },
    { name: "Pink Nookie", logo: "/images/pink-nookie.png", category: "Women's Health", commission: 20 },
    { name: "Plants Basically", logo: "/images/shilajit.png", category: "Supplements", commission: 15 },
    { name: "Blueprint", logo: "/images/brain-nectar.png", category: "Nootropics", commission: 17 },
    { name: "Reindeer Farms", logo: "/images/deer-antler.png", category: "Natural Supplements", commission: 19 },
    { name: "Bodela", logo: "/images/mushroom-gummies.png", category: "Functional Mushrooms", commission: 21 },
    { name: "Mi & My", logo: "/images/honey-bear.png", category: "Natural Foods", commission: 16 },

    // New Brands
    { name: "Tallow & Co", logo: "/images/tallow-co.png", category: "Natural Skincare", commission: 23 },
    { name: "Inala", logo: "/images/inala-power.png", category: "Hair Care", commission: 25 },
    { name: "Fit2Ride", logo: "/images/fit2ride.png", category: "Fitness Gear", commission: 18 },
    { name: "Hair Growth Co", logo: "/images/hair-growth.png", category: "Hair Solutions", commission: 24 },
    { name: "Oats Overnight", logo: "/images/oats-overnight-pack.png", category: "Nutrition", commission: 20 },
    { name: "Her Fantasy Box", logo: "/images/her-fantasy-box.png", category: "Women's Wellness", commission: 26 },
    { name: "Hollywood Skin", logo: "/images/hollywood-skin.png", category: "Body Care", commission: 22 },
    { name: "Sugar Bear", logo: "/images/sugar-bear.png", category: "Specialty Foods", commission: 19 },
  ]

  const totalPages = Math.ceil(brands.length / brandsPerPage)
  const displayedBrands = brands.slice(page * brandsPerPage, (page + 1) * brandsPerPage)

  const nextPage = () => {
    setPage((prev) => (prev + 1) % totalPages)
  }

  const prevPage = () => {
    setPage((prev) => (prev - 1 + totalPages) % totalPages)
  }

  return (
    <section className="py-24 bg-[#0A0A14]">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            PREMIUM PARTNERS
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Top Brands on Our Platform
          </h2>
          <p className="text-base md:text-lg text-white/70 mb-8">
            Partner with industry-leading brands offering competitive commission rates and high-converting products.
          </p>

          <div className="flex justify-center items-center gap-4 mb-8">
            <Button
              variant="outline"
              size="icon"
              onClick={prevPage}
              className="border-white/20 bg-white/5 hover:bg-white/10 text-white"
            >
              <ChevronLeft className="h-5 w-5" />
              <span className="sr-only">Previous page</span>
            </Button>
            <span className="text-white/70">
              Page {page + 1} of {totalPages}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={nextPage}
              className="border-white/20 bg-white/5 hover:bg-white/10 text-white"
            >
              <ChevronRight className="h-5 w-5" />
              <span className="sr-only">Next page</span>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
          {displayedBrands.map((brand, index) => (
            <motion.div
              key={`${brand.name}-${page}-${index}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="bg-white/5 border border-white/10 rounded-lg p-6 hover:border-[#00F0FF]/30 hover:bg-white/10 transition-all duration-300 group"
            >
              <div className="h-32 flex items-center justify-center mb-4 p-2">
                <img
                  src={brand.logo || "/placeholder.svg"}
                  alt={brand.name}
                  className="max-h-full max-w-full object-contain opacity-90 group-hover:opacity-100 transition-opacity duration-300"
                />
              </div>
              <div className="text-center">
                <h3 className="font-medium text-lg mb-1">{brand.name}</h3>
                <p className="text-white/60 text-sm">{brand.category}</p>
              </div>
              <div className="mt-4 pt-4 border-t border-white/10 flex justify-between items-center">
                <span className="text-white/60 text-sm">Commission</span>
                <span className="text-[#00F0FF] font-medium">
                  {brand.commission || 10 + Math.floor(Math.random() * 15)}%
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-white/60">
            ...and <span className="text-[#00F0FF] font-medium">2,500+</span> more brands waiting for you
          </p>
        </div>
      </div>
    </section>
  )
}

