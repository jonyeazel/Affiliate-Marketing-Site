"use client"

import { useState, type ReactNode } from "react"

interface HoverCardProps {
  children: ReactNode
  className?: string
  hoverEffect?: "lift" | "glow" | "border" | "scale" | "all"
}

export default function HoverCard({ children, className = "", hoverEffect = "all" }: HoverCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  const getEffectClasses = () => {
    const effects = {
      lift: "hover:-translate-y-1",
      glow: "hover:shadow-lg hover:shadow-cyan-500/20",
      border: "hover:border-cyan-500/50",
      scale: "hover:scale-[1.02]",
      all: "hover:-translate-y-1 hover:shadow-lg hover:shadow-cyan-500/20 hover:border-cyan-500/50 hover:scale-[1.02]",
    }

    return effects[hoverEffect]
  }

  return (
    <div
      className={`transition-all duration-300 ${getEffectClasses()} ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {children}
    </div>
  )
}

