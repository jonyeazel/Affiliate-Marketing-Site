"use client"

import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import { Check, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { PulseEffect } from "@/components/pulse-effect"

interface Step {
  number: number
  title: string
  description: string
  image: string
  features: string[]
}

export function HowItWorks() {
  const steps: Step[] = [
    {
      number: 1,
      title: "Sign Up & Create Profile",
      description: "Complete your profile in minutes and get matched with relevant brands.",
      image: "/placeholder.svg?height=300&width=400",
      features: ["Quick verification process", "AI-powered niche matching", "Personalized dashboard setup"],
    },
    {
      number: 2,
      title: "Choose Your Programs",
      description: "Browse and join high-converting affiliate programs that match your audience.",
      image: "/placeholder.svg?height=300&width=400",
      features: ["Filter by commission rate", "Sort by conversion potential", "One-click application"],
    },
    {
      number: 3,
      title: "Promote & Earn Instantly",
      description: "Share your unique links and get paid the moment a sale happens.",
      image: "/placeholder.svg?height=300&width=400",
      features: ["Instant commission payouts", "Real-time performance tracking", "Automated payment processing"],
    },
  ]

  return (
    <section id="how-it-works" className="py-24 bg-[#0A0A14]">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            HOW IT WORKS
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Three Simple Steps to Success
          </h2>
          <p className="text-base md:text-lg text-white/70">
            We've simplified affiliate marketing to its core. No complexity, no waiting, just results.
          </p>
        </div>

        <div className="space-y-24 md:space-y-32">
          {steps.map((step, index) => (
            <div
              key={step.number}
              className={`grid grid-cols-1 md:grid-cols-2 gap-12 items-center ${
                index % 2 === 1 ? "md:flex-row-reverse" : ""
              }`}
            >
              <motion.div
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className={`order-2 ${index % 2 === 1 ? "md:order-1" : "md:order-2"}`}
              >
                <div className="relative">
                  <div className="absolute -inset-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 rounded-lg blur-lg opacity-50"></div>
                  <div className="relative overflow-hidden rounded-lg border border-white/10">
                    <img
                      src={step.image || "/placeholder.svg"}
                      alt={`Step ${step.number}: ${step.title}`}
                      className="w-full h-auto object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A14] to-transparent opacity-60"></div>
                    <div className="absolute bottom-4 left-4 bg-[#00F0FF] text-[#0A0A14] font-bold text-xl h-12 w-12 rounded-full flex items-center justify-center">
                      {step.number}
                    </div>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: index % 2 === 0 ? 50 : -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className={`order-1 ${index % 2 === 1 ? "md:order-2" : "md:order-1"}`}
              >
                <h3 className="text-2xl md:text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
                  {step.title}
                </h3>
                <p className="text-lg text-white/70 mb-6">{step.description}</p>

                <ul className="space-y-3 mb-8">
                  {step.features.map((feature, i) => (
                    <motion.li
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.2, duration: 0.5 }}
                      className="flex items-start"
                    >
                      <div className="mr-3 mt-1 h-5 w-5 rounded-full bg-[#00F0FF]/20 flex items-center justify-center">
                        <Check className="h-3 w-3 text-[#00F0FF]" />
                      </div>
                      <span className="text-white/80">{feature}</span>
                    </motion.li>
                  ))}
                </ul>

                {step.number === steps.length && (
                  <Button
                    className="bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90 hover:scale-105 transition-all duration-300 group relative overflow-hidden"
                    onClick={() => {
                      const element = document.getElementById("signup")
                      if (element) {
                        element.scrollIntoView({ behavior: "smooth" })
                      }
                    }}
                  >
                    <span className="relative z-10">Get Started Now</span>
                    <ArrowRight className="relative z-10 ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                    <PulseEffect />
                  </Button>
                )}
              </motion.div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

