"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { MegaMenu } from "@/components/mega-menu"
import { MobileMenu } from "@/components/mobile-menu"
import { ContextNav } from "@/components/context-nav"

export function AdvancedHeader() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-50 w-full border-b transition-all duration-300 ${
        isScrolled
          ? "border-white/10 bg-[#0A0A14]/95 backdrop-blur supports-[backdrop-filter]:bg-[#0A0A14]/60 shadow-sm"
          : "border-transparent bg-[#0A0A14]/50"
      }`}
    >
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <div className="flex items-center gap-3">
          <Link href="/" className="flex items-center">
            <div className="relative w-8 h-8">
              <div className="absolute inset-0 bg-[#00F0FF] rounded-full blur-sm opacity-60"></div>
              <div className="relative w-8 h-8 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
                <span className="font-bold text-xs">AM</span>
              </div>
            </div>
            <span className="font-medium text-base tracking-tight ml-3">AffiliateMarketing</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex lg:ml-6">
            <MegaMenu />
          </div>
        </div>

        <div className="flex items-center">
          {/* Context Navigation (Search, Notifications, User Menu) */}
          <ContextNav />

          {/* Mobile Menu Toggle */}
          <div className="flex lg:hidden ml-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(true)}
              className="text-white hover:bg-white/10"
              aria-label="Open menu"
            >
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 lg:hidden"
            onClick={() => setIsMenuOpen(false)}
          >
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.3, ease: [0.32, 0.72, 0, 1] }}
              className="fixed inset-y-0 right-0 w-full max-w-xs bg-[#0A0A14] shadow-xl z-50 flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between p-4 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="relative w-8 h-8">
                    <div className="absolute inset-0 bg-[#00F0FF] rounded-full blur-sm opacity-60"></div>
                    <div className="relative w-8 h-8 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
                      <span className="font-bold text-xs">AM</span>
                    </div>
                  </div>
                  <span className="font-medium">AffiliateMarketing</span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsMenuOpen(false)}
                  className="text-white hover:bg-white/10"
                  aria-label="Close menu"
                >
                  <X className="h-6 w-6" />
                </Button>
              </div>

              <MobileMenu />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}

