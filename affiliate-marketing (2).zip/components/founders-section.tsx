"use client"

import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import { Linkedin, Twitter, Instagram, ExternalLink } from "lucide-react"

interface FounderProps {
  name: string
  role: string
  image: string
  bio: string
  links: {
    linkedin?: string
    twitter?: string
    instagram?: string
    website?: string
  }
  delay: number
}

const Founder = ({ name, role, image, bio, links, delay }: FounderProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="bg-white/5 rounded-xl overflow-hidden border border-white/10 hover:border-[#00F0FF]/30 hover:bg-white/10 transition-all duration-300 group"
    >
      <div className="relative h-64 overflow-hidden">
        <Image
          src={image || "/placeholder.svg"}
          alt={name}
          fill
          className="object-cover object-center group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A14] to-transparent opacity-70"></div>
      </div>
      <div className="p-6 relative">
        <h3 className="text-xl font-bold text-white mb-1">{name}</h3>
        <p className="text-[#00F0FF] font-medium text-sm mb-4">{role}</p>
        <p className="text-white/70 text-sm mb-6">{bio}</p>
        <div className="flex gap-3">
          {links.linkedin && (
            <Link
              href={links.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-colors"
            >
              <Linkedin className="h-4 w-4" />
            </Link>
          )}
          {links.twitter && (
            <Link
              href={links.twitter}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-colors"
            >
              <Twitter className="h-4 w-4" />
            </Link>
          )}
          {links.instagram && (
            <Link
              href={links.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-colors"
            >
              <Instagram className="h-4 w-4" />
            </Link>
          )}
          {links.website && (
            <Link
              href={links.website}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-colors"
            >
              <ExternalLink className="h-4 w-4" />
            </Link>
          )}
        </div>
      </div>
    </motion.div>
  )
}

export function FoundersSection() {
  const founders = [
    {
      name: "Dan Fleyshman",
      role: "Founder & CEO",
      image: "/images/founders/dan-fleyshman.png",
      bio: "Youngest founder of a publicly traded company. Angel investor in 37 companies and advisor to multiple billion-dollar brands.",
      links: {
        linkedin: "https://linkedin.com/in/danfleyshman",
        twitter: "https://twitter.com/danfleyshman",
        instagram: "https://instagram.com/danfleyshman",
      },
      delay: 0.1,
    },
    {
      name: "Brian Tate",
      role: "Co-Founder & CTO",
      image: "/images/founders/brian-tate.png",
      bio: "Serial tech entrepreneur with 15+ years experience building scalable platforms. Previously led engineering at multiple successful startups.",
      links: {
        linkedin: "https://linkedin.com/",
        twitter: "https://twitter.com/",
      },
      delay: 0.2,
    },
    {
      name: "Christy Buss",
      role: "Co-Founder & COO",
      image: "/images/founders/christy-buss.png",
      bio: "Operations expert with deep experience in scaling businesses. Previously managed operations for Fortune 500 companies and high-growth startups.",
      links: {
        linkedin: "https://linkedin.com/",
        instagram: "https://instagram.com/",
      },
      delay: 0.3,
    },
    {
      name: "Tiffany Hollywood",
      role: "Co-Founder & CMO",
      image: "/images/founders/tiffany-hollywood.png",
      bio: "Marketing strategist with expertise in brand development and growth marketing. Has helped scale multiple 8-figure businesses through affiliate partnerships.",
      links: {
        linkedin: "https://linkedin.com/",
        twitter: "https://twitter.com/",
        instagram: "https://instagram.com/",
      },
      delay: 0.4,
    },
  ]

  return (
    <section className="py-24 bg-[#0A0A14]">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            MEET THE TEAM
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            The Founders
          </h2>
          <p className="text-base md:text-lg text-white/70">
            Our team of industry veterans is dedicated to revolutionizing the affiliate marketing industry with
            transparency, innovation, and creator-first values.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {founders.map((founder) => (
            <Founder key={founder.name} {...founder} />
          ))}
        </div>
      </div>
    </section>
  )
}

