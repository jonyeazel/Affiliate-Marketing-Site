"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface Testimonial {
  id: number
  name: string
  role: string
  company: string
  avatar: string
  content: string
  rating: number
}

export default function TestimonialSlider() {
  const testimonials: Testimonial[] = [
    {
      id: 1,
      name: "Alex Morgan",
      role: "Content Creator",
      company: "TechReviews",
      avatar: "/placeholder.svg?height=40&width=40",
      content:
        "AffiliateMarketing.com transformed my approach to monetization. The AI recommendations helped me increase my conversion rate by 43% in just two months.",
      rating: 5,
    },
    {
      id: 2,
      name: "Sarah Johnson",
      role: "Marketing Director",
      company: "FashionBrand",
      avatar: "/placeholder.svg?height=40&width=40",
      content:
        "As a brand, finding the right affiliates was always challenging. This platform connected us with creators who truly understand our products and audience.",
      rating: 5,
    },
    {
      id: 3,
      name: "Michael Chen",
      role: "Affiliate Manager",
      company: "GadgetWorld",
      avatar: "/placeholder.svg?height=40&width=40",
      content:
        "The analytics and tracking capabilities are unmatched. I can finally see exactly what's working and optimize my campaigns in real-time.",
      rating: 4,
    },
  ]

  const [currentIndex, setCurrentIndex] = useState(0)
  const [autoplay, setAutoplay] = useState(true)

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length)
  }

  useEffect(() => {
    if (!autoplay) return

    const interval = setInterval(() => {
      nextSlide()
    }, 5000)

    return () => clearInterval(interval)
  }, [autoplay, currentIndex])

  return (
    <div className="relative mx-auto max-w-4xl">
      <div className="overflow-hidden">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="min-w-full border-none shadow-none">
              <CardContent className="pt-6">
                <div className="flex justify-center mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${i < testimonial.rating ? "text-yellow-400 fill-yellow-400" : "text-muted"}`}
                    />
                  ))}
                </div>
                <blockquote className="text-center text-xl font-medium leading-relaxed mb-6">
                  "{testimonial.content}"
                </blockquote>
              </CardContent>
              <CardFooter className="flex-col items-center">
                <Avatar className="h-12 w-12 mb-2">
                  <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                  <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <div className="font-medium">{testimonial.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {testimonial.role}, {testimonial.company}
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>

      <div className="mt-8 flex justify-center gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={() => {
            prevSlide()
            setAutoplay(false)
          }}
          className="rounded-full"
        >
          <ChevronLeft className="h-4 w-4" />
          <span className="sr-only">Previous</span>
        </Button>
        {testimonials.map((_, index) => (
          <Button
            key={index}
            variant="ghost"
            size="sm"
            onClick={() => {
              setCurrentIndex(index)
              setAutoplay(false)
            }}
            className={`h-2 min-w-8 rounded-full p-0 ${index === currentIndex ? "bg-primary" : "bg-muted"}`}
          >
            <span className="sr-only">Go to slide {index + 1}</span>
          </Button>
        ))}
        <Button
          variant="outline"
          size="icon"
          onClick={() => {
            nextSlide()
            setAutoplay(false)
          }}
          className="rounded-full"
        >
          <ChevronRight className="h-4 w-4" />
          <span className="sr-only">Next</span>
        </Button>
      </div>
    </div>
  )
}

