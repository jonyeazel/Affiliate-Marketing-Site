"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { usePathname } from "next/navigation"
import {
  Menu,
  X,
  ChevronDown,
  ChevronRight,
  Home,
  BarChart2,
  ShoppingBag,
  Users,
  FileText,
  Settings,
  HelpCircle,
  Zap,
  LogOut,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import ThemeToggle from "@/components/theme-toggle"

interface MenuItem {
  name: string
  href: string
  icon: React.ReactNode
  children?: MenuItem[]
}

export function MobileMenu() {
  const [isOpen, setIsOpen] = useState(false)
  const [expandedItems, setExpandedItems] = useState<string[]>([])
  const pathname = usePathname()
  const menuRef = useRef<HTMLDivElement>(null)

  // Close menu when route changes
  useEffect(() => {
    setIsOpen(false)
  }, [pathname])

  // Prevent scrolling when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
    }
    return () => {
      document.body.style.overflow = ""
    }
  }, [isOpen])

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node) && isOpen) {
        setIsOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [isOpen])

  const menuItems: MenuItem[] = [
    {
      name: "Home",
      href: "/",
      icon: <Home className="h-5 w-5" />,
    },
    {
      name: "Dashboard",
      href: "/dashboard",
      icon: <BarChart2 className="h-5 w-5" />,
    },
    {
      name: "Marketplace",
      href: "/marketplace",
      icon: <ShoppingBag className="h-5 w-5" />,
      children: [
        {
          name: "Browse Programs",
          href: "/marketplace/programs",
          icon: <ChevronRight className="h-4 w-4" />,
        },
        {
          name: "Top Offers",
          href: "/marketplace/top-offers",
          icon: <ChevronRight className="h-4 w-4" />,
        },
        {
          name: "Categories",
          href: "/marketplace/categories",
          icon: <ChevronRight className="h-4 w-4" />,
        },
        {
          name: "Brand Directory",
          href: "/marketplace/brands",
          icon: <ChevronRight className="h-4 w-4" />,
        },
      ],
    },
    {
      name: "Tools",
      href: "/tools",
      icon: <Zap className="h-5 w-5" />,
      children: [
        {
          name: "Link Generator",
          href: "/tools/link-generator",
          icon: <ChevronRight className="h-4 w-4" />,
        },
        {
          name: "Commission Calculator",
          href: "/tools/commission-calculator",
          icon: <ChevronRight className="h-4 w-4" />,
        },
        {
          name: "Performance Tracker",
          href: "/tools/performance-tracker",
          icon: <ChevronRight className="h-4 w-4" />,
        },
      ],
    },
    {
      name: "Community",
      href: "/community",
      icon: <Users className="h-5 w-5" />,
    },
    {
      name: "Blog",
      href: "/blog",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      name: "Settings",
      href: "/settings",
      icon: <Settings className="h-5 w-5" />,
    },
    {
      name: "Help",
      href: "/help",
      icon: <HelpCircle className="h-5 w-5" />,
    },
  ]

  const toggleExpanded = (name: string) => {
    setExpandedItems((prev) => (prev.includes(name) ? prev.filter((item) => item !== name) : [...prev, name]))
  }

  return (
    <>
      <div className="flex lg:hidden items-center gap-2">
        <ThemeToggle />
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsOpen(true)}
          className="text-white hover:bg-white/10 transition-colors"
          aria-label="Open menu"
        >
          <Menu className="h-6 w-6" />
        </Button>
      </div>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 lg:hidden"
              onClick={() => setIsOpen(false)}
            />

            <motion.div
              ref={menuRef}
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.3, ease: [0.32, 0.72, 0, 1] }}
              className="fixed inset-y-0 right-0 w-full max-w-xs bg-[#0A0A14] shadow-xl z-50 lg:hidden flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between p-4 border-b border-white/10 bg-gradient-to-r from-[#0A1A2F] to-[#0A0A14]">
                <div className="flex items-center gap-3">
                  <div className="relative w-8 h-8">
                    <div className="absolute inset-0 bg-[#00F0FF] rounded-full blur-sm opacity-60"></div>
                    <div className="relative w-8 h-8 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
                      <span className="font-bold text-xs">AM</span>
                    </div>
                  </div>
                  <span className="font-medium">AffiliateMarketing</span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="text-white hover:bg-white/10 transition-colors"
                  aria-label="Close menu"
                >
                  <X className="h-6 w-6" />
                </Button>
              </div>

              <div className="flex-1 overflow-y-auto py-2 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
                <nav className="px-2 space-y-1">
                  {menuItems.map((item, index) => (
                    <motion.div
                      key={item.name}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05, duration: 0.3 }}
                    >
                      {item.children ? (
                        <div>
                          <button
                            onClick={() => toggleExpanded(item.name)}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-sm font-medium ${
                              pathname?.startsWith(item.href)
                                ? "bg-gradient-to-r from-[#00F0FF]/20 to-transparent text-[#00F0FF]"
                                : "text-white/80 hover:bg-white/5 hover:text-white"
                            } transition-all duration-300`}
                          >
                            <div className="flex items-center gap-3">
                              {item.icon}
                              {item.name}
                            </div>
                            <ChevronDown
                              className={`h-4 w-4 transition-transform duration-300 ${
                                expandedItems.includes(item.name) ? "rotate-180" : ""
                              }`}
                            />
                          </button>

                          <AnimatePresence>
                            {expandedItems.includes(item.name) && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: "auto", opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.3, ease: [0.32, 0.72, 0, 1] }}
                                className="overflow-hidden"
                              >
                                <div className="pl-10 pr-3 py-1 space-y-1">
                                  {item.children.map((child) => (
                                    <Link
                                      key={child.name}
                                      href={child.href}
                                      className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm ${
                                        pathname === child.href
                                          ? "bg-gradient-to-r from-[#00F0FF]/20 to-transparent text-[#00F0FF]"
                                          : "text-white/70 hover:bg-white/5 hover:text-white"
                                      } transition-all duration-300`}
                                    >
                                      {child.icon}
                                      {child.name}
                                    </Link>
                                  ))}
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      ) : (
                        <Link
                          href={item.href}
                          className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium ${
                            pathname === item.href
                              ? "bg-gradient-to-r from-[#00F0FF]/20 to-transparent text-[#00F0FF]"
                              : "text-white/80 hover:bg-white/5 hover:text-white"
                          } transition-all duration-300`}
                        >
                          {item.icon}
                          {item.name}
                        </Link>
                      )}
                    </motion.div>
                  ))}
                </nav>
              </div>

              <div className="p-4 border-t border-white/10 bg-gradient-to-r from-[#0A1A2F]/50 to-[#0A0A14]/50">
                <Button
                  asChild
                  variant="default"
                  className="w-full bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90 transition-all duration-300"
                >
                  <Link href="/onboarding">Get Started</Link>
                </Button>

                <button className="flex items-center gap-3 w-full px-3 py-2 mt-4 rounded-md text-sm text-white/80 hover:bg-white/5 hover:text-white transition-all duration-300">
                  <LogOut className="h-5 w-5" />
                  Sign out
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}

