"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, X, Home, BarChart2, ShoppingBag, Users, Settings, LogOut } from "lucide-react"
import { usePathname } from "next/navigation"

export function MobileNavigation() {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  // Close menu when route changes
  useEffect(() => {
    setIsOpen(false)
  }, [pathname])

  // Prevent scrolling when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
    }

    return () => {
      document.body.style.overflow = ""
    }
  }, [isOpen])

  const navItems = [
    { name: "Home", href: "/", icon: Home },
    { name: "Dashboard", href: "/dashboard", icon: BarChart2 },
    { name: "Marketplace", href: "/marketplace", icon: ShoppingBag },
    { name: "Community", href: "/community", icon: Users },
    { name: "Settings", href: "/settings", icon: Settings },
  ]

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="lg:hidden fixed bottom-6 right-6 z-40 p-3 rounded-full bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white shadow-lg hover:opacity-90 transition-opacity focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 focus:ring-offset-gray-900"
        aria-label="Open navigation menu"
      >
        <Menu className="h-6 w-6" />
      </button>

      <div
        className={`fixed inset-0 z-50 lg:hidden bg-black/80 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={() => setIsOpen(false)}
      />

      <div
        className={`fixed inset-y-0 right-0 z-50 w-64 bg-[#0A0A14] shadow-xl transform transition-transform duration-300 ease-in-out lg:hidden ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <h2 className="text-xl font-bold text-white">Menu</h2>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 rounded-md text-white hover:bg-white/10 transition-colors"
            aria-label="Close navigation menu"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <nav className="p-4">
          <ul className="space-y-2">
            {navItems.map((item) => {
              const isActive = pathname === item.href
              const ItemIcon = item.icon

              return (
                <li key={item.name}>
                  <Link
                    href={item.href}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                      isActive ? "bg-[#00F0FF]/20 text-[#00F0FF]" : "text-white hover:bg-white/10"
                    }`}
                  >
                    <ItemIcon className="h-5 w-5" />
                    {item.name}
                  </Link>
                </li>
              )
            })}
          </ul>

          <div className="mt-8 pt-4 border-t border-white/10">
            <button className="flex items-center gap-3 px-3 py-2 w-full rounded-md text-white hover:bg-white/10 transition-colors">
              <LogOut className="h-5 w-5" />
              Sign out
            </button>
          </div>
        </nav>
      </div>
    </>
  )
}

