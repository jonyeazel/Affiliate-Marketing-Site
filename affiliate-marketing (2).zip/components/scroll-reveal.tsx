"use client"

import { useEffect, useRef, type ReactNode } from "react"

interface ScrollRevealProps {
  children: ReactNode
  className?: string
  delay?: number
  duration?: number
  distance?: string
  origin?: "top" | "right" | "bottom" | "left"
  reset?: boolean
}

export default function ScrollReveal({
  children,
  className = "",
  delay = 0,
  duration = 700,
  distance = "20px",
  origin = "bottom",
  reset = false,
}: ScrollRevealProps) {
  const elementRef = useRef<HTMLDivElement>(null)
  const initializedRef = useRef(false)

  useEffect(() => {
    const element = elementRef.current
    if (!element) return

    // Initial state
    const setInitialState = () => {
      const originMap = {
        top: { opacity: 0, transform: `translate3d(0, -${distance}, 0)` },
        right: { opacity: 0, transform: `translate3d(${distance}, 0, 0)` },
        bottom: { opacity: 0, transform: `translate3d(0, ${distance}, 0)` },
        left: { opacity: 0, transform: `translate3d(-${distance}, 0, 0)` },
      }

      Object.assign(element.style, {
        opacity: "0",
        transform: originMap[origin].transform,
        transition: `opacity ${duration}ms ease-out, transform ${duration}ms ease-out`,
        willChange: "opacity, transform",
      })
    }

    // Reveal element
    const revealElement = () => {
      const elementTop = element.getBoundingClientRect().top
      const elementBottom = element.getBoundingClientRect().bottom
      const isVisible = elementTop < window.innerHeight && elementBottom > 0

      if (isVisible) {
        setTimeout(() => {
          Object.assign(element.style, {
            opacity: "1",
            transform: "translate3d(0, 0, 0)",
          })
        }, delay)
      } else if (reset) {
        setInitialState()
      }
    }

    // Initialize
    if (!initializedRef.current) {
      setInitialState()
      initializedRef.current = true
    }

    // Add scroll listener
    window.addEventListener("scroll", revealElement, { passive: true })

    // Check initial position
    revealElement()

    return () => {
      window.removeEventListener("scroll", revealElement)
    }
  }, [delay, duration, distance, origin, reset])

  return (
    <div ref={elementRef} className={className}>
      {children}
    </div>
  )
}

