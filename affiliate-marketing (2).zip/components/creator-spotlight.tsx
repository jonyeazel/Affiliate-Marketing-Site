"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowUpRight, Trophy, TrendingUp, Zap, DollarSign } from "lucide-react"

interface Creator {
  id: number
  name: string
  username: string
  avatar: string
  earnings: number
  growth: number
  niche: string
  platforms: string[]
  bio: string
}

export default function CreatorSpotlight() {
  const creators: Creator[] = [
    {
      id: 1,
      name: "Mia Chen",
      username: "miacreates",
      avatar: "/placeholder.svg?height=100&width=100",
      earnings: 24893,
      growth: 43,
      niche: "Tech Reviews",
      platforms: ["TikTok", "YouTube", "Instagram"],
      bio: "Tech reviewer and gadget enthusiast. Sharing honest opinions on the latest products.",
    },
    {
      id: 2,
      name: "Jordan Williams",
      username: "jordanwilliams",
      avatar: "/placeholder.svg?height=100&width=100",
      earnings: 18762,
      growth: 28,
      niche: "Fitness & Wellness",
      platforms: ["Instagram", "TikTok"],
      bio: "Fitness coach helping you build sustainable habits. Join my 8-week transformation program.",
    },
    {
      id: 3,
      name: "Alex Rivera",
      username: "alexcreates",
      avatar: "/placeholder.svg?height=100&width=100",
      earnings: 32451,
      growth: 52,
      niche: "Personal Finance",
      platforms: ["YouTube", "Twitter", "TikTok"],
      bio: "Demystifying personal finance for Gen Z. Learn how to invest, save, and build wealth.",
    },
    {
      id: 4,
      name: "Taylor Kim",
      username: "taylorkim",
      avatar: "/placeholder.svg?height=100&width=100",
      earnings: 15932,
      growth: 37,
      niche: "Fashion & Style",
      platforms: ["Instagram", "TikTok Shop", "Pinterest"],
      bio: "Fashion stylist and trend forecaster. Creating looks that make you feel confident and authentic.",
    },
  ]

  const [activeCreator, setActiveCreator] = useState(0)

  const getPlatformBadge = (platform: string) => {
    switch (platform) {
      case "TikTok":
        return "bg-black text-white"
      case "TikTok Shop":
        return "bg-black text-white"
      case "Instagram":
        return "bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCAF45] text-white"
      case "YouTube":
        return "bg-[#FF0000] text-white"
      case "Twitter":
        return "bg-[#1DA1F2] text-white"
      case "Pinterest":
        return "bg-[#E60023] text-white"
      default:
        return "bg-gray-800 text-white"
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2">
        <Card className="bg-[#111111] border-white/10 overflow-hidden h-full">
          <CardContent className="p-0">
            <div className="relative aspect-video bg-gradient-to-br from-[#FF00FF]/20 to-[#00FFFF]/20">
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  key={creators[activeCreator].id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                  className="text-center"
                >
                  <Avatar className="h-32 w-32 mx-auto border-4 border-[#00FFFF] mb-4">
                    <AvatarImage src={creators[activeCreator].avatar} alt={creators[activeCreator].name} />
                    <AvatarFallback>{creators[activeCreator].name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <h3 className="text-2xl font-bold mb-1">{creators[activeCreator].name}</h3>
                  <p className="text-white/60 mb-4">@{creators[activeCreator].username}</p>

                  <div className="flex justify-center gap-2 mb-6">
                    {creators[activeCreator].platforms.map((platform) => (
                      <Badge key={platform} className={`${getPlatformBadge(platform)}`}>
                        {platform}
                      </Badge>
                    ))}
                  </div>

                  <p className="text-white/80 max-w-md mx-auto">{creators[activeCreator].bio}</p>
                </motion.div>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-[#191919] rounded-lg p-4">
                  <div className="flex items-center mb-2">
                    <DollarSign className="h-4 w-4 text-[#00FFFF] mr-2" />
                    <span className="text-white/60 text-sm">Weekly Earnings</span>
                  </div>
                  <div className="text-2xl font-bold">${creators[activeCreator].earnings.toLocaleString()}</div>
                </div>

                <div className="bg-[#191919] rounded-lg p-4">
                  <div className="flex items-center mb-2">
                    <TrendingUp className="h-4 w-4 text-[#FF00FF] mr-2" />
                    <span className="text-white/60 text-sm">Growth Rate</span>
                  </div>
                  <div className="text-2xl font-bold">+{creators[activeCreator].growth}%</div>
                </div>
              </div>

              <div className="mt-6">
                <Button className="w-full bg-gradient-to-r from-[#00FFFF] to-[#FF00FF] text-black font-bold">
                  View Full Profile
                  <ArrowUpRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-4 flex items-center">
          <Trophy className="h-5 w-5 text-[#FFFF00] mr-2" />
          Top Earners This Week
        </h3>

        <div className="space-y-3">
          {creators.map((creator, index) => (
            <div
              key={creator.id}
              className={`p-4 rounded-lg cursor-pointer transition-all ${
                activeCreator === index
                  ? "bg-gradient-to-r from-[#FF00FF]/20 to-[#00FFFF]/20 border border-white/10"
                  : "bg-[#111111] hover:bg-[#191919]"
              }`}
              onClick={() => setActiveCreator(index)}
            >
              <div className="flex items-center">
                <div className="relative">
                  <Avatar className="h-12 w-12 mr-3">
                    <AvatarImage src={creator.avatar} alt={creator.name} />
                    <AvatarFallback>{creator.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  {index === 0 && (
                    <div className="absolute -top-1 -right-1 bg-[#FFFF00] text-black rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                      1
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="font-medium truncate">{creator.name}</p>
                    <Badge variant="outline" className="border-[#00FFFF] text-[#00FFFF] ml-2">
                      <Zap className="mr-1 h-3 w-3" />
                      {creator.niche}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <p className="text-white/60 text-sm truncate">@{creator.username}</p>
                    <p className="font-bold text-[#00FFFF]">${creator.earnings.toLocaleString()}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

