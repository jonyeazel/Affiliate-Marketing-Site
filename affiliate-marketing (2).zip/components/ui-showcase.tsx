"use client"

import { useState } from "react"
import NextLink from "next/link"
import AnimatedElement from "@/components/animated-element"
import {
  Settings,
  User,
  ChevronRight,
  Bell,
  Mail,
  Phone,
  Share2,
  Download,
  Upload,
  Filter,
  Search,
  TrendingUp,
  BarChart,
  PieChart,
  LineChart,
  Users,
  UserPlus,
  UserMinus,
  UserCheck,
  UserX,
  Lock,
  Shield,
  AlertTriangle,
  AlertCircle,
  Info,
  Check,
  X,
  Plus,
  Minus,
  Edit,
  Trash,
  Copy,
  Save,
  RefreshCwIcon as Refresh,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  Menu,
  Home,
  Send,
  MessageSquare,
  MessageCircle,
  Image,
  Video,
  Music,
  Camera,
  Mic,
  Volume,
  VolumeX,
  Play,
  Pause,
  List,
  Grid,
  Share,
} from "lucide-react"

export default function UIShowcase() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("components")

  const iconGroups = [
    {
      title: "Navigation",
      icons: [
        Home,
        ChevronLeft,
        ChevronRight,
        ChevronUp,
        ChevronDown,
        ArrowLeft,
        ArrowRight,
        ArrowUp,
        ArrowDown,
        Menu,
        ExternalLink,
      ],
    },
    {
      title: "Actions",
      icons: [Plus, Minus, Check, X, Edit, Trash, Save, Copy, Download, Upload, Refresh, Search],
    },
    {
      title: "Communication",
      icons: [Mail, MessageSquare, MessageCircle, Send, Phone, Share, Share2, Bell],
    },
    {
      title: "Data",
      icons: [BarChart, PieChart, LineChart, TrendingUp, Filter, List, Grid],
    },
    {
      title: "Media",
      icons: [Image, Video, Music, Play, Pause, Volume, VolumeX, Camera, Mic],
    },
    {
      title: "User",
      icons: [User, Users, UserPlus, UserMinus, UserCheck, UserX, Settings, Lock, Shield],
    },
  ]

  const colorClasses = [
    "text-red-500",
    "text-orange-500",
    "text-amber-500",
    "text-yellow-500",
    "text-lime-500",
    "text-green-500",
    "text-emerald-500",
    "text-teal-500",
    "text-cyan-500",
    "text-sky-500",
    "text-blue-500",
    "text-indigo-500",
    "text-violet-500",
    "text-purple-500",
    "text-fuchsia-500",
    "text-pink-500",
    "text-rose-500",
  ]

  const buttonVariants = [
    {
      name: "Primary",
      className: "bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90",
    },
    {
      name: "Secondary",
      className: "bg-white/10 text-white hover:bg-white/20",
    },
    {
      name: "Outline",
      className: "border border-white/20 text-white hover:bg-white/10",
    },
    {
      name: "Ghost",
      className: "text-white hover:bg-white/10",
    },
    {
      name: "Destructive",
      className: "bg-red-600 text-white hover:bg-red-700",
    },
  ]

  return (
    <div className="min-h-screen bg-[#0A0A14] text-white py-12">
      <div className="container mx-auto px-4">
        <AnimatedElement animation="fade-in" className="mb-12 text-center">
          <h1 className="text-4xl font-bold mb-4">UI Showcase</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            A comprehensive showcase of all UI elements available for your affiliate marketing website.
          </p>
        </AnimatedElement>

        <div className="flex justify-center mb-8">
          <div className="bg-white/5 rounded-lg p-1 flex">
            {["components", "colors", "typography", "icons"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-md transition-colors ${
                  activeTab === tab ? "bg-[#00F0FF] text-[#0A0A14]" : "text-white hover:bg-white/10"
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {activeTab === "components" && (
          <div className="space-y-12">
            <AnimatedElement animation="slide-up" delay={200}>
              <h2 className="text-2xl font-bold mb-6 border-b border-white/10 pb-2">Buttons</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {buttonVariants.map((variant) => (
                  <div key={variant.name} className="bg-white/5 rounded-lg p-6">
                    <h3 className="text-lg font-medium mb-4">{variant.name}</h3>
                    <div className="space-y-4">
                      <button className={`px-4 py-2 rounded-md transition-colors ${variant.className}`}>Button</button>
                      <button
                        className={`px-4 py-2 rounded-md transition-colors ${variant.className} flex items-center gap-2`}
                      >
                        <Plus className="h-4 w-4" />
                        With Icon
                      </button>
                      <button
                        className={`px-4 py-2 rounded-md transition-colors ${variant.className} opacity-50 cursor-not-allowed`}
                      >
                        Disabled
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </AnimatedElement>

            <AnimatedElement animation="slide-up" delay={400}>
              <h2 className="text-2xl font-bold mb-6 border-b border-white/10 pb-2">Form Elements</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white/5 rounded-lg p-6">
                  <h3 className="text-lg font-medium mb-4">Text Inputs</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">Standard Input</label>
                      <input
                        type="text"
                        className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-white/50 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all duration-200"
                        placeholder="Enter text..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">With Icon</label>
                      <div className="relative">
                        <input
                          type="text"
                          className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-md text-white placeholder-white/50 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all duration-200"
                          placeholder="Search..."
                        />
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">Disabled</label>
                      <input
                        type="text"
                        className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-md text-white/50 placeholder-white/30 cursor-not-allowed"
                        placeholder="Disabled input"
                        disabled
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 rounded-lg p-6">
                  <h3 className="text-lg font-medium mb-4">Selects & Checkboxes</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">Select</label>
                      <select className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-md text-white focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all duration-200">
                        <option value="option1">Option 1</option>
                        <option value="option2">Option 2</option>
                        <option value="option3">Option 3</option>
                      </select>
                    </div>
                    <div>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          className="h-4 w-4 rounded border-white/10 bg-white/5 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-gray-900"
                        />
                        <span className="text-sm text-white">Checkbox</span>
                      </label>
                    </div>
                    <div>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="radio-group"
                          className="h-4 w-4 border-white/10 bg-white/5 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-gray-900"
                        />
                        <span className="text-sm text-white">Radio Button</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </AnimatedElement>

            <AnimatedElement animation="slide-up" delay={600}>
              <h2 className="text-2xl font-bold mb-6 border-b border-white/10 pb-2">Cards & Containers</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white/5 rounded-lg border border-white/10 p-6 hover:border-cyan-500/50 transition-colors">
                  <h3 className="text-lg font-medium mb-2">Standard Card</h3>
                  <p className="text-gray-400">A simple card with some content and a hover effect.</p>
                </div>

                <div className="glass rounded-lg p-6">
                  <h3 className="text-lg font-medium mb-2">Glass Card</h3>
                  <p className="text-gray-400">A card with a glassmorphism effect.</p>
                </div>

                <div className="bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-lg border border-white/10 p-6">
                  <h3 className="text-lg font-medium mb-2">Gradient Card</h3>
                  <p className="text-gray-400">A card with a subtle gradient background.</p>
                </div>
              </div>
            </AnimatedElement>

            <AnimatedElement animation="slide-up" delay={800}>
              <h2 className="text-2xl font-bold mb-6 border-b border-white/10 pb-2">Alerts & Notifications</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-green-500/20 border-l-4 border-green-500 rounded-r-lg p-4 flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                  <div>
                    <h3 className="text-green-500 font-medium">Success Alert</h3>
                    <p className="text-gray-300">Your changes have been saved successfully.</p>
                  </div>
                </div>

                <div className="bg-red-500/20 border-l-4 border-red-500 rounded-r-lg p-4 flex items-start">
                  <AlertTriangle className="h-5 w-5 text-red-500 mr-3 mt-0.5" />
                  <div>
                    <h3 className="text-red-500 font-medium">Error Alert</h3>
                    <p className="text-gray-300">There was a problem processing your request.</p>
                  </div>
                </div>

                <div className="bg-yellow-500/20 border-l-4 border-yellow-500 rounded-r-lg p-4 flex items-start">
                  <AlertCircle className="h-5 w-5 text-yellow-500 mr-3 mt-0.5" />
                  <div>
                    <h3 className="text-yellow-500 font-medium">Warning Alert</h3>
                    <p className="text-gray-300">Your account is approaching its storage limit.</p>
                  </div>
                </div>

                <div className="bg-blue-500/20 border-l-4 border-blue-500 rounded-r-lg p-4 flex items-start">
                  <Info className="h-5 w-5 text-blue-500 mr-3 mt-0.5" />
                  <div>
                    <h3 className="text-blue-500 font-medium">Info Alert</h3>
                    <p className="text-gray-300">A new version of the application is available.</p>
                  </div>
                </div>
              </div>
            </AnimatedElement>
          </div>
        )}

        {activeTab === "colors" && (
          <AnimatedElement animation="fade-in">
            <h2 className="text-2xl font-bold mb-6 border-b border-white/10 pb-2">Color Palette</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {colorClasses.map((colorClass, index) => (
                <div key={index} className="bg-white/5 rounded-lg overflow-hidden">
                  <div className={`h-24 ${colorClass.replace("text-", "bg-")}`} />
                  <div className="p-4">
                    <p className={`font-medium ${colorClass}`}>{colorClass.split("-")[1]}</p>
                    <p className="text-sm text-gray-400">{colorClass}</p>
                  </div>
                </div>
              ))}
            </div>
          </AnimatedElement>
        )}

        {activeTab === "typography" && (
          <AnimatedElement animation="fade-in">
            <h2 className="text-2xl font-bold mb-6 border-b border-white/10 pb-2">Typography</h2>
            <div className="space-y-8">
              <div className="bg-white/5 rounded-lg p-6">
                <h3 className="text-lg font-medium mb-4">Headings</h3>
                <div className="space-y-4">
                  <h1 className="text-4xl font-bold">Heading 1</h1>
                  <h2 className="text-3xl font-bold">Heading 2</h2>
                  <h3 className="text-2xl font-bold">Heading 3</h3>
                  <h4 className="text-xl font-bold">Heading 4</h4>
                  <h5 className="text-lg font-bold">Heading 5</h5>
                  <h6 className="text-base font-bold">Heading 6</h6>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-6">
                <h3 className="text-lg font-medium mb-4">Text Styles</h3>
                <div className="space-y-4">
                  <p className="text-base">
                    Regular paragraph text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </p>
                  <p className="text-sm">Small text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                  <p className="text-xs">Extra small text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                  <p className="text-lg">Large text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                  <p className="text-xl">Extra large text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                  <p className="font-bold">Bold text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                  <p className="italic">Italic text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                  <p className="underline">Underlined text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                  <p className="line-through">
                    Strikethrough text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </p>
                  <p className="text-gradient">
                    Gradient text. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </p>
                </div>
              </div>
            </div>
          </AnimatedElement>
        )}

        {activeTab === "icons" && (
          <AnimatedElement animation="fade-in">
            <h2 className="text-2xl font-bold mb-6 border-b border-white/10 pb-2">Icons</h2>
            <div className="space-y-8">
              {iconGroups.map((group) => (
                <div key={group.title} className="bg-white/5 rounded-lg p-6">
                  <h3 className="text-lg font-medium mb-4">{group.title}</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4">
                    {group.icons.map((Icon, index) => (
                      <div
                        key={index}
                        className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors"
                      >
                        <Icon className="h-6 w-6 text-cyan-500 mb-2" />
                        <span className="text-xs text-gray-400">{Icon.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </AnimatedElement>
        )}

        <AnimatedElement animation="fade-in" delay={1000} className="mt-12 text-center">
          <NextLink
            href="/"
            className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white rounded-md hover:opacity-90 transition-opacity"
          >
            Back to Home
            <ChevronRight className="ml-2 h-4 w-4" />
          </NextLink>
        </AnimatedElement>
      </div>
    </div>
  )
}

