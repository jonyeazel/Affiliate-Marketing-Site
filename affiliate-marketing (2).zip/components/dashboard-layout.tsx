"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Home,
  BarChart2,
  LinkIcon,
  ShoppingBag,
  Users,
  Settings,
  Bell,
  Search,
  Menu,
  X,
  ChevronRight,
  HelpCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { motion, AnimatePresence } from "framer-motion"
import ThemeToggle from "@/components/theme-toggle"

interface DashboardLayoutProps {
  children: React.ReactNode
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false)
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const pathname = usePathname()

  // Close mobile sidebar on route change
  useEffect(() => {
    setIsMobileSidebarOpen(false)
  }, [pathname])

  // Close mobile sidebar on window resize
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileSidebarOpen(false)
      }
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const navItems = [
    { name: "Dashboard", href: "/dashboard", icon: Home },
    { name: "Analytics", href: "/dashboard/analytics", icon: BarChart2 },
    { name: "Links", href: "/dashboard/links", icon: LinkIcon },
    { name: "Programs", href: "/dashboard/programs", icon: ShoppingBag },
    { name: "Community", href: "/dashboard/community", icon: Users },
    { name: "Settings", href: "/dashboard/settings", icon: Settings },
  ]

  const notifications = [
    {
      id: 1,
      title: "New commission earned",
      description: "You earned $45.00 from TechGear",
      time: "5 minutes ago",
      unread: true,
    },
    {
      id: 2,
      title: "Program application approved",
      description: "Your application to join GlowUp was approved",
      time: "2 hours ago",
      unread: true,
    },
    {
      id: 3,
      title: "New feature available",
      description: "Check out our new link tracking dashboard",
      time: "Yesterday",
      unread: false,
    },
  ]

  const searchResults = [
    { type: "Link", name: "TechGear Headphones", href: "/dashboard/links/tech-123" },
    { type: "Program", name: "GlowUp Beauty", href: "/dashboard/programs/glowup" },
    { type: "Setting", name: "Payment Methods", href: "/dashboard/settings/payments" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Sidebar Toggle */}
      <button
        onClick={() => setIsMobileSidebarOpen(true)}
        className="lg:hidden fixed bottom-6 left-6 z-40 p-3 rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
        aria-label="Open sidebar"
      >
        <Menu className="h-6 w-6" />
      </button>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isMobileSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm lg:hidden"
            onClick={() => setIsMobileSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-background border-r border-border transform transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isMobileSidebarOpen ? "translate-x-0" : "-translate-x-full"
        } ${isSidebarOpen ? "lg:w-64" : "lg:w-20"}`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="flex items-center justify-between h-16 px-4 border-b border-border">
            <Link href="/" className={`flex items-center ${!isSidebarOpen && "lg:justify-center"}`}>
              {isSidebarOpen || isMobileSidebarOpen ? (
                <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[#00F0FF] to-[#0033CC]">
                  AffiliateMarketing
                </span>
              ) : (
                <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[#00F0FF] to-[#0033CC]">
                  AM
                </span>
              )}
            </Link>

            <div className="flex items-center">
              <button
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="hidden lg:block p-1 rounded-md text-foreground/60 hover:text-foreground hover:bg-accent transition-colors"
                aria-label={isSidebarOpen ? "Collapse sidebar" : "Expand sidebar"}
              >
                <ChevronRight className={`h-5 w-5 transition-transform ${isSidebarOpen ? "rotate-180" : ""}`} />
              </button>

              <button
                onClick={() => setIsMobileSidebarOpen(false)}
                className="lg:hidden p-1 rounded-md text-foreground/60 hover:text-foreground hover:bg-accent transition-colors"
                aria-label="Close sidebar"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto py-4 px-3">
            <ul className="space-y-1">
              {navItems.map((item) => {
                const isActive = pathname === item.href
                const Icon = item.icon

                return (
                  <li key={item.name}>
                    <Link
                      href={item.href}
                      className={`flex items-center px-3 py-2 rounded-md transition-colors ${
                        isActive
                          ? "bg-primary/10 text-primary"
                          : "text-foreground/70 hover:text-foreground hover:bg-accent"
                      }`}
                    >
                      <Icon className="h-5 w-5 flex-shrink-0" />
                      {(isSidebarOpen || isMobileSidebarOpen) && <span className="ml-3">{item.name}</span>}
                    </Link>
                  </li>
                )
              })}
            </ul>
          </nav>

          {/* Sidebar Footer */}
          <div className="p-4 border-t border-border">
            <div className={`flex ${isSidebarOpen || isMobileSidebarOpen ? "items-center" : "flex-col items-center"}`}>
              <Avatar className="h-10 w-10">
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>

              {(isSidebarOpen || isMobileSidebarOpen) && (
                <div className="ml-3">
                  <p className="text-sm font-medium">Jordan Doe</p>
                  <p className="text-xs text-foreground/60">Pro Plan</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className={`transition-all duration-300 ${isSidebarOpen ? "lg:pl-64" : "lg:pl-20"}`}>
        {/* Header */}
        <header className="sticky top-0 z-30 h-16 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border flex items-center px-4">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center">
              <h1 className="text-xl font-semibold">
                {pathname === "/dashboard"
                  ? "Dashboard"
                  : pathname === "/dashboard/analytics"
                    ? "Analytics"
                    : pathname === "/dashboard/links"
                      ? "Links"
                      : pathname === "/dashboard/programs"
                        ? "Programs"
                        : pathname === "/dashboard/community"
                          ? "Community"
                          : pathname === "/dashboard/settings"
                            ? "Settings"
                            : "Dashboard"}
              </h1>
            </div>

            <div className="flex items-center space-x-4">
              {/* Search */}
              <div className="relative">
                <button
                  onClick={() => setIsSearchOpen(!isSearchOpen)}
                  className="p-2 rounded-md text-foreground/60 hover:text-foreground hover:bg-accent transition-colors"
                  aria-label="Search"
                >
                  <Search className="h-5 w-5" />
                </button>

                <AnimatePresence>
                  {isSearchOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      transition={{ duration: 0.2 }}
                      className="absolute right-0 mt-2 w-72 bg-background border border-border rounded-md shadow-lg z-10"
                    >
                      <div className="p-2">
                        <Input type="search" placeholder="Search..." className="w-full" autoFocus />
                      </div>

                      <div className="border-t border-border py-2">
                        {searchResults.length > 0 ? (
                          <ul>
                            {searchResults.map((result, index) => (
                              <li key={index}>
                                <Link
                                  href={result.href}
                                  className="flex items-center px-4 py-2 hover:bg-accent transition-colors"
                                  onClick={() => setIsSearchOpen(false)}
                                >
                                  <Badge variant="outline" className="mr-2">
                                    {result.type}
                                  </Badge>
                                  <span>{result.name}</span>
                                </Link>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="px-4 py-2 text-foreground/60 text-sm">No results found</p>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Notifications */}
              <div className="relative">
                <button
                  onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                  className="p-2 rounded-md text-foreground/60 hover:text-foreground hover:bg-accent transition-colors"
                  aria-label="Notifications"
                >
                  <Bell className="h-5 w-5" />
                  {notifications.some((n) => n.unread) && (
                    <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full" />
                  )}
                </button>

                <AnimatePresence>
                  {isNotificationsOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      transition={{ duration: 0.2 }}
                      className="absolute right-0 mt-2 w-80 bg-background border border-border rounded-md shadow-lg z-10"
                    >
                      <div className="flex items-center justify-between px-4 py-2 border-b border-border">
                        <h3 className="font-medium">Notifications</h3>
                        <Button variant="ghost" size="sm" className="text-xs">
                          Mark all as read
                        </Button>
                      </div>

                      <div className="max-h-80 overflow-y-auto">
                        {notifications.length > 0 ? (
                          <ul>
                            {notifications.map((notification) => (
                              <li key={notification.id} className="border-b border-border last:border-0">
                                <a
                                  href="#"
                                  className="block px-4 py-3 hover:bg-accent transition-colors"
                                  onClick={(e) => {
                                    e.preventDefault()
                                    setIsNotificationsOpen(false)
                                  }}
                                >
                                  <div className="flex items-start">
                                    <div className="flex-1 min-w-0">
                                      <p className="text-sm font-medium flex items-center">
                                        {notification.title}
                                        {notification.unread && (
                                          <span className="ml-2 w-2 h-2 bg-primary rounded-full" />
                                        )}
                                      </p>
                                      <p className="text-xs text-foreground/60 mt-1">{notification.description}</p>
                                      <p className="text-xs text-foreground/40 mt-1">{notification.time}</p>
                                    </div>
                                  </div>
                                </a>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="px-4 py-3 text-foreground/60 text-sm">No notifications</p>
                        )}
                      </div>

                      <div className="border-t border-border p-2">
                        <Button variant="ghost" size="sm" className="w-full text-xs">
                          View all notifications
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Theme Toggle */}
              <ThemeToggle />

              {/* Help */}
              <button
                className="p-2 rounded-md text-foreground/60 hover:text-foreground hover:bg-accent transition-colors"
                aria-label="Help"
              >
                <HelpCircle className="h-5 w-5" />
              </button>

              {/* User Menu */}
              <div className="relative">
                <Avatar className="h-8 w-8 cursor-pointer">
                  <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}

