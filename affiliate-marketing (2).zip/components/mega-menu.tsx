"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { usePathname } from "next/navigation"
import {
  ChevronDown,
  BarChart2,
  ShoppingBag,
  Zap,
  DollarSign,
  Award,
  TrendingUp,
  Layers,
  Gift,
  Star,
  Clock,
  Compass,
  Heart,
  PieChart,
  Target,
} from "lucide-react"

interface MegaMenuItem {
  name: string
  href: string
  icon: React.ReactNode
  description?: string
}

interface MegaMenuSection {
  title: string
  items: MegaMenuItem[]
}

interface MegaMenuProps {
  sections: MegaMenuSection[]
  featuredItems?: MegaMenuItem[]
  title: string
  description: string
}

export function MegaMenu() {
  const [activeMenu, setActiveMenu] = useState<string | null>(null)
  const pathname = usePathname()
  const menuRef = useRef<HTMLDivElement>(null)

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setActiveMenu(null)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // Close menu when route changes
  useEffect(() => {
    setActiveMenu(null)
  }, [pathname])

  const megaMenus: Record<string, MegaMenuProps> = {
    marketplace: {
      title: "Affiliate Marketplace",
      description: "Discover and join the best affiliate programs for your audience",
      sections: [
        {
          title: "Browse Programs",
          items: [
            {
              name: "All Programs",
              href: "/marketplace/programs",
              icon: <Compass className="h-5 w-5" />,
              description: "Browse all available affiliate programs",
            },
            {
              name: "Top Rated",
              href: "/marketplace/top-rated",
              icon: <Star className="h-5 w-5" />,
              description: "Programs with the highest ratings",
            },
            {
              name: "New Arrivals",
              href: "/marketplace/new",
              icon: <Clock className="h-5 w-5" />,
              description: "Recently added affiliate programs",
            },
            {
              name: "Trending",
              href: "/marketplace/trending",
              icon: <TrendingUp className="h-5 w-5" />,
              description: "Programs gaining popularity",
            },
          ],
        },
        {
          title: "Categories",
          items: [
            {
              name: "Health & Wellness",
              href: "/marketplace/categories/health",
              icon: <Heart className="h-5 w-5" />,
              description: "Fitness, nutrition, and wellness products",
            },
            {
              name: "Tech & Software",
              href: "/marketplace/categories/tech",
              icon: <Layers className="h-5 w-5" />,
              description: "Digital products and software services",
            },
            {
              name: "Fashion & Beauty",
              href: "/marketplace/categories/fashion",
              icon: <ShoppingBag className="h-5 w-5" />,
              description: "Clothing, accessories, and beauty products",
            },
            {
              name: "Finance",
              href: "/marketplace/categories/finance",
              icon: <DollarSign className="h-5 w-5" />,
              description: "Financial services and products",
            },
          ],
        },
      ],
      featuredItems: [
        {
          name: "Exclusive Partnerships",
          href: "/marketplace/exclusive",
          icon: <Award className="h-5 w-5" />,
          description: "Premium programs with higher commissions",
        },
        {
          name: "Seasonal Promotions",
          href: "/marketplace/seasonal",
          icon: <Gift className="h-5 w-5" />,
          description: "Limited-time offers with bonus incentives",
        },
      ],
    },
    tools: {
      title: "Affiliate Tools",
      description: "Powerful tools to maximize your affiliate marketing success",
      sections: [
        {
          title: "Link Management",
          items: [
            {
              name: "Link Generator",
              href: "/tools/link-generator",
              icon: <Zap className="h-5 w-5" />,
              description: "Create and manage affiliate links",
            },
            {
              name: "Link Analytics",
              href: "/tools/link-analytics",
              icon: <BarChart2 className="h-5 w-5" />,
              description: "Track performance of your links",
            },
            {
              name: "Deep Linking",
              href: "/tools/deep-linking",
              icon: <Target className="h-5 w-5" />,
              description: "Create links to specific product pages",
            },
          ],
        },
        {
          title: "Performance",
          items: [
            {
              name: "Commission Calculator",
              href: "/tools/commission-calculator",
              icon: <DollarSign className="h-5 w-5" />,
              description: "Calculate potential earnings",
            },
            {
              name: "Performance Dashboard",
              href: "/tools/performance-dashboard",
              icon: <PieChart className="h-5 w-5" />,
              description: "Visualize your affiliate performance",
            },
            {
              name: "Conversion Optimizer",
              href: "/tools/conversion-optimizer",
              icon: <TrendingUp className="h-5 w-5" />,
              description: "Improve your conversion rates",
            },
          ],
        },
      ],
      featuredItems: [
        {
          name: "AI Content Generator",
          href: "/tools/ai-content",
          icon: <Zap className="h-5 w-5" />,
          description: "Create affiliate content with AI assistance",
        },
      ],
    },
  }

  const handleMenuToggle = (menuName: string) => {
    setActiveMenu(activeMenu === menuName ? null : menuName)
  }

  return (
    <div className="hidden lg:block" ref={menuRef}>
      <div className="flex items-center space-x-1">
        <button
          onClick={() => handleMenuToggle("marketplace")}
          className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-300 ${
            pathname?.startsWith("/marketplace")
              ? "text-[#00F0FF] bg-white/5"
              : "text-white/80 hover:text-white hover:bg-white/5"
          }`}
        >
          Marketplace
          <ChevronDown
            className={`ml-1 h-4 w-4 transition-transform duration-300 ${
              activeMenu === "marketplace" ? "rotate-180" : ""
            }`}
          />
        </button>

        <button
          onClick={() => handleMenuToggle("tools")}
          className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-300 ${
            pathname?.startsWith("/tools")
              ? "text-[#00F0FF] bg-white/5"
              : "text-white/80 hover:text-white hover:bg-white/5"
          }`}
        >
          Tools
          <ChevronDown
            className={`ml-1 h-4 w-4 transition-transform duration-300 ${activeMenu === "tools" ? "rotate-180" : ""}`}
          />
        </button>

        <Link
          href="/community"
          className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-300 ${
            pathname === "/community" ? "text-[#00F0FF] bg-white/5" : "text-white/80 hover:text-white hover:bg-white/5"
          }`}
        >
          Community
        </Link>

        <Link
          href="/blog"
          className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-300 ${
            pathname === "/blog" ? "text-[#00F0FF] bg-white/5" : "text-white/80 hover:text-white hover:bg-white/5"
          }`}
        >
          Blog
        </Link>
      </div>

      <AnimatePresence>
        {activeMenu && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
              onClick={() => setActiveMenu(null)}
              style={{ pointerEvents: "auto" }}
            />

            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="absolute left-0 right-0 mt-2 mx-auto max-w-7xl bg-[#0A0A14] border border-white/10 rounded-lg shadow-2xl z-50 overflow-hidden"
              style={{ transformOrigin: "top center" }}
            >
              <div className="p-6 grid grid-cols-12 gap-8">
                {/* Header */}
                <div className="col-span-12 mb-4 border-b border-white/10 pb-4">
                  <h3 className="text-xl font-bold text-white">{megaMenus[activeMenu].title}</h3>
                  <p className="text-white/60 mt-1">{megaMenus[activeMenu].description}</p>
                </div>

                {/* Main sections */}
                {megaMenus[activeMenu].sections.map((section, index) => (
                  <div key={section.title} className="col-span-3">
                    <h4 className="font-medium text-[#00F0FF] mb-3">{section.title}</h4>
                    <ul className="space-y-2">
                      {section.items.map((item) => (
                        <li key={item.name}>
                          <Link
                            href={item.href}
                            className="flex items-start gap-2 p-2 rounded-md hover:bg-white/5 transition-colors group"
                          >
                            <div className="mt-0.5 text-white/60 group-hover:text-[#00F0FF] transition-colors">
                              {item.icon}
                            </div>
                            <div>
                              <div className="font-medium text-white group-hover:text-[#00F0FF] transition-colors">
                                {item.name}
                              </div>
                              {item.description && (
                                <p className="text-xs text-white/60 mt-0.5 group-hover:text-white/80 transition-colors">
                                  {item.description}
                                </p>
                              )}
                            </div>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}

                {/* Featured items */}
                {megaMenus[activeMenu].featuredItems && (
                  <div className="col-span-3">
                    <h4 className="font-medium text-[#00F0FF] mb-3">Featured</h4>
                    <div className="bg-gradient-to-br from-[#0A1A2F] to-[#0A0A14] rounded-lg p-4 border border-white/10">
                      {megaMenus[activeMenu].featuredItems.map((item) => (
                        <Link
                          key={item.name}
                          href={item.href}
                          className="flex flex-col gap-2 p-3 rounded-md hover:bg-white/5 transition-colors mb-3 last:mb-0"
                        >
                          <div className="flex items-center gap-2">
                            <div className="text-[#00F0FF]">{item.icon}</div>
                            <div className="font-medium text-white">{item.name}</div>
                          </div>
                          {item.description && <p className="text-sm text-white/60">{item.description}</p>}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-gradient-to-r from-[#0A1A2F] to-[#0A0A14] p-4 border-t border-white/10 flex justify-between items-center">
                <p className="text-sm text-white/60">
                  Explore all options in the <span className="text-[#00F0FF]">{megaMenus[activeMenu].title}</span>{" "}
                  section
                </p>
                <Link
                  href={`/${activeMenu}`}
                  className="text-sm text-[#00F0FF] hover:underline"
                  onClick={() => setActiveMenu(null)}
                >
                  View All
                </Link>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}

