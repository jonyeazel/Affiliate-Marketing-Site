"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { usePathname } from "next/navigation"
import { MobileNavigation } from "./mobile-navigation"
import AffiliateMarketingLogo from "./affiliate-marketing-logo"

interface NavItem {
  label: string
  href: string
}

export function MainNavigation() {
  const [scrolled, setScrolled] = useState(false)
  const pathname = usePathname()

  const navItems: NavItem[] = [
    { label: "Home", href: "/" },
    { label: "Features", href: "#features" },
    { label: "How It Works", href: "#how-it-works" },
    { label: "Testimonials", href: "#testimonials" },
    { label: "FAQ", href: "#faq" },
  ]

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 20
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [scrolled])

  const isActive = (href: string) => {
    if (href === "/") return pathname === "/"
    return pathname?.includes(href) || false
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-black/90 backdrop-blur-md py-3 shadow-lg" : "bg-transparent py-5"
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/" className="flex items-center">
          <AffiliateMarketingLogo size="md" className="h-10 w-auto" />
        </Link>

        <nav className="hidden md:flex items-center space-x-1">
          {navItems.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={`relative px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                isActive(item.href) ? "text-[#00F0FF]" : "text-white/80 hover:text-white"
              }`}
            >
              {item.label}
              {isActive(item.href) && (
                <motion.div
                  layoutId="activeNavIndicator"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#00F0FF]"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.2 }}
                />
              )}
            </Link>
          ))}
          <Link
            href="#signup"
            className="ml-4 px-5 py-2 text-sm font-medium bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white rounded-md hover:shadow-lg hover:shadow-[#00F0FF]/20 transition-all duration-300"
          >
            Join Waitlist
          </Link>
        </nav>

        <MobileNavigation />
      </div>
    </header>
  )
}

