"use client"

import { motion } from "framer-motion"
import { Check, X, Info } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useState, useEffect } from "react"

interface ComparisonFeature {
  name: string
  affiliateMarketing: boolean
  traditional: boolean
  highlight?: boolean
  tooltip?: string
}

export function ComparisonTable() {
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)

    return () => {
      window.removeEventListener("resize", checkMobile)
    }
  }, [])

  const features: ComparisonFeature[] = [
    {
      name: "Instant Payments",
      affiliateMarketing: true,
      traditional: false,
      highlight: true,
      tooltip: "Get paid immediately when a sale is made, no waiting periods",
    },
    {
      name: "AI-Powered Matching",
      affiliateMarketing: true,
      traditional: false,
      highlight: true,
      tooltip: "Our AI matches you with the perfect programs based on your audience and niche",
    },
    {
      name: "Verified Traffic Analytics",
      affiliateMarketing: true,
      traditional: false,
      tooltip: "Real-time, accurate traffic and conversion data you can trust",
    },
    {
      name: "Unified Dashboard",
      affiliateMarketing: true,
      traditional: false,
      tooltip: "Manage all your programs, links, and earnings in one place",
    },
    {
      name: "Digital Credential Card",
      affiliateMarketing: true,
      traditional: false,
      highlight: true,
      tooltip: "Showcase your affiliate status with our digital credential cards",
    },
    {
      name: "Community Access",
      affiliateMarketing: true,
      traditional: true,
      tooltip: "Connect with other affiliates and learn from the best",
    },
    {
      name: "Performance Tracking",
      affiliateMarketing: true,
      traditional: true,
      tooltip: "Track your performance across all your campaigns",
    },
    {
      name: "Mobile App",
      affiliateMarketing: true,
      traditional: false,
      tooltip: "Manage your affiliate business on the go with our dedicated mobile app",
    },
    {
      name: "24/7 Support",
      affiliateMarketing: true,
      traditional: false,
      tooltip: "Get help whenever you need it with our round-the-clock support team",
    },
    {
      name: "No Minimum Threshold",
      affiliateMarketing: true,
      traditional: false,
      highlight: true,
      tooltip: "Withdraw your earnings without meeting minimum payout thresholds",
    },
  ]

  return (
    <section className="py-24 bg-gradient-to-b from-[#0A0A14] to-[#0A1A2F]/30">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            COMPARISON
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Why Choose AffiliateMarketing.com
          </h2>
          <p className="text-base md:text-lg text-white/70">
            See how our revolutionary platform compares to traditional affiliate networks.
          </p>
        </div>

        <TooltipProvider>
          {isMobile ? (
            // Mobile view - stacked cards
            <div className="space-y-6 max-w-md mx-auto">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                  className={`rounded-lg overflow-hidden ${
                    feature.highlight ? "border-2 border-[#00F0FF]/30" : "border border-white/10"
                  }`}
                >
                  <div
                    className={`p-4 ${feature.highlight ? "bg-gradient-to-r from-[#00F0FF]/10 to-[#0033CC]/10" : "bg-white/5"}`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <h3 className={`font-medium ${feature.highlight ? "text-[#00F0FF]" : "text-white"}`}>
                        {feature.name}
                      </h3>
                      {feature.tooltip && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button className="ml-1 text-white/40 hover:text-white/60">
                              <Info className="h-4 w-4" />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent className="bg-[#0A0A14] border border-[#00F0FF]/30 text-white p-2 max-w-[200px]">
                            {feature.tooltip}
                          </TooltipContent>
                        </Tooltip>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div
                        className={`p-3 rounded-lg ${feature.affiliateMarketing ? "bg-[#00F0FF]/20" : "bg-white/5"} flex items-center justify-between`}
                      >
                        <span className="text-sm font-medium">Us</span>
                        {feature.affiliateMarketing ? (
                          <Check className="h-5 w-5 text-[#00F0FF]" />
                        ) : (
                          <X className="h-5 w-5 text-white/40" />
                        )}
                      </div>

                      <div
                        className={`p-3 rounded-lg ${feature.traditional ? "bg-white/10" : "bg-white/5"} flex items-center justify-between`}
                      >
                        <span className="text-sm font-medium">Them</span>
                        {feature.traditional ? (
                          <Check className="h-5 w-5 text-white/60" />
                        ) : (
                          <X className="h-5 w-5 text-white/40" />
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            // Desktop view - table layout
            <div className="max-w-4xl mx-auto overflow-x-auto">
              <div className="min-w-[768px]">
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="col-span-1"></div>
                  <div className="col-span-1 text-center">
                    <div className="bg-gradient-to-r from-[#00F0FF] to-[#0033CC] p-px rounded-lg">
                      <div className="bg-[#0A0A14] rounded-lg p-4">
                        <h3 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[#00F0FF] to-[#0033CC]">
                          AffiliateMarketing.com
                        </h3>
                        <p className="text-white/60 text-sm mt-1">Next-Gen Platform</p>
                      </div>
                    </div>
                  </div>
                  <div className="col-span-1 text-center">
                    <div className="bg-white/10 p-px rounded-lg">
                      <div className="bg-[#0A0A14] rounded-lg p-4">
                        <h3 className="text-xl font-bold text-white/80">Traditional Networks</h3>
                        <p className="text-white/60 text-sm mt-1">Legacy Platforms</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  {features.map((feature, index) => (
                    <motion.div
                      key={feature.name}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1, duration: 0.5 }}
                      className={`grid grid-cols-3 gap-4 ${
                        feature.highlight
                          ? "bg-gradient-to-r from-[#00F0FF]/10 to-[#0033CC]/10 border border-[#00F0FF]/20"
                          : "bg-white/5 border border-white/10"
                      } rounded-lg p-4`}
                    >
                      <div className="col-span-1 flex items-center">
                        <span className={feature.highlight ? "font-medium text-[#00F0FF]" : "text-white"}>
                          {feature.name}
                        </span>
                        {feature.tooltip && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button className="ml-2 text-white/40 hover:text-white/60">
                                <Info className="h-4 w-4" />
                              </button>
                            </TooltipTrigger>
                            <TooltipContent className="bg-[#0A0A14] border border-[#00F0FF]/30 text-white p-2">
                              {feature.tooltip}
                            </TooltipContent>
                          </Tooltip>
                        )}
                      </div>
                      <div className="col-span-1 flex justify-center items-center">
                        {feature.affiliateMarketing ? (
                          <div className="h-8 w-8 rounded-full bg-[#00F0FF]/20 flex items-center justify-center">
                            <Check className="h-5 w-5 text-[#00F0FF]" />
                          </div>
                        ) : (
                          <div className="h-8 w-8 rounded-full bg-white/10 flex items-center justify-center">
                            <X className="h-5 w-5 text-white/40" />
                          </div>
                        )}
                      </div>
                      <div className="col-span-1 flex justify-center items-center">
                        {feature.traditional ? (
                          <div className="h-8 w-8 rounded-full bg-white/10 flex items-center justify-center">
                            <Check className="h-5 w-5 text-white/60" />
                          </div>
                        ) : (
                          <div className="h-8 w-8 rounded-full bg-white/10 flex items-center justify-center">
                            <X className="h-5 w-5 text-white/40" />
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </TooltipProvider>
      </div>
    </section>
  )
}

