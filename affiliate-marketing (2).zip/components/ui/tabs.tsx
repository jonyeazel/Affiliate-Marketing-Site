"use client"

import { useState, type ReactNode } from "react"
import { Tab } from "@headlessui/react"

function classNames(...classes) {
  return classes.filter(Boolean).join(" ")
}

// Add missing exports to prevent import errors
export const TabsList = ({ children }: { children: ReactNode }) => <>{children}</>
export const TabsTrigger = ({ children }: { children: ReactNode }) => <>{children}</>
export const TabsContent = ({ children }: { children: ReactNode }) => <>{children}</>

export function Tabs({ tabs = [] }) {
  const [selectedIndex, setSelectedIndex] = useState(0)

  // Add a safety check
  if (!tabs || !Array.isArray(tabs) || tabs.length === 0) {
    return <div className="text-gray-400">No tabs to display</div>
  }

  return (
    <div className="w-full max-w-md px-2 sm:px-0">
      <Tab.Group selectedIndex={selectedIndex} onChange={setSelectedIndex}>
        <Tab.List className="flex space-x-1 rounded-xl bg-blue-900/20 p-1">
          {tabs.map((tab, index) => (
            <Tab
              key={index}
              className={({ selected }) =>
                classNames(
                  "w-full rounded-lg py-2.5 text-sm font-medium leading-5 transition-all duration-200",
                  "ring-white/60 ring-offset-2 ring-offset-blue-400 focus:outline-none focus:ring-2",
                  selected
                    ? "bg-[#00F0FF] text-[#0A0A14] shadow-lg transform scale-105"
                    : "text-white hover:bg-white/[0.12] hover:text-white",
                )
              }
            >
              {tab.label}
            </Tab>
          ))}
        </Tab.List>
        <Tab.Panels className="mt-2">
          {tabs.map((tab, index) => (
            <Tab.Panel
              key={index}
              className={classNames(
                "rounded-xl bg-white dark:bg-[#0A0A14] dark:border dark:border-white/10 p-3",
                "ring-white/60 ring-offset-2 ring-offset-blue-400 focus:outline-none focus:ring-2",
                "transition-all duration-300 transform",
                selectedIndex === index ? "translate-x-0 opacity-100" : "translate-x-4 opacity-0",
              )}
            >
              {tab.content}
            </Tab.Panel>
          ))}
        </Tab.Panels>
      </Tab.Group>
    </div>
  )
}

