"use client"

import { useState, useRef, useEffect } from "react"
import { StarIcon } from "@heroicons/react/20/solid"

export function TestimonialSlider({ testimonials = [] }) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const intervalRef = useRef(null)
  const hasTestimonials = testimonials && Array.isArray(testimonials) && testimonials.length > 0

  useEffect(() => {
    if (hasTestimonials) {
      intervalRef.current = setInterval(() => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length)
      }, 5000)
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [hasTestimonials, testimonials.length])

  const renderStars = (rating) => {
    return Array.from({ length: 5 }).map((_, i) => (
      <StarIcon
        key={i}
        className={`h-5 w-5 ${i < rating ? "text-yellow-400" : "text-gray-300 dark:text-gray-600"}`}
        aria-hidden="true"
      />
    ))
  }

  if (!hasTestimonials) {
    return <div className="text-gray-400">No testimonials to display</div>
  }

  return (
    <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-3xl">
        <div className="relative overflow-hidden rounded-xl bg-white dark:bg-[#0A0A14] dark:border dark:border-white/10 shadow-xl">
          <div
            className="flex transition-transform duration-500 ease-in-out"
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
          >
            {testimonials.map((testimonial, index) => (
              <div key={index} className="w-full flex-shrink-0 p-8">
                <div className="flex items-center">
                  <div className="flex-1">
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">{testimonial.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {testimonial.role}, {testimonial.company}
                    </p>
                  </div>
                  <div className="flex">{renderStars(testimonial.rating)}</div>
                </div>
                <div className="mt-4">
                  <p className="text-base italic text-gray-600 dark:text-gray-300">"{testimonial.quote}"</p>
                </div>
              </div>
            ))}
          </div>

          <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`h-2 w-2 rounded-full ${
                  index === currentIndex ? "bg-[#00F0FF]" : "bg-gray-300 dark:bg-gray-600"
                }`}
                onClick={() => setCurrentIndex(index)}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

