"use client"
import { Disclosure, Transition } from "@headlessui/react"
import { ChevronUpIcon } from "@heroicons/react/20/solid"

export function Accordion({ items = [] }) {
  // Add a safety check
  if (!items || !Array.isArray(items) || items.length === 0) {
    return <div className="text-gray-400">No accordion items to display</div>
  }

  return (
    <div className="w-full max-w-md rounded-2xl bg-white dark:bg-[#0A0A14] dark:border dark:border-white/10 p-2">
      <div className="mx-auto w-full rounded-2xl bg-white dark:bg-[#0A0A14] p-2">
        {items.map((item, index) => (
          <Disclosure as="div" key={index} className="mt-2">
            {({ open }) => (
              <>
                <Disclosure.Button className="flex w-full justify-between rounded-lg bg-[#00F0FF]/10 px-4 py-2 text-left text-sm font-medium text-[#00F0FF] hover:bg-[#00F0FF]/20 focus:outline-none focus-visible:ring focus-visible:ring-[#00F0FF] focus-visible:ring-opacity-75">
                  <span>{item.title}</span>
                  <ChevronUpIcon className={`${open ? "rotate-180 transform" : ""} h-5 w-5 text-[#00F0FF]`} />
                </Disclosure.Button>
                <Transition
                  enter="transition duration-100 ease-out"
                  enterFrom="transform scale-95 opacity-0"
                  enterTo="transform scale-100 opacity-100"
                  leave="transition duration-75 ease-out"
                  leaveFrom="transform scale-100 opacity-100"
                  leaveTo="transform scale-95 opacity-0"
                >
                  <Disclosure.Panel className="px-4 pt-4 pb-2 text-sm text-gray-500 dark:text-gray-300">
                    {item.content}
                  </Disclosure.Panel>
                </Transition>
              </>
            )}
          </Disclosure>
        ))}
      </div>
    </div>
  )
}

// Add missing exports to prevent import errors
export const AccordionItem = ({ children }) => <>{children}</>
export const AccordionTrigger = ({ children }) => <>{children}</>
export const AccordionContent = ({ children }) => <>{children}</>

