"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from "lucide-react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"

const toastVariants = cva(
  "group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-4 pr-8 shadow-lg transition-all",
  {
    variants: {
      variant: {
        default: "bg-background border-border",
        success: "bg-success/10 border-success text-success",
        error: "bg-destructive/10 border-destructive text-destructive",
        warning: "bg-warning/10 border-warning text-warning",
        info: "bg-info/10 border-info text-info",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
)

export interface ToastProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof toastVariants> {
  title?: string
  description?: string
  action?: React.ReactNode
  duration?: number
  onClose?: () => void
}

export function Toast({
  className,
  variant,
  title,
  description,
  action,
  duration = 5000,
  onClose,
  ...props
}: ToastProps) {
  const [isVisible, setIsVisible] = useState(true)
  const [progress, setProgress] = useState(100)

  useEffect(() => {
    if (duration === Number.POSITIVE_INFINITY) return

    const timer = setTimeout(() => {
      setIsVisible(false)
    }, duration)

    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev - 100 / (duration / 100)
        return newProgress < 0 ? 0 : newProgress
      })
    }, 100)

    return () => {
      clearTimeout(timer)
      clearInterval(interval)
    }
  }, [duration])

  const handleClose = () => {
    setIsVisible(false)
    onClose?.()
  }

  const getIcon = () => {
    switch (variant) {
      case "success":
        return <CheckCircle className="h-5 w-5" />
      case "error":
        return <AlertCircle className="h-5 w-5" />
      case "warning":
        return <AlertTriangle className="h-5 w-5" />
      case "info":
        return <Info className="h-5 w-5" />
      default:
        return null
    }
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className={cn(toastVariants({ variant }), className)}
          {...props}
        >
          <div className="grid gap-1">
            {title && (
              <div className="flex items-center gap-2">
                {getIcon()}
                <div className="text-sm font-semibold">{title}</div>
              </div>
            )}
            {description && <div className="text-sm opacity-90">{description}</div>}
          </div>

          {action && <div>{action}</div>}

          <button
            className="absolute right-2 top-2 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-2 group-hover:opacity-100"
            onClick={handleClose}
            aria-label="Close toast"
          >
            <X className="h-4 w-4" />
          </button>

          {duration !== Number.POSITIVE_INFINITY && (
            <div className="absolute bottom-0 left-0 h-1 bg-foreground/20" style={{ width: `${progress}%` }} />
          )}
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export function useToast() {
  const [toasts, setToasts] = useState<Array<ToastProps & { id: string }>>([])

  const toast = (props: ToastProps) => {
    const id = Math.random().toString(36).substring(2, 9)
    setToasts((prev) => [...prev, { ...props, id }])
    return id
  }

  const dismiss = (id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id))
  }

  const Toaster = () => (
    <div className="fixed bottom-0 right-0 z-50 flex flex-col gap-2 p-4 md:max-w-[420px]">
      <AnimatePresence>
        {toasts.map((t) => (
          <Toast key={t.id} {...t} onClose={() => dismiss(t.id)} />
        ))}
      </AnimatePresence>
    </div>
  )

  return { toast, dismiss, Toaster }
}

