"use client"
import { Menu } from "@headlessui/react"

export const DropdownMenu = Menu
export const DropdownMenuTrigger = Menu.Button
export const DropdownMenuContent = Menu.Items
export const DropdownMenuItem = Menu.Item

