"use client"

import { CheckIcon, XMarkIcon } from "@heroicons/react/20/solid"

function classNames(...classes) {
  return classes.filter(Boolean).join(" ")
}

export function ProductComparison({ products = [], features = [] }) {
  // Add safety checks
  if (!products || !Array.isArray(products) || products.length === 0) {
    return <div className="text-gray-400">No products to compare</div>
  }

  if (!features || !Array.isArray(features) || features.length === 0) {
    return <div className="text-gray-400">No features to compare</div>
  }

  return (
    <div className="bg-white dark:bg-[#0A0A14]">
      <div className="mx-auto max-w-7xl py-16 sm:py-24 sm:px-6 lg:px-8">
        {/* xs to lg */}
        <div className="mx-auto max-w-2xl space-y-16 lg:hidden">
          {products.map((product, productIdx) => (
            <section key={product.name}>
              <div className="mb-8 px-4">
                <h2 className="text-lg font-medium leading-6 text-gray-900 dark:text-white">{product.name}</h2>
              </div>

              <table className="w-full">
                <caption className="sr-only">{product.name} features</caption>
                <thead>
                  <tr>
                    <th className="sr-only" scope="col">
                      Feature
                    </th>
                    <th className="sr-only" scope="col">
                      Included
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {features.map((feature) => (
                    <tr key={feature.name} className="border-t border-gray-200">
                      <th
                        className="py-5 px-4 text-sm font-normal text-gray-500 dark:text-gray-300 text-left"
                        scope="row"
                      >
                        {feature.name}
                      </th>
                      <td className="py-5 pr-4">
                        {typeof product.features[feature.id] === "boolean" ? (
                          <div className="flex justify-end">
                            {product.features[feature.id] ? (
                              <CheckIcon className="h-5 w-5 text-green-500" aria-hidden="true" />
                            ) : (
                              <XMarkIcon className="h-5 w-5 text-red-500" aria-hidden="true" />
                            )}
                          </div>
                        ) : (
                          <div className="text-sm text-gray-700 dark:text-gray-300 text-right">
                            {product.features[feature.id]}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          ))}
        </div>

        {/* lg+ */}
        <div className="hidden lg:block">
          <table className="h-px w-full table-fixed">
            <caption className="sr-only">Feature comparison</caption>
            <thead>
              <tr>
                <th className="w-1/4 pb-4 px-6 text-sm font-medium text-gray-900 dark:text-white text-left" scope="col">
                  <span className="sr-only">Feature</span>
                </th>
                {products.map((product) => (
                  <th
                    key={product.name}
                    className="w-1/4 pb-4 px-6 text-lg font-medium leading-6 text-gray-900 dark:text-white text-left"
                    scope="col"
                  >
                    {product.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 border-t border-gray-200">
              {features.map((feature) => (
                <tr key={feature.name}>
                  <th className="py-5 px-6 text-sm font-normal text-gray-600 dark:text-gray-300 text-left" scope="row">
                    {feature.name}
                  </th>
                  {products.map((product) => (
                    <td key={product.name} className="py-5 px-6">
                      {typeof product.features[feature.id] === "boolean" ? (
                        <div className="flex">
                          {product.features[feature.id] ? (
                            <CheckIcon className="h-5 w-5 text-green-500" aria-hidden="true" />
                          ) : (
                            <XMarkIcon className="h-5 w-5 text-red-500" aria-hidden="true" />
                          )}
                        </div>
                      ) : (
                        <div className="text-sm text-gray-700 dark:text-gray-300">{product.features[feature.id]}</div>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

