"use client"

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  type TooltipProps,
  Cell,
} from "recharts"
import { Card } from "@/components/ui/card"

interface Platform {
  name: string
  conversionRate: number
  color: string
}

export default function LinkPerformance() {
  const data: Platform[] = [
    { name: "TikTok", conversionRate: 12.4, color: "#000000" },
    { name: "Instagram", conversionRate: 8.7, color: "#E1306C" },
    { name: "YouTube", conversionRate: 7.2, color: "#FF0000" },
    { name: "Blog", conversionRate: 5.8, color: "#00FFFF" },
    { name: "Twitter", conversionRate: 4.3, color: "#1DA1F2" },
    { name: "Pinterest", conversionRate: 3.9, color: "#E60023" },
  ]

  const CustomTooltip = ({ active, payload, label }: TooltipProps<number, string>) => {
    if (active && payload && payload.length) {
      return (
        <Card className="bg-[#191919] border-white/10 p-3">
          <p className="font-medium">{label}</p>
          <p className="text-[#FFFF00]">{payload[0].value}% conversion rate</p>
          <p className="text-white/60 text-sm">Industry avg: 3.4%</p>
        </Card>
      )
    }

    return null
  }

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{
            top: 5,
            right: 10,
            left: 10,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
          <XAxis
            dataKey="name"
            stroke="#666"
            tick={{ fill: "#999" }}
            axisLine={{ stroke: "#333" }}
            tickLine={{ stroke: "#333" }}
          />
          <YAxis
            stroke="#666"
            tick={{ fill: "#999" }}
            axisLine={{ stroke: "#333" }}
            tickLine={{ stroke: "#333" }}
            tickFormatter={(value) => `${value}%`}
          />
          <Tooltip content={<CustomTooltip />} />
          <Bar dataKey="conversionRate" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

