"use client"
import { motion } from "framer-motion"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { DollarSign, TrendingUp, Users, Clock, ArrowRight, Sparkles } from "lucide-react"

interface Opportunity {
  id: string
  title: string
  brand: {
    name: string
    logo: string
  }
  matchScore: number
  commission: string
  category: string
  expiresIn: string
  spots: number
  totalSpots: number
  isNew: boolean
}

export default function OpportunityFeed() {
  const opportunities: Opportunity[] = [
    {
      id: "1",
      title: "Tech Gadget Bundle",
      brand: {
        name: "TechGear",
        logo: "/placeholder.svg?height=40&width=40",
      },
      matchScore: 94,
      commission: "$45 + 12%",
      category: "Tech",
      expiresIn: "2 days",
      spots: 8,
      totalSpots: 25,
      isNew: true,
    },
    {
      id: "2",
      title: "Premium Skincare Set",
      brand: {
        name: "GlowUp",
        logo: "/placeholder.svg?height=40&width=40",
      },
      matchScore: 87,
      commission: "18%",
      category: "Beauty",
      expiresIn: "5 days",
      spots: 12,
      totalSpots: 50,
      isNew: false,
    },
    {
      id: "3",
      title: "Fitness Tracker Pro",
      brand: {
        name: "ActiveLife",
        logo: "/placeholder.svg?height=40&width=40",
      },
      matchScore: 82,
      commission: "$30 + 10%",
      category: "Fitness",
      expiresIn: "3 days",
      spots: 15,
      totalSpots: 40,
      isNew: true,
    },
  ]

  return (
    <div className="space-y-4">
      {opportunities.map((opportunity) => (
        <motion.div
          key={opportunity.id}
          initial={opportunity.isNew ? { x: -20, opacity: 0 } : false}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="bg-[#191919] rounded-lg p-4 border border-white/5 hover:border-white/10 transition-all"
        >
          <div className="flex items-start gap-3 mb-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={opportunity.brand.logo} alt={opportunity.brand.name} />
              <AvatarFallback>{opportunity.brand.name.charAt(0)}</AvatarFallback>
            </Avatar>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="font-medium truncate">{opportunity.title}</h3>
                {opportunity.isNew && <Badge className="bg-[#FF00FF] text-white">NEW</Badge>}
              </div>
              <p className="text-sm text-white/60">{opportunity.brand.name}</p>
            </div>

            <div className="flex flex-col items-center bg-[#111111] rounded-md px-2 py-1">
              <div className="text-xs text-white/60">Match</div>
              <div className="font-bold text-[#00FFFF]">{opportunity.matchScore}%</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mb-3">
            <div className="flex items-center text-sm">
              <DollarSign className="h-4 w-4 text-[#FFFF00] mr-1" />
              <span className="text-white/60 mr-1">Commission:</span>
              <span className="font-medium">{opportunity.commission}</span>
            </div>

            <div className="flex items-center text-sm">
              <TrendingUp className="h-4 w-4 text-[#00FFFF] mr-1" />
              <span className="text-white/60 mr-1">Category:</span>
              <span className="font-medium">{opportunity.category}</span>
            </div>

            <div className="flex items-center text-sm">
              <Clock className="h-4 w-4 text-[#FF00FF] mr-1" />
              <span className="text-white/60 mr-1">Expires in:</span>
              <span className="font-medium">{opportunity.expiresIn}</span>
            </div>

            <div className="flex items-center text-sm">
              <Users className="h-4 w-4 text-white/60 mr-1" />
              <span className="text-white/60 mr-1">Spots:</span>
              <span className="font-medium">
                {opportunity.spots}/{opportunity.totalSpots}
              </span>
            </div>
          </div>

          <div className="mb-3">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-white/60">Spots filling up</span>
              <span className="text-white/60">
                {Math.round((1 - opportunity.spots / opportunity.totalSpots) * 100)}% full
              </span>
            </div>
            <Progress
              value={(1 - opportunity.spots / opportunity.totalSpots) * 100}
              className="h-1.5 bg-white/10"
              indicatorClassName="bg-[#FF00FF]"
            />
          </div>

          <Button className="w-full bg-gradient-to-r from-[#00FFFF] to-[#FF00FF] text-black font-medium">
            <Sparkles className="mr-2 h-4 w-4" />
            Claim Opportunity
          </Button>
        </motion.div>
      ))}

      <Button variant="ghost" className="w-full text-white/60 hover:text-white">
        Load More
        <ArrowRight className="ml-2 h-4 w-4" />
      </Button>
    </div>
  )
}

