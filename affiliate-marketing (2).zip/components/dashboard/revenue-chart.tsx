"use client"

import { useEffect, useState } from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, type TooltipProps } from "recharts"
import { Card } from "@/components/ui/card"

interface DataPoint {
  date: string
  earnings: number
  clicks: number
}

export default function RevenueChart() {
  const [data, setData] = useState<DataPoint[]>([])

  useEffect(() => {
    // Generate last 7 days of data
    const generateData = () => {
      const result: DataPoint[] = []
      const now = new Date()

      for (let i = 6; i >= 0; i--) {
        const date = new Date(now)
        date.setDate(date.getDate() - i)

        const dayName = date.toLocaleDateString("en-US", { weekday: "short" })
        const baseEarnings = Math.random() * 300 + 100
        const baseClicks = Math.floor(Math.random() * 200 + 50)

        // Add some trends
        let earnings = baseEarnings
        let clicks = baseClicks

        // Weekend boost
        if (date.getDay() === 0 || date.getDay() === 6) {
          earnings *= 1.3
          clicks *= 1.2
        }

        // Recent days trend up
        if (i < 3) {
          earnings *= 1 + (3 - i) * 0.1
          clicks *= 1 + (3 - i) * 0.05
        }

        result.push({
          date: dayName,
          earnings: Number.parseFloat(earnings.toFixed(2)),
          clicks: Math.floor(clicks),
        })
      }

      return result
    }

    setData(generateData())
  }, [])

  const CustomTooltip = ({ active, payload, label }: TooltipProps<number, string>) => {
    if (active && payload && payload.length) {
      return (
        <Card className="bg-[#191919] border-white/10 p-3">
          <p className="font-medium">{label}</p>
          <p className="text-[#00FFFF]">${payload[0].value?.toLocaleString()}</p>
          <p className="text-white/60 text-sm">{payload[1].value} clicks</p>
        </Card>
      )
    }

    return null
  }

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 5,
            right: 10,
            left: 10,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
          <XAxis
            dataKey="date"
            stroke="#666"
            tick={{ fill: "#999" }}
            axisLine={{ stroke: "#333" }}
            tickLine={{ stroke: "#333" }}
          />
          <YAxis
            stroke="#666"
            tick={{ fill: "#999" }}
            axisLine={{ stroke: "#333" }}
            tickLine={{ stroke: "#333" }}
            tickFormatter={(value) => `$${value}`}
          />
          <Tooltip content={<CustomTooltip />} />
          <Line
            type="monotone"
            dataKey="earnings"
            stroke="#00FFFF"
            strokeWidth={3}
            dot={{ fill: "#00FFFF", strokeWidth: 2, r: 4 }}
            activeDot={{ fill: "#00FFFF", strokeWidth: 2, r: 6 }}
          />
          <Line
            type="monotone"
            dataKey="clicks"
            stroke="#FF00FF"
            strokeWidth={2}
            dot={{ fill: "#FF00FF", strokeWidth: 2, r: 4 }}
            activeDot={{ fill: "#FF00FF", strokeWidth: 2, r: 6 }}
            opacity={0.7}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

