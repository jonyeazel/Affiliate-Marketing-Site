"use client"

import { useState } from "react"
import { X, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface ProgramApplicationModalProps {
  program: {
    name: string
    category: string
    commission: string
    cookieDuration: string
    averageEarnings: string
  }
  onClose: () => void
}

export default function ProgramApplicationModal({ program, onClose }: ProgramApplicationModalProps) {
  const [step, setStep] = useState(1)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    website: "",
    socialProfiles: "",
    monthlyTraffic: "",
    contentTypes: "",
    promotionStrategy: "",
  })

  const handleInputChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value })
  }

  const handleSubmit = () => {
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSubmitted(true)
    }, 1500)
  }

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
      <Card className="w-full max-w-lg max-h-[90vh] overflow-auto">
        {!isSubmitted ? (
          <>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Apply to {program.name}</CardTitle>
                <Button variant="ghost" size="icon" onClick={onClose}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <CardDescription>Complete this application to join the {program.name} affiliate program</CardDescription>
            </CardHeader>
            <CardContent>
              {step === 1 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Commission Rate</div>
                      <div className="font-medium">{program.commission}</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Cookie Duration</div>
                      <div className="font-medium">{program.cookieDuration}</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Category</div>
                      <div className="font-medium">{program.category}</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Avg. Earnings</div>
                      <div className="font-medium">{program.averageEarnings}</div>
                    </div>
                  </div>

                  <div className="space-y-2 pt-4">
                    <Label htmlFor="website">Your Website or Blog URL</Label>
                    <Input
                      id="website"
                      placeholder="https://yourwebsite.com"
                      value={formData.website}
                      onChange={(e) => handleInputChange("website", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="social-profiles">Social Media Profiles</Label>
                    <Input
                      id="social-profiles"
                      placeholder="Instagram, YouTube, TikTok, etc."
                      value={formData.socialProfiles}
                      onChange={(e) => handleInputChange("socialProfiles", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="monthly-traffic">Monthly Traffic/Followers</Label>
                    <Input
                      id="monthly-traffic"
                      placeholder="e.g., 10,000 monthly visitors"
                      value={formData.monthlyTraffic}
                      onChange={(e) => handleInputChange("monthlyTraffic", e.target.value)}
                    />
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="content-types">Content Types You Create</Label>
                    <Input
                      id="content-types"
                      placeholder="Blog posts, videos, social media, etc."
                      value={formData.contentTypes}
                      onChange={(e) => handleInputChange("contentTypes", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="promotion-strategy">How do you plan to promote {program.name} products?</Label>
                    <Textarea
                      id="promotion-strategy"
                      placeholder="Describe your promotion strategy..."
                      className="min-h-[120px]"
                      value={formData.promotionStrategy}
                      onChange={(e) => handleInputChange("promotionStrategy", e.target.value)}
                    />
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              {step === 1 ? (
                <Button variant="ghost" onClick={onClose}>
                  Cancel
                </Button>
              ) : (
                <Button variant="outline" onClick={() => setStep(1)}>
                  Back
                </Button>
              )}

              {step === 1 ? (
                <Button onClick={() => setStep(2)} disabled={!formData.website || !formData.monthlyTraffic}>
                  Continue
                </Button>
              ) : (
                <Button onClick={handleSubmit} disabled={!formData.promotionStrategy || isSubmitting}>
                  {isSubmitting ? "Submitting..." : "Submit Application"}
                </Button>
              )}
            </CardFooter>
          </>
        ) : (
          <>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Application Submitted</CardTitle>
                <Button variant="ghost" size="icon" onClick={onClose}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="flex flex-col items-center text-center py-6">
              <div className="rounded-full bg-green-100 p-3 mb-4">
                <CheckCircle2 className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-medium mb-2">Thank You!</h3>
              <p className="text-muted-foreground mb-4">
                Your application to join the {program.name} affiliate program has been submitted successfully.
              </p>
              <div className="bg-muted p-4 rounded-md w-full text-left mb-4">
                <div className="text-sm font-medium mb-1">What happens next?</div>
                <ol className="text-sm text-muted-foreground list-decimal pl-4 space-y-1">
                  <li>The {program.name} team will review your application</li>
                  <li>You'll receive a notification when your status changes</li>
                  <li>If approved, you can start creating affiliate links immediately</li>
                </ol>
              </div>
              <p className="text-sm text-muted-foreground">
                Average approval time: <span className="font-medium">24-48 hours</span>
              </p>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={onClose}>
                Return to Dashboard
              </Button>
            </CardFooter>
          </>
        )}
      </Card>
    </div>
  )
}

