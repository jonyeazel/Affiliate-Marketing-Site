"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { ChevronDown } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface FaqItem {
  question: string
  answer: string
}

export function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const faqs: FaqItem[] = [
    {
      question: "When will the platform launch?",
      answer:
        "We're currently in private beta with select partners. We plan to launch publicly in Q3 2023. Join the waitlist to be among the first to get access when we open the doors.",
    },
    {
      question: "How does instant payment work?",
      answer:
        "We front the payments to affiliates when a sale is made, and then collect from the brand on their normal payment schedule. This means affiliates get paid immediately while brands maintain their cash flow.",
    },
    {
      question: "Is there a fee to join?",
      answer:
        "The platform is free for affiliates to join. Brands pay a competitive monthly fee based on their program size, plus a small percentage of sales. Detailed pricing will be announced at launch.",
    },
    {
      question: "How is this different from other platforms?",
      answer:
        "We're the only platform offering instant payments, AI-powered matching, and a unified dashboard for all your programs. Our technology is built from the ground up for today's affiliate marketing landscape.",
    },
    {
      question: "Can I migrate my existing programs?",
      answer:
        "Yes! We have tools to easily migrate your existing affiliate relationships and historical data. Our team will help you with the transition to ensure a smooth experience.",
    },
    {
      question: "Is my data secure on the platform?",
      answer:
        "Absolutely. We use bank-level encryption and security protocols to protect all user data. Your information is never shared with third parties without your explicit consent, and we're fully compliant with GDPR and other privacy regulations.",
    },
  ]

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section className="py-24 bg-gradient-to-b from-[#0A0A14] to-[#0A1A2F]/30">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            FAQ
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Common Questions
          </h2>
          <p className="text-base md:text-lg text-white/70">
            Everything you need to know about our revolutionary affiliate marketing platform.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="border border-white/10 rounded-lg bg-white/5 hover:border-[#00F0FF]/30 transition-colors duration-300"
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full px-6 py-4 text-left flex justify-between items-center"
                >
                  <span className="text-lg font-medium">{faq.question}</span>
                  <ChevronDown
                    className={`h-5 w-5 text-[#00F0FF] transition-transform duration-300 ${openIndex === index ? "rotate-180" : ""}`}
                  />
                </button>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="px-6 pb-4 text-white/70"
                  >
                    {faq.answer}
                  </motion.div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

