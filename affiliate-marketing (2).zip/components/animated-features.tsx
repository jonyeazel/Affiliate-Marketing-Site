"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { CheckCircle } from "lucide-react"

interface Feature {
  title: string
  description: string
  icon: string
  color: string
}

export function AnimatedFeatures() {
  const [activeFeature, setActiveFeature] = useState(0)

  const features: Feature[] = [
    {
      title: "Smart Link Generation",
      description:
        "Create trackable affiliate links instantly with our AI-powered link generator that optimizes for conversion.",
      icon: "✨",
      color: "from-[#00F0FF] to-[#0033CC]",
    },
    {
      title: "Real-time Analytics",
      description: "Track your performance with comprehensive real-time analytics and actionable insights.",
      icon: "📊",
      color: "from-[#FF3366] to-[#FF9933]",
    },
    {
      title: "Instant Payouts",
      description: "Get paid instantly when you make a sale, no more waiting for monthly payment cycles.",
      icon: "💸",
      color: "from-[#33CC33] to-[#009966]",
    },
    {
      title: "AI Opportunity Finder",
      description: "Our AI scans thousands of programs to match you with the highest-converting opportunities.",
      icon: "🔍",
      color: "from-[#9966FF] to-[#6633CC]",
    },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveFeature((prev) => (prev + 1) % features.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [features.length])

  return (
    <div className="w-full max-w-6xl mx-auto py-16 px-4">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-[#00F0FF] to-[#0033CC]">
          Revolutionary Features
        </h2>
        <p className="text-white/70 max-w-2xl mx-auto">
          Our platform is packed with innovative features designed to maximize your affiliate marketing success.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        <div className="space-y-4">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              className={`p-4 rounded-xl cursor-pointer transition-all duration-300 ${
                activeFeature === index ? "bg-white/5 border border-white/10" : "hover:bg-white/5"
              }`}
              onClick={() => setActiveFeature(index)}
              animate={{
                y: activeFeature === index ? 0 : 5,
                opacity: activeFeature === index ? 1 : 0.7,
              }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-start">
                <div
                  className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center bg-gradient-to-r ${feature.color} mr-4`}
                >
                  <span className="text-lg">{feature.icon}</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold flex items-center">
                    {feature.title}
                    {activeFeature === index && (
                      <motion.span
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="ml-2 text-[#00F0FF]"
                      >
                        <CheckCircle className="h-4 w-4" />
                      </motion.span>
                    )}
                  </h3>
                  <p className="text-white/60 text-sm mt-1">{feature.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="relative h-[400px] rounded-2xl overflow-hidden border border-white/10 bg-black/20">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              className="absolute inset-0 flex items-center justify-center p-8"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{
                opacity: activeFeature === index ? 1 : 0,
                scale: activeFeature === index ? 1 : 0.9,
                zIndex: activeFeature === index ? 10 : 0,
              }}
              transition={{ duration: 0.5 }}
            >
              <div
                className={`w-full h-full rounded-xl bg-gradient-to-br ${feature.color} opacity-10 absolute inset-0`}
              />

              <div className="relative z-10 text-center">
                <div className="text-6xl mb-6">{feature.icon}</div>
                <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
                <p className="text-white/80 max-w-md">{feature.description}</p>

                <motion.div className="mt-8 inline-block" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <a
                    href="#signup"
                    className={`px-6 py-3 rounded-lg bg-gradient-to-r ${feature.color} text-white font-medium`}
                  >
                    Try It Now
                  </a>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

