"use client"

import { motion } from "framer-motion"

export function PulseEffect() {
  return (
    <motion.span
      className="absolute inset-0 bg-[#00F0FF]/20 rounded-md"
      animate={{
        scale: [1, 1.05, 1],
        opacity: [0, 0.3, 0],
      }}
      transition={{
        duration: 2,
        repeat: Number.POSITIVE_INFINITY,
        repeatType: "loop",
      }}
    />
  )
}

