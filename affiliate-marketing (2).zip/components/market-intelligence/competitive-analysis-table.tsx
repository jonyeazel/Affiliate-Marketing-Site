"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

export default function CompetitiveAnalysisTable() {
  // This is a simplified implementation - in a real app, you would use the actual data
  const data = [
    {
      name: "TechGadgets Pro",
      commission: "Up to 15%",
      cookieDuration: "45 days",
      conversionRate: "4.2%",
      averageOrder: "$120",
      paymentFrequency: "Net-15",
      rating: "Excellent",
    },
    {
      name: "GadgetWorld",
      commission: "10-12%",
      cookieDuration: "30 days",
      conversionRate: "3.8%",
      averageOrder: "$95",
      paymentFrequency: "Net-30",
      rating: "Good",
    },
    {
      name: "TechHub",
      commission: "8-14%",
      cookieDuration: "60 days",
      conversionRate: "3.5%",
      averageOrder: "$150",
      paymentFrequency: "Net-30",
      rating: "Good",
    },
    {
      name: "ElectronicsPro",
      commission: "12%",
      cookieDuration: "30 days",
      conversionRate: "3.2%",
      averageOrder: "$110",
      paymentFrequency: "Net-45",
      rating: "Average",
    },
    {
      name: "TechSavvy",
      commission: "Up to 18%",
      cookieDuration: "30 days",
      conversionRate: "2.9%",
      averageOrder: "$85",
      paymentFrequency: "Net-30",
      rating: "Average",
    },
  ]

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Program Name</TableHead>
          <TableHead>Commission</TableHead>
          <TableHead>Cookie</TableHead>
          <TableHead>Conv. Rate</TableHead>
          <TableHead>Avg. Order</TableHead>
          <TableHead>Payment</TableHead>
          <TableHead>Rating</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {data.map((row) => (
          <TableRow key={row.name}>
            <TableCell className="font-medium">{row.name}</TableCell>
            <TableCell>{row.commission}</TableCell>
            <TableCell>{row.cookieDuration}</TableCell>
            <TableCell>{row.conversionRate}</TableCell>
            <TableCell>{row.averageOrder}</TableCell>
            <TableCell>{row.paymentFrequency}</TableCell>
            <TableCell>
              <Badge
                variant="outline"
                className={
                  row.rating === "Excellent"
                    ? "bg-green-500/10 text-green-500 hover:bg-green-500/20 hover:text-green-500"
                    : row.rating === "Good"
                      ? "bg-blue-500/10 text-blue-500 hover:bg-blue-500/20 hover:text-blue-500"
                      : "bg-yellow-500/10 text-yellow-500 hover:bg-yellow-500/20 hover:text-yellow-500"
                }
              >
                {row.rating}
              </Badge>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}

