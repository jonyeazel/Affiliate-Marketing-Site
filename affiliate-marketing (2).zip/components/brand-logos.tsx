export default function BrandLogos() {
  const logos = [
    { name: "Amazon", opacity: "opacity-70" },
    { name: "Shopify", opacity: "opacity-80" },
    { name: "Etsy", opacity: "opacity-60" },
    { name: "Walmart", opacity: "opacity-70" },
    { name: "Target", opacity: "opacity-60" },
    { name: "eBay", opacity: "opacity-80" },
  ]

  return (
    <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-8">
      {logos.map((logo) => (
        <div key={logo.name} className={`text-muted-foreground ${logo.opacity} transition-opacity hover:opacity-100`}>
          <div className="h-8 text-lg font-semibold">{logo.name}</div>
        </div>
      ))}
    </div>
  )
}

