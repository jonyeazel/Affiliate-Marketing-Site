"use client"

import { motion } from "framer-motion"
import { Check, type LucideIcon } from "lucide-react"

interface FeatureCardProps {
  number: number
  title: string
  description: string
  icon: LucideIcon
  benefits: string[]
  delay?: number
}

export function FeatureCard({ number, title, description, icon: Icon, benefits, delay = 0 }: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay, duration: 0.6 }}
      className="bg-gradient-to-br from-[#0A1A2F]/40 to-[#0A0A14]/80 backdrop-blur-sm rounded-xl p-8 border border-white/10 transition-all duration-300 shadow-xl hover:border-[#00F0FF]/30 hover:shadow-[#00F0FF]/5"
    >
      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] flex items-center justify-center mb-6 text-white font-bold text-xl">
        {number}
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-sm md:text-base text-white/70 mb-4">{description}</p>
      <ul className="space-y-2">
        {benefits.map((benefit, index) => (
          <li key={index} className="flex items-start">
            <Check className="h-5 w-5 text-[#00F0FF] mr-2 shrink-0 mt-0.5" />
            <span className="text-white/80">{benefit}</span>
          </li>
        ))}
      </ul>
    </motion.div>
  )
}

