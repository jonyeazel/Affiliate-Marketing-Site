"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BarChart2,
  Users,
  FileText,
  Settings,
  HelpCircle,
  Zap,
  DollarSign,
  Award,
  Briefcase,
  BookOpen,
  Home,
  ChevronRight,
  CreditCard,
  Bell,
  Gift,
  Star,
  TrendingUp,
  User,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface NavItem {
  name: string
  href: string
  icon: React.ReactNode
  badge?: {
    text: string
    variant: "default" | "success" | "warning" | "danger"
  }
  children?: Omit<NavItem, "children">[]
}

export function NavSidebar() {
  const [expandedItems, setExpandedItems] = useState<string[]>([])
  const pathname = usePathname()

  // Expand the active section by default
  useEffect(() => {
    const activeParent = navItems.find(
      (item) => item.children && item.children.some((child) => child.href === pathname),
    )

    if (activeParent && !expandedItems.includes(activeParent.name)) {
      setExpandedItems((prev) => [...prev, activeParent.name])
    }
  }, [pathname])

  const toggleExpanded = (name: string) => {
    setExpandedItems((prev) => (prev.includes(name) ? prev.filter((item) => item !== name) : [...prev, name]))
  }

  const navItems: NavItem[] = [
    {
      name: "Overview",
      href: "/dashboard",
      icon: <Home className="h-5 w-5" />,
    },
    {
      name: "Analytics",
      href: "/dashboard/analytics",
      icon: <BarChart2 className="h-5 w-5" />,
      children: [
        {
          name: "Performance",
          href: "/dashboard/analytics/performance",
          icon: <TrendingUp className="h-4 w-4" />,
        },
        {
          name: "Revenue",
          href: "/dashboard/analytics/revenue",
          icon: <DollarSign className="h-4 w-4" />,
        },
        {
          name: "Traffic",
          href: "/dashboard/analytics/traffic",
          icon: <Users className="h-4 w-4" />,
        },
      ],
    },
    {
      name: "Programs",
      href: "/dashboard/programs",
      icon: <Briefcase className="h-5 w-5" />,
      badge: {
        text: "3 New",
        variant: "success",
      },
      children: [
        {
          name: "Active Programs",
          href: "/dashboard/programs/active",
          icon: <Star className="h-4 w-4" />,
        },
        {
          name: "Applications",
          href: "/dashboard/programs/applications",
          icon: <FileText className="h-4 w-4" />,
          badge: {
            text: "2",
            variant: "warning",
          },
        },
        {
          name: "Recommended",
          href: "/dashboard/programs/recommended",
          icon: <Gift className="h-4 w-4" />,
          badge: {
            text: "New",
            variant: "success",
          },
        },
      ],
    },
    {
      name: "Links",
      href: "/dashboard/links",
      icon: <Zap className="h-5 w-5" />,
      children: [
        {
          name: "All Links",
          href: "/dashboard/links/all",
          icon: <ChevronRight className="h-4 w-4" />,
        },
        {
          name: "Create New",
          href: "/dashboard/links/create",
          icon: <ChevronRight className="h-4 w-4" />,
        },
        {
          name: "Link Groups",
          href: "/dashboard/links/groups",
          icon: <ChevronRight className="h-4 w-4" />,
        },
      ],
    },
    {
      name: "Earnings",
      href: "/dashboard/earnings",
      icon: <CreditCard className="h-5 w-5" />,
      children: [
        {
          name: "Transactions",
          href: "/dashboard/earnings/transactions",
          icon: <ChevronRight className="h-4 w-4" />,
        },
        {
          name: "Payouts",
          href: "/dashboard/earnings/payouts",
          icon: <ChevronRight className="h-4 w-4" />,
        },
        {
          name: "Tax Documents",
          href: "/dashboard/earnings/tax",
          icon: <ChevronRight className="h-4 w-4" />,
        },
      ],
    },
    {
      name: "Community",
      href: "/dashboard/community",
      icon: <Users className="h-5 w-5" />,
    },
    {
      name: "Resources",
      href: "/dashboard/resources",
      icon: <BookOpen className="h-5 w-5" />,
    },
    {
      name: "Notifications",
      href: "/dashboard/notifications",
      icon: <Bell className="h-5 w-5" />,
      badge: {
        text: "3",
        variant: "danger",
      },
    },
    {
      name: "Settings",
      href: "/dashboard/settings",
      icon: <Settings className="h-5 w-5" />,
    },
    {
      name: "Help & Support",
      href: "/dashboard/support",
      icon: <HelpCircle className="h-5 w-5" />,
    },
  ]

  const getBadgeVariant = (variant: string) => {
    switch (variant) {
      case "success":
        return "bg-green-500/20 text-green-400 border-green-500/30"
      case "warning":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      case "danger":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      default:
        return "bg-[#00F0FF]/20 text-[#00F0FF] border-[#00F0FF]/30"
    }
  }

  return (
    <div className="w-64 h-screen bg-[#0A0A14] border-r border-white/10 flex flex-col">
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
            <User className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-medium">John Doe</h3>
            <p className="text-xs text-white/50">Affiliate Partner</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {navItems.map((item) => (
          <div key={item.name} className="mb-1">
            {item.children ? (
              <>
                <button
                  onClick={() => toggleExpanded(item.name)}
                  className={`flex items-center justify-between w-full px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === item.href || pathname?.startsWith(item.href + "/")
                      ? "bg-gradient-to-r from-[#00F0FF]/20 to-transparent text-[#00F0FF]"
                      : "text-white/80 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {item.icon}
                    <span>{item.name}</span>
                  </div>
                  <div className="flex items-center">
                    {item.badge && (
                      <Badge className={`mr-2 ${getBadgeVariant(item.badge.variant)}`} variant="outline">
                        {item.badge.text}
                      </Badge>
                    )}
                    <ChevronRight
                      className={`h-4 w-4 transition-transform duration-200 ${
                        expandedItems.includes(item.name) ? "rotate-90" : ""
                      }`}
                    />
                  </div>
                </button>

                {expandedItems.includes(item.name) && (
                  <div className="mt-1 ml-4 pl-4 border-l border-white/10 space-y-1">
                    {item.children.map((child) => (
                      <Link
                        key={child.name}
                        href={child.href}
                        className={`flex items-center justify-between px-3 py-2 rounded-md text-sm transition-colors ${
                          pathname === child.href
                            ? "bg-gradient-to-r from-[#00F0FF]/10 to-transparent text-[#00F0FF]"
                            : "text-white/70 hover:bg-white/5 hover:text-white"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          {child.icon}
                          <span>{child.name}</span>
                        </div>
                        {child.badge && (
                          <Badge className={getBadgeVariant(child.badge.variant)} variant="outline">
                            {child.badge.text}
                          </Badge>
                        )}
                      </Link>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <Link
                href={item.href}
                className={`flex items-center justify-between px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  pathname === item.href
                    ? "bg-gradient-to-r from-[#00F0FF]/20 to-transparent text-[#00F0FF]"
                    : "text-white/80 hover:bg-white/5 hover:text-white"
                }`}
              >
                <div className="flex items-center gap-3">
                  {item.icon}
                  <span>{item.name}</span>
                </div>
                {item.badge && (
                  <Badge className={getBadgeVariant(item.badge.variant)} variant="outline">
                    {item.badge.text}
                  </Badge>
                )}
              </Link>
            )}
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-white/10 bg-[#0A1A2F]/30">
        <div className="bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 rounded-lg p-3 border border-[#00F0FF]/30">
          <h4 className="font-medium text-sm flex items-center gap-2">
            <Award className="h-4 w-4 text-[#00F0FF]" />
            Pro Affiliate Status
          </h4>
          <p className="text-xs text-white/70 mt-1">Unlock premium features and higher commission rates</p>
          <Button
            className="w-full mt-3 bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90 text-xs py-1"
            size="sm"
          >
            Upgrade Now
          </Button>
        </div>
      </div>
    </div>
  )
}

