"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import { Play } from "lucide-react"

interface VideoTestimonial {
  id: string
  name: string
  role: string
  company: string
  thumbnail: string
  videoUrl: string
}

export function TestimonialVideo() {
  const [activeVideo, setActiveVideo] = useState<string | null>(null)

  const testimonials: VideoTestimonial[] = [
    {
      id: "video1",
      name: "Sarah Johnson",
      role: "Marketing Director",
      company: "StyleTrend",
      thumbnail: "/placeholder.svg?height=400&width=600",
      videoUrl: "#",
    },
    {
      id: "video2",
      name: "Michael Chen",
      role: "Content Creator",
      company: "TechReviews",
      thumbnail: "/placeholder.svg?height=400&width=600",
      videoUrl: "#",
    },
    {
      id: "video3",
      name: "Jessica Williams",
      role: "Affiliate Manager",
      company: "FitLife",
      thumbnail: "/placeholder.svg?height=400&width=600",
      videoUrl: "#",
    },
  ]

  const handlePlayVideo = (id: string) => {
    setActiveVideo(id)
    // In a real implementation, this would trigger the video to play
  }

  const closeVideo = () => {
    setActiveVideo(null)
  }

  return (
    <section className="py-24 bg-[#0A0A14]">
      <div className="container px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge
            className="mb-4 bg-gradient-to-r from-[#00F0FF]/20 to-[#0033CC]/20 text-white border-[#00F0FF]/50"
            variant="outline"
          >
            SUCCESS STORIES
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#00F0FF]">
            Hear From Our Users
          </h2>
          <p className="text-base md:text-lg text-white/70">
            Real stories from real affiliates and brands who have transformed their businesses with our platform.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="relative group"
            >
              <div className="relative overflow-hidden rounded-lg border border-white/10 bg-white/5 aspect-video">
                <img
                  src={testimonial.thumbnail || "/placeholder.svg"}
                  alt={`${testimonial.name} testimonial`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A14] to-transparent opacity-70"></div>

                <button
                  onClick={() => handlePlayVideo(testimonial.id)}
                  className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-16 w-16 rounded-full bg-[#00F0FF] flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
                >
                  <Play className="h-6 w-6 text-[#0A0A14] ml-1" fill="#0A0A14" />
                </button>

                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <h3 className="font-bold text-lg">{testimonial.name}</h3>
                  <p className="text-white/70 text-sm">
                    {testimonial.role}, {testimonial.company}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {activeVideo && (
          <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
            <div className="relative w-full max-w-4xl">
              <button onClick={closeVideo} className="absolute -top-12 right-0 text-white/70 hover:text-white">
                Close
              </button>
              <div className="bg-black aspect-video rounded-lg">
                {/* Video player would go here in a real implementation */}
                <div className="flex items-center justify-center h-full">
                  <p className="text-white">Video player would appear here</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}

