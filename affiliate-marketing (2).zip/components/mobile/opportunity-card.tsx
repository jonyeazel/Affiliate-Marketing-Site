"use client"

import { Button } from "@/components/ui/button"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Sparkles, Users, DollarSign, TrendingUp, ChevronUp } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface OpportunityCardProps {
  opportunity: {
    id: string
    title: string
    brand: {
      name: string
      logo: string
      verified: boolean
    }
    category: string
    commission: string
    matchScore: number
    earnings: string
    timeLeft: string
    spots: number
    totalSpots: number
    description: string
    requirements?: string[]
    media?: string
    isHot?: boolean
  }
  isActive: boolean
}

export default function OpportunityCard({ opportunity, isActive }: OpportunityCardProps) {
  const [showDetails, setShowDetails] = useState(false)

  useEffect(() => {
    if (!isActive) {
      setShowDetails(false)
    }
  }, [isActive])

  return (
    <div className="relative h-full w-full">
      {/* Background Image */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black z-10">
        {opportunity.media ? (
          <img
            src={opportunity.media || "/placeholder.svg"}
            alt={opportunity.title}
            className="h-full w-full object-cover opacity-80"
          />
        ) : (
          <div className="h-full w-full bg-gradient-to-br from-[#111111] to-[#222222]"></div>
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black"></div>
      </div>

      {/* Content */}
      <div className="absolute bottom-0 left-0 right-0 p-4 z-20">
        <AnimatePresence>
          {showDetails ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
              className="bg-black/70 backdrop-blur-md rounded-xl p-4 mb-4"
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <Badge className="mb-2 bg-[#191919] text-white/80">{opportunity.category}</Badge>
                  <h3 className="text-xl font-bold mb-1">{opportunity.title}</h3>
                  <div className="flex items-center text-white/60 text-sm">
                    <span>{opportunity.brand.name}</span>
                    {opportunity.brand.verified && <Sparkles className="ml-1 h-3 w-3 text-[#00CFCF]" />}
                  </div>
                </div>
                <Badge className="bg-[#00CFCF] text-black">{opportunity.matchScore}% Match</Badge>
              </div>

              <p className="text-white/80 mb-4">
                <span className="font-bold text-[#00CFCF]">Earn {opportunity.commission}</span> promoting{" "}
                {opportunity.title}. {opportunity.description}
              </p>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-[#191919] rounded-lg p-3">
                  <div className="text-white/60 text-xs mb-1">Commission</div>
                  <div className="font-bold">{opportunity.commission}</div>
                </div>

                <div className="bg-[#191919] rounded-lg p-3">
                  <div className="text-white/60 text-xs mb-1">Potential Earnings</div>
                  <div className="font-bold">{opportunity.earnings}</div>
                </div>
              </div>

              {opportunity.requirements && (
                <div className="mb-4">
                  <h4 className="font-medium mb-2">Requirements</h4>
                  <ul className="space-y-1">
                    {opportunity.requirements.map((req, index) => (
                      <li key={index} className="flex items-start text-sm">
                        <span className="text-[#00CFCF] mr-2">•</span>
                        <span className="text-white/80">{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="flex items-center justify-between text-sm mb-1">
                <div className="flex items-center text-white/60">
                  <Users className="mr-1 h-4 w-4" />
                  <span>Spots Remaining</span>
                </div>
                <span>
                  {opportunity.spots}/{opportunity.totalSpots}
                </span>
              </div>
              <Progress
                value={(opportunity.spots / opportunity.totalSpots) * 100}
                className="h-1.5 bg-white/10"
                indicatorClassName="bg-[#00CFCF]"
              />

              <Button variant="ghost" className="w-full mt-3 text-white/60" onClick={() => setShowDetails(false)}>
                <ChevronUp className="h-4 w-4" />
                <span className="ml-1">Hide Details</span>
              </Button>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="mb-2">
                {opportunity.isHot && (
                  <Badge className="mb-2 bg-[#00CFCF] text-black">
                    <Sparkles className="mr-1 h-3 w-3" />
                    HOT OPPORTUNITY
                  </Badge>
                )}
                <h3 className="text-2xl font-bold mb-1">{opportunity.title}</h3>
                <div className="flex items-center text-white/60">
                  <span>{opportunity.brand.name}</span>
                  {opportunity.brand.verified && <Sparkles className="ml-1 h-3 w-3 text-[#00CFCF]" />}
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-3">
                <Badge className="bg-[#191919] text-white/80">{opportunity.category}</Badge>
                <Badge className="bg-[#191919] text-white/80">
                  <DollarSign className="mr-1 h-3 w-3 text-[#00CFCF]" />
                  {opportunity.commission}
                </Badge>
                <Badge className="bg-[#191919] text-white/80">
                  <TrendingUp className="mr-1 h-3 w-3 text-[#00CFCF]" />
                  {opportunity.earnings}
                </Badge>
              </div>

              <Button variant="ghost" className="w-full text-white/60" onClick={() => setShowDetails(true)}>
                <span className="mr-1">View Details</span>
                <ChevronUp className="h-4 w-4 rotate-180" />
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

