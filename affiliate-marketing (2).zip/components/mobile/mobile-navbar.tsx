"use client"

import { Compass, BarChart3, Home, User, DollarSign } from "lucide-react"
import { Button } from "@/components/ui/button"

interface MobileNavbarProps {
  activeTab: string
  setActiveTab: (tab: string) => void
}

export default function MobileNavbar({ activeTab, setActiveTab }: MobileNavbarProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black/80 backdrop-blur-xl border-t border-white/10 z-50">
      <div className="flex items-center justify-around h-16">
        <Button
          variant="ghost"
          size="icon"
          className={`flex flex-col items-center justify-center gap-1 h-full w-full rounded-none ${activeTab === "discover" ? "text-[#00CFCF]" : "text-white/60"}`}
          onClick={() => setActiveTab("discover")}
        >
          <Compass className="h-5 w-5" />
          <span className="text-[10px]">Discover</span>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className={`flex flex-col items-center justify-center gap-1 h-full w-full rounded-none ${activeTab === "feed" ? "text-[#00CFCF]" : "text-white/60"}`}
          onClick={() => setActiveTab("feed")}
        >
          <Home className="h-5 w-5" />
          <span className="text-[10px]">Feed</span>
        </Button>

        <div className="relative -top-5">
          <Button className="h-14 w-14 rounded-full bg-[#00CFCF] flex items-center justify-center">
            <DollarSign className="h-6 w-6 text-black" />
          </Button>
        </div>

        <Button
          variant="ghost"
          size="icon"
          className={`flex flex-col items-center justify-center gap-1 h-full w-full rounded-none ${activeTab === "earnings" ? "text-[#00CFCF]" : "text-white/60"}`}
          onClick={() => setActiveTab("earnings")}
        >
          <BarChart3 className="h-5 w-5" />
          <span className="text-[10px]">Earnings</span>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className={`flex flex-col items-center justify-center gap-1 h-full w-full rounded-none ${activeTab === "profile" ? "text-[#00CFCF]" : "text-white/60"}`}
          onClick={() => setActiveTab("profile")}
        >
          <User className="h-5 w-5" />
          <span className="text-[10px]">Profile</span>
        </Button>
      </div>
    </div>
  )
}

