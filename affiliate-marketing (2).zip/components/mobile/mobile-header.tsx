"use client"

import { Search, Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import MoneyDripLogo from "@/components/mobile/moneydrip-logo"

export default function MobileHeader() {
  return (
    <div className="sticky top-0 z-50 bg-black/80 backdrop-blur-xl border-b border-white/10">
      <div className="flex items-center justify-between h-16 px-4">
        <MoneyDripLogo />

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="text-white/70 hover:text-white">
            <Search className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-white/70 hover:text-white">
            <Bell className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}

