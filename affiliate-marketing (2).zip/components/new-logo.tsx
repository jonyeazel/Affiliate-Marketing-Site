"use client"

import { motion } from "framer-motion"

interface LogoProps {
  size?: "sm" | "md" | "lg" | "xl"
  variant?: "default" | "light" | "dark"
  animated?: boolean
}

export default function NewLogo({ size = "md", variant = "default", animated = false }: LogoProps) {
  const sizeMap = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-12 w-12",
    xl: "h-16 w-16",
  }

  const colorMap = {
    default: {
      primary: "from-cyan-500 to-blue-600",
      secondary: "from-indigo-500 to-purple-600",
      text: "text-white",
    },
    light: {
      primary: "from-cyan-400 to-blue-500",
      secondary: "from-indigo-400 to-purple-500",
      text: "text-white",
    },
    dark: {
      primary: "from-cyan-600 to-blue-700",
      secondary: "from-indigo-600 to-purple-700",
      text: "text-white",
    },
  }

  const colors = colorMap[variant]

  if (animated) {
    return (
      <div className="relative flex items-center">
        <motion.div
          className={`relative ${sizeMap[size]}`}
          initial={{ rotate: 0 }}
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
        >
          <div className={`absolute inset-0 rounded-full bg-gradient-to-br ${colors.primary} opacity-70 blur-sm`} />
          <div className={`absolute inset-0 rounded-full bg-gradient-to-br ${colors.primary}`} />
          <div className="absolute inset-0 flex items-center justify-center">
            <svg viewBox="0 0 24 24" className="w-3/4 h-3/4 text-white">
              <motion.path
                d="M12 4L4 8L12 12L20 8L12 4Z"
                fill="currentColor"
                initial={{ opacity: 0.2 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
              />
              <motion.path
                d="M4 8V16L12 20V12"
                fill="currentColor"
                initial={{ opacity: 0.5 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", delay: 0.5 }}
              />
              <motion.path
                d="M20 8V16L12 20V12"
                fill="currentColor"
                initial={{ opacity: 0.5 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", delay: 1 }}
              />
            </svg>
          </div>
        </motion.div>
        <motion.div
          className={`ml-2 font-bold ${colors.text} text-lg`}
          initial={{ opacity: 0, x: -5 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          AffiliateMarketing
        </motion.div>
      </div>
    )
  }

  return (
    <div className="relative flex items-center">
      <div className={`relative ${sizeMap[size]}`}>
        <div className={`absolute inset-0 rounded-full bg-gradient-to-br ${colors.primary} opacity-70 blur-sm`} />
        <div className={`absolute inset-0 rounded-full bg-gradient-to-br ${colors.primary}`} />
        <div className="absolute inset-0 flex items-center justify-center">
          <svg viewBox="0 0 24 24" className="w-3/4 h-3/4 text-white">
            <path d="M12 4L4 8L12 12L20 8L12 4Z" fill="currentColor" />
            <path d="M4 8V16L12 20V12" fill="currentColor" />
            <path d="M20 8V16L12 20V12" fill="currentColor" />
          </svg>
        </div>
      </div>
      <div className={`ml-2 font-bold ${colors.text} text-lg`}>AffiliateMarketing</div>
    </div>
  )
}

