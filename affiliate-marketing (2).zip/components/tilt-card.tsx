"use client"

import type React from "react"

import { useState, useRef, type ReactNode } from "react"

interface TiltCardProps {
  children: ReactNode
  className?: string
  perspective?: number
  scale?: number
  max?: number
  speed?: number
  reset?: boolean
  disabled?: boolean
}

export default function TiltCard({
  children,
  className = "",
  perspective = 1000,
  scale = 1.05,
  max = 15,
  speed = 500,
  reset = true,
  disabled = false,
}: TiltCardProps) {
  const [tiltStyle, setTiltStyle] = useState({
    transform: `perspective(${perspective}px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`,
    transition: `transform ${speed}ms ease-out`,
  })

  const cardRef = useRef<HTMLDivElement>(null)

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (disabled || !cardRef.current) return

    const card = cardRef.current
    const rect = card.getBoundingClientRect()
    const width = rect.width
    const height = rect.height
    const mouseX = e.clientX - rect.left
    const mouseY = e.clientY - rect.top
    const centerX = width / 2
    const centerY = height / 2
    const percentX = (mouseX - centerX) / centerX
    const percentY = (mouseY - centerY) / centerY
    const tiltX = max * percentY * -1
    const tiltY = max * percentX

    setTiltStyle({
      transform: `perspective(${perspective}px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) scale3d(${scale}, ${scale}, ${scale})`,
      transition: `transform ${speed}ms ease-out`,
    })
  }

  const handleMouseLeave = () => {
    if (reset) {
      setTiltStyle({
        transform: `perspective(${perspective}px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`,
        transition: `transform ${speed}ms ease-out`,
      })
    }
  }

  return (
    <div
      ref={cardRef}
      className={`${className}`}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={tiltStyle}
    >
      {children}
    </div>
  )
}

