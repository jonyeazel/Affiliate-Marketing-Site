"use client"

import { useRef, useEffect, useState, type ReactNode } from "react"

type AnimationType =
  | "fade-in"
  | "slide-up"
  | "slide-down"
  | "slide-left"
  | "slide-right"
  | "zoom-in"
  | "zoom-out"
  | "rotate"

interface AnimatedElementProps {
  children: ReactNode
  animation: AnimationType
  duration?: number
  delay?: number
  threshold?: number
  className?: string
  once?: boolean
}

export default function AnimatedElement({
  children,
  animation,
  duration = 500,
  delay = 0,
  threshold = 0.1,
  className = "",
  once = true,
}: AnimatedElementProps) {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          if (once && ref.current) {
            observer.unobserve(ref.current)
          }
        } else if (!once) {
          setIsVisible(false)
        }
      },
      { threshold },
    )

    const currentRef = ref.current
    if (currentRef) {
      observer.observe(currentRef)
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef)
      }
    }
  }, [threshold, once])

  const getAnimationStyles = () => {
    const baseStyles = {
      opacity: 0,
      transform: "none",
      transition: `all ${duration}ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms`,
    }

    const visibleStyles = {
      opacity: 1,
      transform: "none",
    }

    const animationStyles = {
      "fade-in": { opacity: 0 },
      "slide-up": { opacity: 0, transform: "translateY(20px)" },
      "slide-down": { opacity: 0, transform: "translateY(-20px)" },
      "slide-left": { opacity: 0, transform: "translateX(20px)" },
      "slide-right": { opacity: 0, transform: "translateX(-20px)" },
      "zoom-in": { opacity: 0, transform: "scale(0.95)" },
      "zoom-out": { opacity: 0, transform: "scale(1.05)" },
      rotate: { opacity: 0, transform: "rotate(-5deg)" },
    }

    return isVisible ? { ...baseStyles, ...visibleStyles } : { ...baseStyles, ...animationStyles[animation] }
  }

  return (
    <div ref={ref} className={className} style={getAnimationStyles()}>
      {children}
    </div>
  )
}

