"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DollarSign, Flame, Clock, Users, TrendingUp, Zap, ShoppingBag, ArrowRight } from "lucide-react"

interface Drop {
  id: number
  title: string
  brand: {
    name: string
    logo: string
  }
  category: string
  commission: string
  conversion: number
  timeLeft: string
  spots: number
  totalSpots: number
  earnings: string
  description: string
  image: string
  isHot: boolean
}

export default function TrendingDrops() {
  const drops: Drop[] = [
    {
      id: 1,
      title: "Ultra Boost Headphones Pro",
      brand: {
        name: "SonicWave",
        logo: "/placeholder.svg?height=40&width=40",
      },
      category: "Tech",
      commission: "15% + $20 bonus",
      conversion: 8.4,
      timeLeft: "3 days",
      spots: 18,
      totalSpots: 50,
      earnings: "$120-$350",
      description: "Premium noise-cancelling headphones with 40-hour battery life and spatial audio.",
      image: "/placeholder.svg?height=200&width=300",
      isHot: true,
    },
    {
      id: 2,
      title: "Glow Serum Collection",
      brand: {
        name: "Lumina Beauty",
        logo: "/placeholder.svg?height=40&width=40",
      },
      category: "Beauty",
      commission: "20%",
      conversion: 7.2,
      timeLeft: "5 days",
      spots: 24,
      totalSpots: 75,
      earnings: "$80-$200",
      description: "Viral skincare collection featuring vitamin C, hyaluronic acid, and niacinamide serums.",
      image: "/placeholder.svg?height=200&width=300",
      isHot: true,
    },
    {
      id: 3,
      title: "FitPro Smart Watch",
      brand: {
        name: "TechFit",
        logo: "/placeholder.svg?height=40&width=40",
      },
      category: "Fitness",
      commission: "12% + $15 bonus",
      conversion: 6.8,
      timeLeft: "7 days",
      spots: 32,
      totalSpots: 100,
      earnings: "$90-$250",
      description: "Advanced fitness tracker with heart rate monitoring, sleep analysis, and 10-day battery life.",
      image: "/placeholder.svg?height=200&width=300",
      isHot: false,
    },
  ]

  const [activeTab, setActiveTab] = useState("all")

  return (
    <div className="space-y-6">
      <div className="flex overflow-x-auto pb-2 gap-2">
        <Button
          variant={activeTab === "all" ? "default" : "outline"}
          onClick={() => setActiveTab("all")}
          className={activeTab === "all" ? "bg-[#FFFF00] text-black hover:bg-[#FFFF00]/90" : "border-white/20"}
        >
          All Drops
        </Button>
        <Button
          variant={activeTab === "tech" ? "default" : "outline"}
          onClick={() => setActiveTab("tech")}
          className={activeTab === "tech" ? "bg-[#FFFF00] text-black hover:bg-[#FFFF00]/90" : "border-white/20"}
        >
          Tech
        </Button>
        <Button
          variant={activeTab === "beauty" ? "default" : "outline"}
          onClick={() => setActiveTab("beauty")}
          className={activeTab === "beauty" ? "bg-[#FFFF00] text-black hover:bg-[#FFFF00]/90" : "border-white/20"}
        >
          Beauty
        </Button>
        <Button
          variant={activeTab === "fashion" ? "default" : "outline"}
          onClick={() => setActiveTab("fashion")}
          className={activeTab === "fashion" ? "bg-[#FFFF00] text-black hover:bg-[#FFFF00]/90" : "border-white/20"}
        >
          Fashion
        </Button>
        <Button
          variant={activeTab === "fitness" ? "default" : "outline"}
          onClick={() => setActiveTab("fitness")}
          className={activeTab === "fitness" ? "bg-[#FFFF00] text-black hover:bg-[#FFFF00]/90" : "border-white/20"}
        >
          Fitness
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {drops.map((drop) => (
          <Card key={drop.id} className="bg-[#111111] border-white/10 overflow-hidden">
            <div className="relative">
              <div className="aspect-[3/2] bg-gradient-to-br from-[#111111] to-[#222222] flex items-center justify-center">
                <img
                  src={drop.image || "/placeholder.svg"}
                  alt={drop.title}
                  className="h-full w-full object-cover opacity-90"
                />
              </div>

              {drop.isHot && (
                <Badge className="absolute top-3 right-3 bg-gradient-to-r from-[#FF5500] to-[#FFAA00] text-black font-medium">
                  <Flame className="mr-1 h-3 w-3" />
                  HOT DROP
                </Badge>
              )}

              <div className="absolute bottom-3 left-3 flex items-center">
                <Avatar className="h-8 w-8 border-2 border-[#111111]">
                  <AvatarImage src={drop.brand.logo} alt={drop.brand.name} />
                  <AvatarFallback>{drop.brand.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <span className="ml-2 text-sm font-medium bg-black/70 px-2 py-1 rounded-md">{drop.brand.name}</span>
              </div>
            </div>

            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <h3 className="font-bold text-lg">{drop.title}</h3>
                <Badge variant="outline" className="border-[#00FFFF] text-[#00FFFF] ml-2 whitespace-nowrap">
                  {drop.category}
                </Badge>
              </div>

              <p className="text-white/70 text-sm mb-4">{drop.description}</p>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-[#191919] rounded-md p-2">
                  <div className="flex items-center text-xs text-white/60 mb-1">
                    <DollarSign className="h-3 w-3 mr-1" />
                    Commission
                  </div>
                  <div className="font-medium text-[#FF00FF]">{drop.commission}</div>
                </div>

                <div className="bg-[#191919] rounded-md p-2">
                  <div className="flex items-center text-xs text-white/60 mb-1">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    Conversion
                  </div>
                  <div className="font-medium">{drop.conversion}%</div>
                </div>

                <div className="bg-[#191919] rounded-md p-2">
                  <div className="flex items-center text-xs text-white/60 mb-1">
                    <Clock className="h-3 w-3 mr-1" />
                    Time Left
                  </div>
                  <div className="font-medium">{drop.timeLeft}</div>
                </div>

                <div className="bg-[#191919] rounded-md p-2">
                  <div className="flex items-center text-xs text-white/60 mb-1">
                    <Users className="h-3 w-3 mr-1" />
                    Spots Left
                  </div>
                  <div className="font-medium">
                    {drop.spots}/{drop.totalSpots}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center text-[#00FFFF]">
                  <Zap className="h-4 w-4 mr-1" />
                  Avg Earnings: {drop.earnings}
                </div>
              </div>
            </CardContent>

            <CardFooter className="p-4 pt-0">
              <Button className="w-full bg-gradient-to-r from-[#FFFF00] to-[#FF8800] text-black font-medium">
                <ShoppingBag className="mr-2 h-4 w-4" />
                Claim This Drop
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="text-center">
        <Button variant="outline" className="border-white/20">
          View All Drops
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

