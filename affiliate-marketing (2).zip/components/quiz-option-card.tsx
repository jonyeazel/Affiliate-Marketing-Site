"use client"

import type React from "react"

import { motion } from "framer-motion"
import { CheckCircle2, Circle } from "lucide-react"
import { cn } from "@/lib/utils"

interface QuizOptionCardProps {
  id: string
  label: string
  description?: string
  icon?: React.ElementType
  isSelected: boolean
  onClick: () => void
}

export default function QuizOptionCard({
  id,
  label,
  description,
  icon: Icon,
  isSelected,
  onClick,
}: QuizOptionCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={cn(
        "relative rounded-lg border-2 p-4 cursor-pointer transition-all duration-200",
        isSelected
          ? "border-cyan-500 bg-slate-800/70"
          : "border-slate-700 hover:border-slate-600 hover:bg-slate-800/30",
      )}
      onClick={onClick}
    >
      <div className="flex items-start gap-4">
        {Icon && (
          <div
            className={cn(
              "flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center",
              isSelected ? "bg-gradient-to-r from-cyan-500 to-blue-600" : "bg-slate-700",
            )}
          >
            <Icon className="h-5 w-5" />
          </div>
        )}
        <div className="flex-1">
          <div className="flex justify-between">
            <h3 className="font-medium text-lg">{label}</h3>
            <div>
              {isSelected ? (
                <CheckCircle2 className="h-5 w-5 text-cyan-500" />
              ) : (
                <Circle className="h-5 w-5 text-slate-500" />
              )}
            </div>
          </div>
          {description && <p className="text-slate-300 text-sm mt-1">{description}</p>}
        </div>
      </div>

      {isSelected && (
        <motion.div
          className="absolute inset-0 rounded-lg border-2 border-cyan-500 pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          layoutId="selectedOption"
        />
      )}
    </motion.div>
  )
}

