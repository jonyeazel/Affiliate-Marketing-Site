"use client"

import type React from "react"

import { motion } from "framer-motion"
import { Lock } from "lucide-react"
import { useRef, useState } from "react"

export function CredentialCard() {
  const cardRef = useRef<HTMLDivElement>(null)
  const [rotateX, setRotateX] = useState(0)
  const [rotateY, setRotateY] = useState(0)

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return

    const rect = cardRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    const centerX = rect.width / 2
    const centerY = rect.height / 2

    const rotateXValue = ((y - centerY) / centerY) * -10
    const rotateYValue = ((x - centerX) / centerX) * 10

    setRotateX(rotateXValue)
    setRotateY(rotateYValue)
  }

  const handleMouseLeave = () => {
    setRotateX(0)
    setRotateY(0)
  }

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX,
        rotateY,
        transformStyle: "preserve-3d",
      }}
      className="relative rounded-2xl overflow-hidden shadow-2xl border border-[#00F0FF]/30 bg-gradient-to-br from-[#0A1A2F] to-[#0F2847] transition-all duration-700"
    >
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=600&width=400')] bg-cover opacity-10 mix-blend-overlay"></div>
      <div className="p-8 h-full flex flex-col" style={{ minHeight: "400px" }}>
        <div className="flex justify-between items-start mb-auto">
          <div>
            <div className="flex items-center gap-2">
              <div className="relative h-8 w-8">
                <div className="absolute h-4 w-8 bg-[#00F0FF] top-0 rounded-sm"></div>
                <div className="absolute h-4 w-6 bg-[#0033CC] bottom-0 left-1 rounded-sm"></div>
                <div className="absolute h-4 w-4 bg-[#FFFFFF] bottom-0 right-1 rounded-sm"></div>
              </div>
              <span className="font-bold text-lg text-white">affiliatemarketing.com</span>
            </div>
            <div className="text-xs text-[#00F0FF] mt-1">VERIFIED AFFILIATE</div>
          </div>
          <div className="h-12 w-12 rounded-full bg-gradient-to-r from-[#00F0FF] to-[#0033CC] flex items-center justify-center">
            <span className="text-xs font-bold text-black">TIER 1</span>
          </div>
        </div>

        <div className="mt-auto">
          <div className="text-white/60 text-xs mb-1">MEMBER SINCE</div>
          <div className="text-white font-medium">MARCH 2025</div>

          <div className="mt-4 text-white/60 text-xs mb-1">MEMBER ID</div>
          <div className="text-white font-medium font-mono">#AF38291D</div>

          <div className="mt-4 text-white/60 text-xs mb-1">VERIFIED STATUS</div>
          <div className="flex items-center">
            <span className="text-white font-medium mr-2">ACTIVE</span>
            <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></span>
          </div>

          <div className="mt-6 pt-6 border-t border-white/10">
            <div className="flex justify-between items-center">
              <div className="text-xs text-white/60">Tap card to view benefits</div>
              <div className="text-xs text-[#00F0FF] flex items-center gap-1">
                <Lock className="h-3 w-3" />
                Secured by blockchain
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Elements */}
      <div className="absolute -top-4 -left-4 h-24 w-24 bg-[#00F0FF] rounded-full blur-[100px] opacity-30 animate-pulse"></div>
      <div className="absolute -bottom-4 -right-4 h-24 w-24 bg-[#0033CC] rounded-full blur-[100px] opacity-30 animate-pulse delay-700"></div>
    </motion.div>
  )
}

