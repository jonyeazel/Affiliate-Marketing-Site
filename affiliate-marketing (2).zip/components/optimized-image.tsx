"use client"

import { useState, useEffect } from "react"
import Image from "next/image"

interface OptimizedImageProps {
  src: string
  alt: string
  width: number
  height: number
  className?: string
  priority?: boolean
}

export default function OptimizedImage({
  src,
  alt,
  width,
  height,
  className = "",
  priority = false,
}: OptimizedImageProps) {
  const [isLoaded, setIsLoaded] = useState(false)
  const [isInView, setIsInView] = useState(false)

  useEffect(() => {
    if (!priority) {
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setIsInView(true)
            observer.disconnect()
          }
        },
        { rootMargin: "200px" },
      )

      const currentElement = document.getElementById(`image-${src.replace(/\W/g, "")}`)
      if (currentElement) {
        observer.observe(currentElement)
      }

      return () => {
        if (currentElement) {
          observer.unobserve(currentElement)
        }
      }
    } else {
      setIsInView(true)
    }
  }, [src, priority])

  return (
    <div
      id={`image-${src.replace(/\W/g, "")}`}
      className={`relative overflow-hidden ${className}`}
      style={{ width, height }}
    >
      {(isInView || priority) && (
        <>
          <div
            className={`absolute inset-0 bg-gray-200 dark:bg-gray-800 animate-pulse ${
              isLoaded ? "opacity-0" : "opacity-100"
            } transition-opacity duration-300`}
          />
          <Image
            src={src || "/placeholder.svg"}
            alt={alt}
            width={width}
            height={height}
            className={`transition-opacity duration-500 ${isLoaded ? "opacity-100" : "opacity-0"}`}
            onLoad={() => setIsLoaded(true)}
            priority={priority}
          />
        </>
      )}
    </div>
  )
}

