"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

export function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Check if user has already consented
    const hasConsented = localStorage.getItem("cookieConsent")

    if (!hasConsented) {
      // Show the banner after a short delay
      const timer = setTimeout(() => {
        setIsVisible(true)
      }, 2000)

      return () => clearTimeout(timer)
    }
  }, [])

  const acceptAll = () => {
    localStorage.setItem("cookieConsent", "all")
    setIsVisible(false)
  }

  const acceptNecessary = () => {
    localStorage.setItem("cookieConsent", "necessary")
    setIsVisible(false)
  }

  const dismiss = () => {
    setIsVisible(false)
  }

  if (!isVisible) return null

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 20 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-4 right-4 z-50 max-w-sm"
        >
          <div className="bg-[#0A0A14] border border-white/10 rounded-lg shadow-2xl p-4 flex flex-col">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-sm font-medium text-white/90">Cookie Notice</h3>
              <Button
                onClick={dismiss}
                variant="ghost"
                className="h-6 w-6 p-0 text-white/70 hover:text-white hover:bg-white/10"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>

            <p className="text-white/70 text-xs mb-3">We use cookies to improve your experience.</p>

            <div className="flex gap-2">
              <Button
                onClick={acceptAll}
                size="sm"
                className="text-xs h-7 px-2 bg-gradient-to-r from-[#00F0FF] to-[#0033CC] text-white hover:opacity-90 transition-opacity duration-300"
              >
                Accept
              </Button>

              <Button
                onClick={acceptNecessary}
                size="sm"
                className="text-xs h-7 px-2 bg-white/10 text-white hover:bg-white/20 transition-colors duration-300"
              >
                Decline
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

