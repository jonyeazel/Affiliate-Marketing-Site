"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface QuizProgressIndicatorProps {
  steps: number
  currentStep: number
  labels?: string[]
}

export default function QuizProgressIndicator({ steps, currentStep, labels }: QuizProgressIndicatorProps) {
  return (
    <div className="w-full max-w-3xl mx-auto mb-4 md:mb-6">
      <div className="relative">
        {/* Background line */}
        <div className="absolute top-1/2 left-0 right-0 h-0.5 -translate-y-1/2 bg-slate-800/80" />

        {/* Progress line */}
        <motion.div
          className="absolute top-1/2 left-0 h-0.5 -translate-y-1/2 bg-gradient-to-r from-cyan-400 via-cyan-500 to-blue-500"
          initial={{ width: 0 }}
          animate={{ width: `${(currentStep / (steps - 1)) * 100}%` }}
          transition={{ duration: 0.5 }}
        />

        {/* Step indicators */}
        <div className="relative flex justify-between">
          {Array.from({ length: steps }).map((_, index) => {
            const isCompleted = index < currentStep
            const isCurrent = index === currentStep

            return (
              <div key={index} className="flex flex-col items-center">
                <motion.div
                  className={cn(
                    "w-6 h-6 md:w-8 md:h-8 rounded-full flex items-center justify-center z-10",
                    isCompleted
                      ? "bg-gradient-to-r from-cyan-400 to-blue-500 shadow-md shadow-cyan-900/30"
                      : isCurrent
                        ? "bg-cyan-500 shadow-md shadow-cyan-900/20"
                        : "bg-slate-800",
                  )}
                  initial={{ scale: 0.8 }}
                  animate={{
                    scale: isCurrent ? 1.1 : 1,
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <span className="text-white font-medium text-xs md:text-sm">{index + 1}</span>
                </motion.div>

                {labels && (
                  <span
                    className={cn(
                      "mt-1 md:mt-2 text-[10px] md:text-xs font-medium",
                      isCurrent ? "text-cyan-400" : isCompleted ? "text-cyan-100" : "text-slate-500",
                    )}
                  >
                    {labels[index]}
                  </span>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

