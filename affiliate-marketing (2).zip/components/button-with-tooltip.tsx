"use client"

import { useState, type ReactNode } from "react"
import { Button } from "@/components/ui/button"

interface ButtonWithTooltipProps {
  children: ReactNode
  tooltip: string
  className?: string
  onClick?: () => void
  ariaLabel?: string
}

export default function ButtonWithTooltip({
  children,
  tooltip,
  className = "",
  onClick,
  ariaLabel,
}: ButtonWithTooltipProps) {
  const [showTooltip, setShowTooltip] = useState(false)

  return (
    <div className="relative inline-block">
      <Button
        className={className}
        onClick={onClick}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        onFocus={() => setShowTooltip(true)}
        onBlur={() => setShowTooltip(false)}
        aria-label={ariaLabel || tooltip}
      >
        {children}
      </Button>

      {showTooltip && (
        <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 px-2 py-1 bg-black text-white text-xs rounded whitespace-nowrap z-10">
          {tooltip}
          <div className="absolute left-1/2 -translate-x-1/2 top-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-black"></div>
        </div>
      )}
    </div>
  )
}

