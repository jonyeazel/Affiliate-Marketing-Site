export const defaultSEO = {
  title: "AffiliateMarketing.com - Get Paid Instantly | April 2025",
  titleTemplate: "%s | AffiliateMarketing.com",
  description:
    "The future of affiliate marketing. Get paid instantly, find the best brands, and grow your business. Updated April 2025.",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://affiliatemarketing.com",
    site_name: "AffiliateMarketing.com",
    images: [
      {
        url: "https://affiliatemarketing.com/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "AffiliateMarketing.com",
      },
    ],
  },
  twitter: {
    handle: "@affiliatemarketing",
    site: "@affiliatemarketing",
    cardType: "summary_large_image",
  },
  additionalMetaTags: [
    {
      name: "viewport",
      content: "width=device-width, initial-scale=1",
    },
    {
      name: "theme-color",
      content: "#00F0FF",
    },
    {
      name: "application-name",
      content: "AffiliateMarketing.com",
    },
    {
      name: "apple-mobile-web-app-capable",
      content: "yes",
    },
    {
      name: "apple-mobile-web-app-status-bar-style",
      content: "black-translucent",
    },
    {
      name: "apple-mobile-web-app-title",
      content: "AffiliateMarketing.com",
    },
  ],
  additionalLinkTags: [
    {
      rel: "icon",
      href: "/favicon.ico",
    },
    {
      rel: "apple-touch-icon",
      href: "/apple-touch-icon.png",
      sizes: "180x180",
    },
    {
      rel: "manifest",
      href: "/manifest.json",
    },
  ],
}

export const pageSEO = (title, description, url, imageUrl) => ({
  title,
  description,
  canonical: `https://affiliatemarketing.com${url}`,
  openGraph: {
    title,
    description,
    url: `https://affiliatemarketing.com${url}`,
    images: imageUrl
      ? [
          {
            url: imageUrl,
            width: 1200,
            height: 630,
            alt: title,
          },
        ]
      : defaultSEO.openGraph.images,
  },
})

